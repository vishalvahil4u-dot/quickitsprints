package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.*
import com.example.camera.CameraXVideoRecordingComponent
import com.example.camera.CameraXVideoHelper
import com.example.camera.RecordedVideoResult
import com.example.util.LocalStorageVideoManager
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Inline Card on Order Tracking / Rider Screen showing the real-time status
 * of the Work Video Proof verification pipeline.
 */
@Composable
fun WorkProofInlineCard(
    order: OrderItem,
    isTechnicianView: Boolean = false,
    onOpenProofAction: () -> Unit,
    onDownloadVideo: (() -> Unit)? = null,
    onUploadDeviceVideo: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val proof = order.workProof
    val status = proof?.status ?: WorkProofStatus.NOT_SUBMITTED

    val (bgColor, borderColor, icon, title, subtitle) = when (status) {
        WorkProofStatus.NOT_SUBMITTED -> {
            if (isTechnicianView) {
                Tuple5(
                    BlinkitYellowLight,
                    BlinkitYellowDark,
                    Icons.Default.Videocam,
                    "📹 Video Proof Required for Job Completion",
                    "Record 15-30s video showing appliance running & parts replaced to unlock OTP."
                )
            } else {
                Tuple5(
                    BlinkitSurfaceVariant,
                    BlinkitBorder,
                    Icons.Default.Pending,
                    "📹 Work Verification in Progress",
                    "Technician will upload timestamped video proof once on-site work is completed."
                )
            }
        }
        WorkProofStatus.SUBMITTED -> {
            Tuple5(
                BlinkitGreenLight.copy(alpha = 0.8f),
                BlinkitGreen,
                Icons.Default.PlayCircle,
                if (isTechnicianView) "📹 Proof Submitted • Awaiting Client Review" else "📹 Review Technician's Work Video Proof",
                if (isTechnicianView) "Client has received alert to review proof & authorize payment / OTP." else "Inspect video proof. You can download, upload device video if issue, or approve & pay."
            )
        }
        WorkProofStatus.APPROVED_BY_CLIENT -> {
            Tuple5(
                BlinkitGreenLight,
                BlinkitGreenDark,
                Icons.Default.VerifiedUser,
                "✓ Work Proof Approved & Payment Settled",
                "Appliance tested & verified. 30-Day Free Rework Warranty active."
            )
        }
        WorkProofStatus.REVISION_REQUESTED -> {
            Tuple5(
                BlinkitRed.copy(alpha = 0.12f),
                BlinkitRed,
                Icons.Default.Warning,
                "⚠️ Re-Check Requested by Customer",
                "Reason: ${proof?.clientRejectionReason ?: "Issue needs further inspection"}. Please resolve & re-record."
            )
        }
        WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> {
            Tuple5(
                Color(0xFFFFF7ED),
                Color(0xFFEA580C),
                Icons.Default.PauseCircleFilled,
                "⏸️ Payment On Hold • Admin Reviewing Video",
                "Issue reported with local video proof. Payment frozen until Admin reviews & approves."
            )
        }
        WorkProofStatus.ADMIN_APPROVED -> {
            Tuple5(
                Color(0xFFF0FDF4),
                Color(0xFF16A34A),
                Icons.Default.AdminPanelSettings,
                "🛡️ Admin Approved Video Proof",
                "Admin ${proof?.adminReviewerName ?: "Operations"} verified job video. Payment released."
            )
        }
        WorkProofStatus.ADMIN_REFUNDED -> {
            Tuple5(
                Color(0xFFFAF5FF),
                Color(0xFF9333EA),
                Icons.Default.CurrencyRupee,
                "💸 Claim Approved • Refund Processed",
                "Admin confirmed customer dispute. Full refund credited to QuickIt Wallet."
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("work_proof_inline_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, borderColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = borderColor, modifier = Modifier.size(20.dp))
                    }

                    Column {
                        Text(
                            title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            subtitle,
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            // Telemetry Badges
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = Color.White.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.5.dp, BlinkitBorder)
                ) {
                    Text(
                        when {
                            order.workProof?.isPaymentOnHold == true -> "⏸️ Payment Held in Escrow"
                            order.workProof?.customerDownloadedVideo == true -> "⬇️ Video Downloaded Locally"
                            order.workProof?.customerLocalVideoPath != null -> "📁 Local Device Video Attached"
                            order.workProof?.isSavedToPhoneStorage == true -> "💾 Saved to Phone Storage (DCIM)"
                            else -> "📍 GPS & Timestamp Verified"
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (order.workProof?.isPaymentOnHold == true) Color(0xFFEA580C) else BlinkitGreenDark,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Action Buttons
            if (!isTechnicianView) {
                // Customer Video Hub Action Buttons (Download, Upload Rebuttal Video, Review Proof)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (onDownloadVideo != null) {
                        OutlinedButton(
                            onClick = onDownloadVideo,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_customer_download_video"),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                            border = BorderStroke(1.dp, BlinkitDark)
                        ) {
                            Icon(
                                if (proof?.customerDownloadedVideo == true) Icons.Default.CheckCircle else Icons.Default.Download,
                                contentDescription = null,
                                tint = BlinkitDark,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                if (proof?.customerDownloadedVideo == true) "Downloaded" else "Download",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark
                            )
                        }
                    }

                    if (onUploadDeviceVideo != null) {
                        OutlinedButton(
                            onClick = onUploadDeviceVideo,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_customer_upload_video"),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                            border = BorderStroke(1.dp, Color(0xFFEA580C))
                        ) {
                            Icon(
                                Icons.Default.UploadFile,
                                contentDescription = null,
                                tint = Color(0xFFEA580C),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                if (proof?.customerLocalVideoPath != null) "Rebuttal ✓" else "Upload Video",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEA580C)
                            )
                        }
                    }

                    Button(
                        onClick = onOpenProofAction,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (status) {
                                WorkProofStatus.APPROVED_BY_CLIENT, WorkProofStatus.ADMIN_APPROVED -> BlinkitGreenDark
                                WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEA580C)
                                WorkProofStatus.ADMIN_REFUNDED -> Color(0xFF9333EA)
                                else -> BlinkitGreen
                            }
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("open_work_proof_btn")
                    ) {
                        Icon(
                            Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            when {
                                status == WorkProofStatus.SUBMITTED -> "Review & Pay"
                                status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> "Hold Status"
                                else -> "View Proof"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            } else {
                // Technician View Single Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onOpenProofAction,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (status) {
                                WorkProofStatus.APPROVED_BY_CLIENT, WorkProofStatus.ADMIN_APPROVED -> BlinkitGreenDark
                                WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEA580C)
                                WorkProofStatus.ADMIN_REFUNDED -> Color(0xFF9333EA)
                                else -> BlinkitGreen
                            }
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("open_work_proof_btn")
                    ) {
                        Icon(
                            if (status == WorkProofStatus.NOT_SUBMITTED || status == WorkProofStatus.REVISION_REQUESTED) Icons.Default.Videocam else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            when {
                                status == WorkProofStatus.NOT_SUBMITTED || status == WorkProofStatus.REVISION_REQUESTED -> "Record Video Proof"
                                else -> "View Proof"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dedicated Modal Dialog for the Customer to Download the Technician's Proof Video to Local Storage.
 */
@Composable
fun CustomerVideoDownloadDialog(
    order: OrderItem,
    onDownloadConfirmed: () -> String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var downloadProgress by remember { mutableStateOf(0f) }
    var isDownloading by remember { mutableStateOf(true) }
    var downloadedPath by remember {
        mutableStateOf(
            order.workProof?.customerDownloadedPath ?: "/storage/emulated/0/DCIM/QuickIt_Proofs/DOWNLOAD_VID_${order.orderNumber}.mp4"
        )
    }

    LaunchedEffect(Unit) {
        val path = onDownloadConfirmed()
        downloadedPath = path
        for (i in 1..10) {
            delay(150)
            downloadProgress = i / 10f
        }
        isDownloading = false
        Toast.makeText(context, "Video downloaded to $path", Toast.LENGTH_LONG).show()
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .testTag("customer_video_download_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isDownloading) BlinkitYellowLight else BlinkitGreenLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (isDownloading) Icons.Default.Download else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (isDownloading) BlinkitDark else BlinkitGreenDark,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Text(
                    if (isDownloading) "Downloading Proof Video..." else "Video Saved to Device Storage",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = BlinkitTextPrimary,
                    textAlign = TextAlign.Center
                )

                Text(
                    "Order #${order.orderNumber} • ${order.riderName} (1080p FHD • 24 FPS)",
                    fontSize = 11.sp,
                    color = BlinkitTextSecondary,
                    textAlign = TextAlign.Center
                )

                if (isDownloading) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = downloadProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = BlinkitGreen,
                            trackColor = BlinkitSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${(downloadProgress * 100).toInt()}% Complete", fontSize = 10.sp, color = BlinkitTextSecondary)
                            Text("18.4 MB / 18.4 MB (4.5 MB/s)", fontSize = 10.sp, color = BlinkitTextSecondary, fontFamily = FontFamily.Monospace)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = BlinkitSurfaceVariant,
                        border = BorderStroke(1.dp, BlinkitBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("📁 Local Storage Path:", fontSize = 10.sp, color = BlinkitTextSecondary, fontWeight = FontWeight.Bold)
                            Text(
                                downloadedPath,
                                fontSize = 10.sp,
                                color = BlinkitTextPrimary,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 13.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(16.dp))
                        Text("Timestamped & GPS-Watermarked for dispute security", fontSize = 10.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDownloading) BlinkitDark else BlinkitGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isDownloading) "Downloading in Background..." else "Done", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * Dedicated Modal Dialog for the Customer to Upload Video from Local Phone Storage / Camera.
 */
@Composable
fun CustomerVideoUploadDialog(
    order: OrderItem,
    onUploadConfirmed: (localPath: String, reason: String, category: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedVideoUri by remember { mutableStateOf<String?>(order.workProof?.customerLocalVideoPath) }
    var selectedCategory by remember { mutableStateOf("Water Leakage / Pipe Dripping") }
    var customerNotes by remember { mutableStateOf("") }
    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf(0f) }
    var showSuccessState by remember { mutableStateOf(false) }

    // System File/Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = "/storage/emulated/0/DCIM/Camera/VID_CUSTOMER_PICKED_${System.currentTimeMillis()}.mp4"
            Toast.makeText(context, "Selected video: $selectedVideoUri", Toast.LENGTH_SHORT).show()
        }
    }

    val sampleVideos = listOf(
        "📹 VID_AC_Water_Leakage_persisting.mp4 (14.2 MB)" to "/storage/emulated/0/DCIM/Camera/VID_AC_Water_Leakage.mp4",
        "📹 VID_Compressor_Unusual_Vibration.mp4 (9.8 MB)" to "/storage/emulated/0/DCIM/Camera/VID_Compressor_Vibration.mp4",
        "📹 VID_Electrical_Sparking_Outlet.mp4 (16.5 MB)" to "/storage/emulated/0/DCIM/Camera/VID_Sparking_Outlet.mp4",
        "📹 VID_Drainage_Clogged_Pipes.mp4 (11.0 MB)" to "/storage/emulated/0/DCIM/Camera/VID_Drainage_Clog.mp4"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f)
                .padding(vertical = 10.dp)
                .testTag("customer_video_upload_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF7ED)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text("Upload Issue Video Proof", fontSize = 15.sp, fontWeight = FontWeight.Black, color = BlinkitTextPrimary)
                            Text("Attach device video to freeze payment & dispute", fontSize = 10.sp, color = BlinkitTextSecondary)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                if (showSuccessState) {
                    // Success / Payment On Hold View
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF7ED)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⏸️", fontSize = 32.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Video Uploaded & Payment On Hold",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFEA580C),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Your video evidence has been securely attached to Order #${order.orderNumber}. Payment is 100% frozen in escrow until Admin reviews the video files.",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BlinkitSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Uploaded Video: $selectedVideoUri", fontSize = 10.sp, color = BlinkitTextPrimary, fontFamily = FontFamily.Monospace)
                                Text("Category: $selectedCategory", fontSize = 10.sp, color = Color(0xFFEA580C), fontWeight = FontWeight.Bold)
                                if (customerNotes.isNotEmpty()) {
                                    Text("Notes: $customerNotes", fontSize = 10.sp, color = BlinkitTextSecondary)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Close", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Video Selector Buttons (System Picker + Simulated Gallery)
                        item {
                            Text("1. Choose Video from Phone Storage or Camera:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = BlinkitSurfaceVariant,
                                    border = BorderStroke(1.dp, if (selectedVideoUri != null) BlinkitGreen else BlinkitBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            videoPickerLauncher.launch("video/*")
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(24.dp))
                                        Text("Open Gallery / Files", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                        Text("Select MP4 / MOV", fontSize = 9.sp, color = BlinkitTextSecondary)
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = BlinkitSurfaceVariant,
                                    border = BorderStroke(1.dp, BlinkitBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedVideoUri = "/storage/emulated/0/DCIM/Camera/VID_CAMERA_RECORDED_${System.currentTimeMillis()}.mp4"
                                            Toast.makeText(context, "Recorded with Camera: $selectedVideoUri", Toast.LENGTH_SHORT).show()
                                        }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Videocam, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(24.dp))
                                        Text("Record with Camera", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEA580C))
                                        Text("Record live issue", fontSize = 9.sp, color = BlinkitTextSecondary)
                                    }
                                }
                            }
                        }

                        // Sample Videos for 1-Tap Quick Selection
                        item {
                            Text("Or Tap a Device Video Sample:", fontSize = 10.sp, color = BlinkitTextSecondary, fontWeight = FontWeight.Bold)
                        }

                        items(sampleVideos) { (label, path) ->
                            val isSelected = selectedVideoUri == path
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFFFFF7ED) else BlinkitSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFFEA580C) else BlinkitBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedVideoUri = path }
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedVideoUri = path },
                                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFEA580C))
                                    )
                                    Column {
                                        Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = BlinkitTextPrimary)
                                        Text(path, fontSize = 9.sp, color = BlinkitTextSecondary, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }

                        // 2. Issue Category
                        item {
                            Text("2. Issue Category:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                        }

                        item {
                            listOf(
                                "Water Leakage / Pipe Dripping",
                                "Appliance Vibration / Abnormal Noise",
                                "Cooling / Heating Ineffective",
                                "Electrical Sparking / Tripping Switch",
                                "Technician Proof Incomplete / Unclear"
                            ).forEach { cat ->
                                val isSelected = selectedCategory == cat
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) Color(0xFFFFF7ED) else BlinkitSurfaceVariant,
                                    border = BorderStroke(1.dp, if (isSelected) Color(0xFFEA580C) else BlinkitBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                        .clickable { selectedCategory = cat }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedCategory = cat },
                                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFEA580C))
                                        )
                                        Text(cat, fontSize = 11.sp, color = BlinkitTextPrimary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }
                        }

                        // 3. Customer Notes
                        item {
                            Text("3. Add Detailed Explanation (Optional):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                            OutlinedTextField(
                                value = customerNotes,
                                onValueChange = { customerNotes = it },
                                placeholder = { Text("e.g., Compressor started vibrating loudly after technician left...", fontSize = 11.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(70.dp),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }

                    if (isUploading) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            LinearProgressIndicator(
                                progress = uploadProgress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFFEA580C),
                                trackColor = BlinkitSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Uploading Video Proof...", fontSize = 10.sp, color = Color(0xFFEA580C), fontWeight = FontWeight.Bold)
                                Text("${(uploadProgress * 100).toInt()}%", fontSize = 10.sp, color = BlinkitTextSecondary)
                            }
                        }
                    }

                    // Bottom Action
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cancel", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val videoPath = selectedVideoUri ?: "/storage/emulated/0/DCIM/Camera/VID_CUSTOMER_EVIDENCE_${System.currentTimeMillis()}.mp4"
                                isUploading = true
                                uploadProgress = 0.3f
                                // Launch async upload simulation
                                onUploadConfirmed(
                                    videoPath,
                                    if (customerNotes.isNotEmpty()) customerNotes else "Customer uploaded video for $selectedCategory",
                                    selectedCategory
                                )
                                uploadProgress = 1.0f
                                isUploading = false
                                showSuccessState = true
                            },
                            enabled = !isUploading,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.8f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Upload & Freeze Payment", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

private data class Tuple5<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)

/**
 * Modal Dialog for the Client to review the video proof, check completed tasks,
 * inspect replaced spare parts, download video locally, upload rebuttal device video,
 * put payment on hold for admin review, or Approve & Settle Payment.
 */
@Composable
fun ClientWorkProofReviewDialog(
    order: OrderItem,
    onApproveProof: (rating: Int, paymentMethod: String) -> Unit = { _, _ -> },
    onRequestRevision: (reason: String) -> Unit = {},
    onDownloadVideo: () -> Unit = {},
    onUploadLocalDeviceVideo: (localPath: String, reason: String, category: String) -> Unit = { _, _, _ -> },
    onEscalateToAdmin: (reason: String, category: String, localPath: String?) -> Unit = { _, _, _ -> },
    onDismiss: () -> Unit
) {
    val proof = order.workProof ?: WorkProofRecord(
        videoTitle = "${order.items.firstOrNull()?.service?.name ?: "Service"} Completion Test",
        completedChecklist = listOf(
            "Load test & power draw verified under operating conditions",
            "Zero leakage / vibration inspection passed",
            "Internal coils & components sanitized with high-pressure steam"
        ),
        replacedParts = listOf(
            ReplacedSparePart(partName = "Heavy Duty Dual Capacitor (45+5µF)", partNumber = "CAP-AC-8841", warrantyMonths = 12, price = 350.0, emoji = "🔋"),
            ReplacedSparePart(partName = "High-Flow Brass Drain Valve", partNumber = "VLV-BR-1029", warrantyMonths = 6, price = 180.0, emoji = "🔧")
        )
    )

    var isPlaying by remember { mutableStateOf(true) }
    var currentProgressSec by remember { mutableStateOf(8) }
    var selectedTab by remember { mutableStateOf("VIDEO") } // "VIDEO", "LOCAL_MEDIA", "CHECKLIST", "PARTS", "ADMIN_STATUS"
    var showReportIssueFlow by remember { mutableStateOf(false) }
    var showPaymentSettlementSheet by remember { mutableStateOf(false) }
    var revisionReason by remember { mutableStateOf("") }
    var issueCategory by remember { mutableStateOf("Appliance Operational Issue") }
    var selectedStarRating by remember { mutableStateOf(5) }
    var selectedPaymentMethod by remember { mutableStateOf("UPI (GPay / PhonePe)") }
    var isApprovedScreen by remember { mutableStateOf(proof.status == WorkProofStatus.APPROVED_BY_CLIENT || proof.status == WorkProofStatus.ADMIN_APPROVED) }

    // Local Device Download & Upload simulation states
    var isDownloadingLocal by remember { mutableStateOf(false) }
    var localDownloadedSuccess by remember { mutableStateOf(proof.customerDownloadedVideo) }
    var downloadedPathDisplay by remember { mutableStateOf(proof.customerDownloadedPath ?: "/storage/emulated/0/DCIM/QuickIt_Proofs/VID_${order.orderNumber}.mp4") }

    var selectedDeviceVideoUri by remember { mutableStateOf(proof.customerLocalVideoPath) }
    var isUploadingDeviceVideo by remember { mutableStateOf(false) }
    var deviceVideoUploadSuccess by remember { mutableStateOf(proof.customerLocalVideoPath != null) }

    // Simulated Video Progress Timer
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(1000)
            if (currentProgressSec < proof.videoDurationSec) {
                currentProgressSec++
            } else {
                currentProgressSec = 0
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .padding(vertical = 10.dp)
                .testTag("client_work_proof_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Header with Verification Shield & Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    when (proof.status) {
                                        WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFFFF7ED)
                                        WorkProofStatus.ADMIN_REFUNDED -> Color(0xFFFAF5FF)
                                        else -> BlinkitGreenLight
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                when (proof.status) {
                                    WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Icons.Default.PauseCircleFilled
                                    WorkProofStatus.ADMIN_REFUNDED -> Icons.Default.CurrencyRupee
                                    else -> Icons.Default.Shield
                                },
                                contentDescription = null,
                                tint = when (proof.status) {
                                    WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEA580C)
                                    WorkProofStatus.ADMIN_REFUNDED -> Color(0xFF9333EA)
                                    else -> BlinkitGreenDark
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                "Client Video Proof & Payment",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitTextPrimary
                            )
                            Text(
                                "By ${order.riderName} • Verified On-Site",
                                fontSize = 10.sp,
                                color = BlinkitGreenDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                // Payment Hold Alert Banner if in Dispute
                if (proof.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD || proof.isPaymentOnHold) {
                    Surface(
                        color = Color(0xFFFFF7ED),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFEA580C))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("⏸️", fontSize = 16.sp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "PAYMENT ON HOLD (Admin Reviewing Video Proof)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFEA580C)
                                )
                                Text(
                                    proof.paymentHoldReason ?: "Customer reported issue. Admin is reviewing technician and device videos.",
                                    fontSize = 9.sp,
                                    color = Color(0xFF9A3412),
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }

                if (!isApprovedScreen && !showReportIssueFlow && !showPaymentSettlementSheet) {
                    // Navigation Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .background(BlinkitSurfaceVariant, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TabPill(
                            label = "📹 Video Proof (${proof.videoDurationSec}s)",
                            isSelected = selectedTab == "VIDEO",
                            onClick = { selectedTab = "VIDEO" }
                        )
                        TabPill(
                            label = "📁 Device Video ${if (selectedDeviceVideoUri != null) "✓" else ""}",
                            isSelected = selectedTab == "LOCAL_MEDIA",
                            onClick = { selectedTab = "LOCAL_MEDIA" }
                        )
                        TabPill(
                            label = "✅ Checklist (${proof.checklistItems.size})",
                            isSelected = selectedTab == "CHECKLIST",
                            onClick = { selectedTab = "CHECKLIST" }
                        )
                        TabPill(
                            label = "⚙️ Parts (${proof.replacedParts.size})",
                            isSelected = selectedTab == "PARTS",
                            onClick = { selectedTab = "PARTS" }
                        )
                    }

                    // Content based on Tab
                    Box(modifier = Modifier.weight(1f)) {
                        when (selectedTab) {
                            "VIDEO" -> {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Simulated Video Player Viewfinder
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(
                                                Brush.verticalGradient(
                                                    listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        // Center visual animation / icon
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(proof.videoThumbnailEmoji, fontSize = 44.sp)
                                            Text(
                                                proof.videoTitle,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                "Live Equipment Operational Test (1080p FHD)",
                                                color = Color.White.copy(alpha = 0.7f),
                                                fontSize = 10.sp
                                            )
                                        }

                                        // Top Live GPS & Timestamp Watermark
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.TopCenter)
                                                .background(Color.Black.copy(alpha = 0.6f))
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isPlaying) Color.Red else Color.Gray)
                                                )
                                                Text("REC • GPS WATERMARKED", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text("26-AUG-2026 10:14:02 AM", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        }

                                        // Bottom Location Tag & Play Controls
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.BottomCenter)
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                                    )
                                                )
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                "📍 ${proof.recordedGpsCoordinates}",
                                                color = Color(0xFF4ADE80),
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )

                                            // Scrub Bar
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                IconButton(
                                                    onClick = { isPlaying = !isPlaying },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                        contentDescription = "Play/Pause",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }

                                                LinearProgressIndicator(
                                                    progress = (currentProgressSec.toFloat() / proof.videoDurationSec).coerceIn(0f, 1f),
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(4.dp)
                                                        .clip(RoundedCornerShape(2.dp)),
                                                    color = BlinkitGreen,
                                                    trackColor = Color.White.copy(alpha = 0.3f)
                                                )

                                                Text(
                                                    "0:${String.format("%02d", currentProgressSec)} / 0:${proof.videoDurationSec}",
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            }
                                        }
                                    }

                                    // Local Device Download & Save Option
                                    Surface(
                                        color = if (localDownloadedSuccess) BlinkitGreenLight.copy(alpha = 0.5f) else BlinkitSurfaceVariant,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (localDownloadedSuccess) BlinkitGreen else BlinkitBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text(if (localDownloadedSuccess) "💾" else "⬇️", fontSize = 16.sp)
                                                Column {
                                                    Text(
                                                        if (localDownloadedSuccess) "Downloaded to Device Storage" else "Download Video Proof Locally",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = BlinkitTextPrimary
                                                    )
                                                    Text(
                                                        if (localDownloadedSuccess) downloadedPathDisplay else "Save MP4 to DCIM/QuickIt_Proofs/ for inspection",
                                                        fontSize = 9.sp,
                                                        color = BlinkitTextSecondary,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }

                                            Button(
                                                onClick = {
                                                    isDownloadingLocal = true
                                                    onDownloadVideo()
                                                    localDownloadedSuccess = true
                                                    downloadedPathDisplay = "/storage/emulated/0/DCIM/QuickIt_Proofs/PROOF_${order.orderNumber}_${System.currentTimeMillis()}.mp4"
                                                    isDownloadingLocal = false
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = if (localDownloadedSuccess) BlinkitGreenDark else BlinkitDark
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Text(
                                                    if (localDownloadedSuccess) "Saved ✓" else "Download",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }

                                    // Technician Remarks Card
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("💬", fontSize = 16.sp)
                                            Column {
                                                Text("Technician Note:", fontSize = 10.sp, color = BlinkitTextSecondary, fontWeight = FontWeight.Bold)
                                                Text(proof.technicianRemarks, fontSize = 11.sp, color = BlinkitTextPrimary)
                                            }
                                        }
                                    }
                                }
                            }

                            "LOCAL_MEDIA" -> {
                                // Device Video Upload / Rebuttal Video Section
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Upload Local Video Proof from Device Storage", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                    Text("If you notice any lingering leak, noise, or improper finish, upload a video recorded from your phone camera as rebuttal evidence.", fontSize = 10.sp, color = BlinkitTextSecondary)

                                    if (selectedDeviceVideoUri == null) {
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = BlinkitSurfaceVariant,
                                            border = BorderStroke(1.5.dp, BlinkitBorder),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clickable {
                                                    // Simulate picking video from device gallery
                                                    isUploadingDeviceVideo = true
                                                    selectedDeviceVideoUri = "/storage/emulated/0/DCIM/Camera/CUSTOMER_PROOF_${System.currentTimeMillis()}.mp4"
                                                    deviceVideoUploadSuccess = true
                                                    isUploadingDeviceVideo = false
                                                    onUploadLocalDeviceVideo(
                                                        selectedDeviceVideoUri!!,
                                                        "Customer uploaded device video showing persisting vibration",
                                                        issueCategory
                                                    )
                                                }
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxSize().padding(16.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Icon(Icons.Default.UploadFile, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(36.dp))
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("📁 Tap to Select Video from Device Storage", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                                Text("Supports MP4, MOV from Gallery or DCIM folder", fontSize = 10.sp, color = BlinkitTextSecondary)
                                            }
                                        }
                                    } else {
                                        Card(
                                            shape = RoundedCornerShape(14.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                                            border = BorderStroke(1.5.dp, Color(0xFFEA580C)),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxSize().padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text("📱", fontSize = 18.sp)
                                                        Text("Customer Device Video Attached", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEA580C))
                                                    }
                                                    IconButton(
                                                        onClick = { selectedDeviceVideoUri = null },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Remove", tint = BlinkitRed, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                Text("Path: $selectedDeviceVideoUri", fontSize = 10.sp, color = BlinkitTextSecondary, fontFamily = FontFamily.Monospace)
                                                Text("Status: Attached to dispute packet. Payment frozen pending Admin review.", fontSize = 10.sp, color = Color(0xFF9A3412), fontWeight = FontWeight.Bold)

                                                Spacer(modifier = Modifier.weight(1f))

                                                Button(
                                                    onClick = {
                                                        onEscalateToAdmin(
                                                            "Customer uploaded device video evidence. Payment held.",
                                                            issueCategory,
                                                            selectedDeviceVideoUri
                                                        )
                                                        showReportIssueFlow = false
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("Freeze Payment & Escalate to Admin", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            "CHECKLIST" -> {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    item {
                                        Text("Standard Multi-Point Inspection Checklist:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                    }
                                    items(proof.checklistItems) { item ->
                                        Card(
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(18.dp))
                                                Text(item, fontSize = 11.sp, color = BlinkitTextPrimary, fontWeight = FontWeight.Medium)
                                            }
                                        }
                                    }
                                }
                            }

                            "PARTS" -> {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    item {
                                        Text("Replaced Spare Parts & Manufacturer Warranty:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                    }
                                    if (proof.replacedParts.isEmpty()) {
                                        item {
                                            Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                                                Text("No extra spare parts required. Regular service performed.", fontSize = 11.sp, color = BlinkitTextMuted)
                                            }
                                        }
                                    } else {
                                        items(proof.replacedParts) { part ->
                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                                                border = BorderStroke(1.dp, BlinkitBorder),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(part.emoji, fontSize = 20.sp)
                                                        Column {
                                                            Text(part.partName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                                            Text("Serial #${part.partNumber} • ${part.warrantyMonths}-Month Warranty", fontSize = 9.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                    Text("₹${String.format("%.0f", part.price)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary, fontFamily = FontFamily.Monospace)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Divider(color = BlinkitBorder)

                    // Dual Actions: Report Issue (Hold Payment) OR Approve & Settle Payment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showReportIssueFlow = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFEA580C))
                        ) {
                            Icon(Icons.Default.PauseCircleFilled, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Report Issue / Hold Pay", color = Color(0xFFEA580C), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                showPaymentSettlementSheet = true
                            },
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("approve_work_proof_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Approve & Pay ₹${String.format("%.0f", order.grandTotal)}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                } else if (showPaymentSettlementSheet) {
                    // Payment Settlement Step after Customer Approves Proof
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Settle Payment & Release Completion OTP", fontSize = 15.sp, fontWeight = FontWeight.Black, color = BlinkitTextPrimary)
                        Text("You verified the video proof. Choose payment method to complete the booking:", fontSize = 11.sp, color = BlinkitTextSecondary)

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Grand Total Due", fontSize = 11.sp, color = BlinkitDark, fontWeight = FontWeight.Bold)
                                    Text("Includes ₹29 safety fee + ₹0 visit fee", fontSize = 9.sp, color = BlinkitTextSecondary)
                                }
                                Text(
                                    "₹${String.format("%.0f", order.grandTotal)}",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BlinkitDark,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Payment Methods
                        listOf(
                            "UPI (GPay / PhonePe / Paytm)" to "⚡ Instant 0% fee",
                            "QuickIt Wallet (Pre-loaded)" to "💼 1-Tap debit",
                            "Credit / Debit Card (Visa/Mastercard)" to "💳 Auto receipt & GST invoice",
                            "Cash / UPI to Technician On-Site" to "🤝 Pay technician directly"
                        ).forEach { (method, sub) ->
                            val isSelected = selectedPaymentMethod == method
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) BlinkitGreen else BlinkitBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPaymentMethod = method }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedPaymentMethod = method },
                                        colors = RadioButtonDefaults.colors(selectedColor = BlinkitGreen)
                                    )
                                    Column {
                                        Text(method, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                        Text(sub, fontSize = 9.sp, color = BlinkitTextSecondary)
                                    }
                                }
                            }
                        }

                        // Rating Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Rate Technician Service:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                (1..5).forEach { star ->
                                    Text(
                                        if (star <= selectedStarRating) "⭐" else "☆",
                                        fontSize = 18.sp,
                                        modifier = Modifier.clickable { selectedStarRating = star }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showPaymentSettlementSheet = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Back", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                onApproveProof(selectedStarRating, selectedPaymentMethod)
                                showPaymentSettlementSheet = false
                                isApprovedScreen = true
                            },
                            modifier = Modifier.weight(1.8f),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Pay ₹${String.format("%.0f", order.grandTotal)} & Get OTP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                } else if (showReportIssueFlow) {
                    // Report Issue & Escalate to Admin Hold Sub-view
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Hold Payment & Escalate to Admin Review", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color(0xFFEA580C))
                        Text("Your payment will remain 100% frozen in escrow until our Admin Operations Team reviews the video evidence.", fontSize = 10.sp, color = BlinkitTextSecondary)

                        listOf(
                            "Appliance still vibrating / making unusual sound",
                            "Water leakage or pressure drop still persisting",
                            "Cooling / heating temperature not adequate",
                            "Video proof is unclear / did not record actual running test",
                            "Area not cleaned or old spare parts not handed over"
                        ).forEach { presetReason ->
                            val isSelected = revisionReason == presetReason
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFFFFF7ED) else BlinkitSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFFEA580C) else BlinkitBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        revisionReason = presetReason
                                        issueCategory = presetReason
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            revisionReason = presetReason
                                            issueCategory = presetReason
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFEA580C))
                                    )
                                    Text(presetReason, fontSize = 11.sp, color = BlinkitTextPrimary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = revisionReason,
                            onValueChange = { revisionReason = it },
                            placeholder = { Text("Or describe issue in detail...", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            maxLines = 2
                        )

                        // Option to attach local video
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BlinkitSurfaceVariant,
                            border = BorderStroke(1.dp, BlinkitBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedDeviceVideoUri = "/storage/emulated/0/DCIM/Camera/REBUTTAL_PROOF_${System.currentTimeMillis()}.mp4"
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(18.dp))
                                Column {
                                    Text(
                                        if (selectedDeviceVideoUri != null) "📁 Attached: $selectedDeviceVideoUri" else "📁 Attach Rebuttal Video from Device (Optional)",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BlinkitDark
                                    )
                                    Text("Helps admin verify your dispute instantly", fontSize = 9.sp, color = BlinkitTextSecondary)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showReportIssueFlow = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Back", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                val reason = if (revisionReason.isBlank()) "Service issue flagged during client inspection" else revisionReason
                                onEscalateToAdmin(reason, issueCategory, selectedDeviceVideoUri)
                                onRequestRevision(reason)
                                showReportIssueFlow = false
                            },
                            modifier = Modifier.weight(1.8f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PauseCircleFilled, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Put Payment On Hold & Escalate", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Celebration / Approved & OTP Revealed Screen
                    val scale = remember { Animatable(0.5f) }
                    LaunchedEffect(Unit) {
                        scale.animateTo(
                            targetValue = 1f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessLow
                            )
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .scale(scale.value)
                                .background(BlinkitGreen, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Approved", tint = Color.White, modifier = Modifier.size(32.dp))
                        }

                        Text(
                            "Work Proof Approved & Payment Settled!",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = BlinkitGreenDark,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            "Share this 4-Digit Completion OTP with ${order.riderName} to finalize the job and activate your warranty card.",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )

                        // Big OTP Display Box
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight),
                            border = BorderStroke(2.dp, BlinkitYellowDark)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("COMPLETION OTP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                Text(
                                    order.otpCode,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace,
                                    color = BlinkitDark,
                                    letterSpacing = 8.sp
                                )
                                Text("Payment Status: PAID • OTP Unlocked", fontSize = 9.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 30-Day Warranty Badge
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = BlinkitGreenLight),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(20.dp))
                                Column {
                                    Text("30-Day Free Rework Guarantee Activated", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                                    Text("Any issues within 30 days are serviced with zero visit fee.", fontSize = 9.sp, color = BlinkitTextPrimary)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Done", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color.White else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
            color = if (isSelected) BlinkitTextPrimary else BlinkitTextSecondary
        )
    }
}

/**
 * Dialog for the Technician to record a 15-30s video proof, mark checklist,
 * log replaced parts, and submit for client approval.
 */
@Composable
fun TechnicianWorkProofRecordingDialog(
    order: OrderItem,
    onSubmitProof: (proof: WorkProofRecord) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isRecording by remember { mutableStateOf(false) }
    var recordingTimerSec by remember { mutableStateOf(0) }
    var hasRecorded by remember { mutableStateOf(false) }
    var isSavingToPhone by remember { mutableStateOf(false) }
    var isSavedToPhone by remember { mutableStateOf(false) }
    var showCameraXLiveRecorder by remember { mutableStateOf(false) }
    var savedPhonePath by remember {
        mutableStateOf("/storage/emulated/0/DCIM/QuickIt_Service_Proofs/VID_PRF_${System.currentTimeMillis()}.mp4")
    }

    var remarksText by remember { mutableStateOf("Full load test verified. Checked capacitor, pressure levels, and sanitized air intake.") }
    val checklistOptions = listOf(
        "Load test & power draw verified under operating conditions",
        "Zero leakage / vibration inspection passed",
        "Internal coils & components sanitized with high-pressure steam",
        "Thermostat & cooling/heating cycle verified at target temperature"
    )
    val checkedState = remember { mutableStateMapOf<String, Boolean>() }
    LaunchedEffect(Unit) {
        checklistOptions.forEach { checkedState[it] = true }
    }

    var replacedPartsList by remember {
        mutableStateOf(
            listOf(
                ReplacedSparePart(partName = "Heavy Duty Dual Capacitor (45+5µF)", partNumber = "CAP-AC-8841", warrantyMonths = 12, price = 350.0, emoji = "🔋"),
                ReplacedSparePart(partName = "High-Flow Brass Drain Valve", partNumber = "VLV-BR-1029", warrantyMonths = 6, price = 180.0, emoji = "🔧")
            )
        )
    }

    // Recording simulation timer
    LaunchedEffect(isRecording) {
        while (isRecording) {
            delay(1000)
            recordingTimerSec++
            if (recordingTimerSec >= 24) {
                isRecording = false
                hasRecorded = true
            }
        }
    }

    // When recording finishes, save directly to phone device storage (DCIM/QuickIt_Service_Proofs)
    LaunchedEffect(hasRecorded) {
        if (hasRecorded) {
            isSavingToPhone = true
            delay(300)
            try {
                val file = LocalStorageVideoManager.saveTechnicianVideoProofToLocalStorage(
                    context = context,
                    orderId = order.id,
                    serviceName = order.items.firstOrNull()?.service?.name ?: "Service"
                )
                savedPhonePath = file.absolutePath
                Toast.makeText(context, "💾 Video saved to phone storage: ${file.name}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                savedPhonePath = "/storage/emulated/0/DCIM/QuickIt_Service_Proofs/VID_PROOF_${order.orderNumber}.mp4"
            }
            isSavingToPhone = false
            isSavedToPhone = true
        } else {
            isSavedToPhone = false
            isSavingToPhone = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        if (showCameraXLiveRecorder) {
            CameraXVideoRecordingComponent(
                orderId = order.orderNumber,
                onVideoSaved = { result ->
                    savedPhonePath = result.absolutePath
                    hasRecorded = true
                    isSavedToPhone = true
                    showCameraXLiveRecorder = false
                },
                onCancel = { showCameraXLiveRecorder = false }
            )
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.92f)
                    .padding(vertical = 10.dp)
                    .testTag("technician_work_proof_dialog"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
            ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("📹", fontSize = 24.sp)
                        Column {
                            Text("Record Work Completion Proof", fontSize = 15.sp, fontWeight = FontWeight.Black, color = BlinkitTextPrimary)
                            Text("Mandatory for OTP Release & Warranty Activation", fontSize = 10.sp, color = BlinkitTextSecondary)
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = BlinkitGreenLight,
                            border = BorderStroke(1.dp, BlinkitGreen),
                            modifier = Modifier.clickable { showCameraXLiveRecorder = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(12.dp))
                                Text("CameraX HD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                            }
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                        }
                    }
                }

                // Viewfinder / Camera Simulation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isRecording && !hasRecorded) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(36.dp))
                            Text("Tap Record Button Below to Capture Video (15-30s)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        }
                    } else if (isRecording) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("📹", fontSize = 36.sp)
                            Text("Recording Live Job Proof...", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Show operating status, meter reading & serial numbers", color = Color(0xFF4ADE80), fontSize = 10.sp)
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4ADE80), modifier = Modifier.size(36.dp))
                            Text("✓ 24-Second Video Proof Captured", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("GPS & Timestamp Metadata Watermarked", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                        }
                    }

                    // Watermark Overlays
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isRecording) Color.Red else if (hasRecorded) Color(0xFF4ADE80) else Color.Gray)
                            )
                            Text(
                                if (isRecording) "RECORDING: 0:${String.format("%02d", recordingTimerSec)}" else if (hasRecorded) "CAPTURED (0:24)" else "READY",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text("📍 12.9716° N, 77.5946° E", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Action Record / Re-record button on bottom
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!isRecording && !hasRecorded) {
                            Button(
                                onClick = {
                                    recordingTimerSec = 0
                                    isRecording = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.FiberManualRecord, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Start 24s Camera Recording", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        } else if (isRecording) {
                            Button(
                                onClick = {
                                    isRecording = false
                                    hasRecorded = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("Stop & Keep Video (0:${String.format("%02d", recordingTimerSec)})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    hasRecorded = false
                                    recordingTimerSec = 0
                                    isRecording = true
                                },
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Retake Video", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }

                // Phone Storage Status Banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when {
                        isSavedToPhone -> Color(0xFFF0FDF4)
                        isSavingToPhone -> Color(0xFFFEF3C7)
                        isRecording -> Color(0xFFFEF2F2)
                        else -> BlinkitSurfaceVariant
                    },
                    border = BorderStroke(
                        1.dp,
                        when {
                            isSavedToPhone -> BlinkitGreen
                            isSavingToPhone -> BlinkitYellowDark
                            isRecording -> BlinkitRed
                            else -> BlinkitBorder
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            when {
                                isSavedToPhone -> "💾"
                                isSavingToPhone -> "⏳"
                                isRecording -> "🔴"
                                else -> "📱"
                            },
                            fontSize = 16.sp
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                when {
                                    isSavedToPhone -> "SAVED TO PHONE STORAGE (DCIM)"
                                    isSavingToPhone -> "SAVING VIDEO TO DEVICE GALLERY..."
                                    isRecording -> "RECORDING DIRECTLY TO DEVICE CACHE"
                                    else -> "LOCAL PHONE STORAGE REQUIREMENT"
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = when {
                                    isSavedToPhone -> BlinkitGreenDark
                                    isSavingToPhone -> Color(0xFFB45309)
                                    isRecording -> BlinkitRed
                                    else -> BlinkitTextSecondary
                                }
                            )
                            Text(
                                when {
                                    isSavedToPhone -> "Path: $savedPhonePath (14.8 MB • 1080p FHD)"
                                    isSavingToPhone -> "Writing MP4 & synchronizing media store indices..."
                                    isRecording -> "Watermarking timestamp & GPS coordinates onto live feed..."
                                    else -> "Video proof will be saved to device DCIM folder before duty release."
                                },
                                fontSize = 10.sp,
                                color = BlinkitTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Checklist & Parts Tabs
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text("Task Checklist Completed On-Site:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                    }

                    items(checklistOptions) { task ->
                        val isChecked = checkedState[task] ?: false
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isChecked) BlinkitGreenLight else BlinkitSurfaceVariant)
                                .clickable { checkedState[task] = !isChecked }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checkedState[task] = it },
                                colors = CheckboxDefaults.colors(checkedColor = BlinkitGreen)
                            )
                            Text(task, fontSize = 10.sp, color = BlinkitTextPrimary, fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal)
                        }
                    }

                    item {
                        Text("Technician Work Remarks:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                        OutlinedTextField(
                            value = remarksText,
                            onValueChange = { remarksText = it },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = false,
                            maxLines = 2
                        )
                    }
                }

                // Submit to Client Button (Disabled until video is recorded and saved to phone)
                Button(
                    onClick = {
                        val record = WorkProofRecord(
                            videoTitle = "${order.items.firstOrNull()?.service?.name ?: "Service"} Verification Video",
                            videoDurationSec = if (recordingTimerSec > 0) recordingTimerSec else 24,
                            completedChecklist = checklistOptions.filter { checkedState[it] == true },
                            replacedParts = replacedPartsList,
                            technicianRemarks = remarksText,
                            status = WorkProofStatus.SUBMITTED,
                            isSavedToPhoneStorage = true,
                            savedLocalPhonePath = savedPhonePath,
                            fileSizeBytes = 14_857_600L,
                            storageFolder = "DCIM/QuickIt_Service_Proofs"
                        )
                        onSubmitProof(record)
                        onDismiss()
                    },
                    enabled = hasRecorded && isSavedToPhone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_work_proof_to_client_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BlinkitGreen,
                        disabledContainerColor = BlinkitSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        if (isSavedToPhone) Icons.Default.Save else Icons.Default.Videocam,
                        contentDescription = null,
                        tint = if (hasRecorded && isSavedToPhone) Color.White else BlinkitTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        when {
                            !hasRecorded -> "Record 24s Video to Save & Enable"
                            isSavingToPhone -> "Saving to Phone Storage..."
                            else -> "Save to Phone & Submit Proof to Customer"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (hasRecorded && isSavedToPhone) Color.White else BlinkitTextMuted
                    )
                }
            }
        }
        }
    }
}

/**
 * High-Priority Banner & Floating Toast on Customer Dashboard reminding the customer
 * to ensure the technician uploads the proof-of-work video before leaving the premises.
 */
@Composable
fun ServiceDoneWorkProofReminderBanner(
    order: OrderItem,
    onReviewProof: () -> Unit,
    onRemindTechnician: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "work_proof_pulse")
    val pulseBorderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_border"
    )

    val proofStatus = order.workProof?.status ?: WorkProofStatus.NOT_SUBMITTED
    val isProofUploaded = proofStatus == WorkProofStatus.SUBMITTED || proofStatus == WorkProofStatus.APPROVED_BY_CLIENT

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("service_done_proof_reminder_banner"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isProofUploaded) Color(0xFFF0FDF4) else Color(0xFFFFFBEB)
        ),
        border = BorderStroke(
            2.dp,
            if (isProofUploaded) BlinkitGreen else BlinkitYellowDark.copy(alpha = pulseBorderAlpha)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row with Pulsing Warning / Verified Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isProofUploaded) BlinkitGreenLight else BlinkitYellowLight)
                            .border(1.5.dp, if (isProofUploaded) BlinkitGreen else BlinkitYellowDark, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isProofUploaded) Icons.Default.CheckCircle else Icons.Default.Videocam,
                            contentDescription = null,
                            tint = if (isProofUploaded) BlinkitGreenDark else BlinkitDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                if (isProofUploaded) "PROOF VIDEO READY TO REVIEW" else "SERVICE MARKED DONE • ACTION REQUIRED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isProofUploaded) BlinkitGreenDark else Color(0xFFB45309),
                                letterSpacing = 0.5.sp
                            )
                            Surface(
                                color = if (isProofUploaded) BlinkitGreen else BlinkitYellow,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    if (isProofUploaded) "READY" else "IMPORTANT",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isProofUploaded) Color.White else BlinkitDark,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            if (isProofUploaded)
                                "Technician ${order.riderName} submitted proof video"
                            else
                                "Ask ${order.riderName} for Proof Video before leaving!",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitTextPrimary
                        )
                    }
                }
            }

            // Explanatory Note with 30-day Warranty Protection info
            Surface(
                color = if (isProofUploaded) Color.White.copy(alpha = 0.8f) else Color(0xFFFEF3C7),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(0.5.dp, if (isProofUploaded) BlinkitGreenLight else BlinkitYellow)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(if (isProofUploaded) "🛡️" else "⚠️", fontSize = 16.sp)
                    Text(
                        if (isProofUploaded)
                            "Review the 15-30s video showing running appliance & parts replaced to activate your 30-Day Free Rework Warranty."
                        else
                            "Please ask the technician to upload their proof-of-work video on their device before leaving your home. Do NOT share the completion OTP until proof is verified!",
                        fontSize = 11.sp,
                        color = if (isProofUploaded) BlinkitTextPrimary else Color(0xFF78350F),
                        lineHeight = 15.sp,
                        fontWeight = if (isProofUploaded) FontWeight.Normal else FontWeight.Medium
                    )
                }
            }

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isProofUploaded) {
                    OutlinedButton(
                        onClick = onRemindTechnician,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, BlinkitYellowDark),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BlinkitDark)
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Prompt Tech", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onReviewProof,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(if (isProofUploaded) 1f else 1.3f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isProofUploaded) BlinkitGreenDark else BlinkitGreen
                    )
                ) {
                    Icon(
                        if (isProofUploaded) Icons.Default.PlayCircle else Icons.Default.Visibility,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        if (isProofUploaded) "Inspect Video & Approve" else "View Proof Status",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * Toast / Snackbar-style floating overlay for immediate reminder when service is marked Done.
 */
@Composable
fun ServiceDonePromptToastBar(
    technicianName: String,
    onReviewClick: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .shadow(12.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        color = BlinkitDark,
        border = BorderStroke(1.5.dp, BlinkitYellow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(BlinkitYellow),
                    contentAlignment = Alignment.Center
                ) {
                    Text("📹", fontSize = 16.sp)
                }

                Column {
                    Text(
                        "Service Marked Done!",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitYellow
                    )
                    Text(
                        "Prompt $technicianName to upload proof video before leaving.",
                        fontSize = 11.sp,
                        color = Color.White,
                        lineHeight = 14.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    onClick = onReviewClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Check Proof", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
