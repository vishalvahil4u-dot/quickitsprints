package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.BlinkitRepository
import com.example.data.TechnicianPartnerSession
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class DemoTechProfile(
    val name: String,
    val phone: String,
    val speciality: String,
    val hub: String,
    val emoji: String,
    val rating: Double
)

data class TradeCategoryOption(
    val id: String,
    val name: String,
    val emoji: String,
    val defaultSpeciality: String,
    val defaultTools: List<String>
)

enum class PartnerAuthMode {
    SIGN_IN,
    REGISTER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TechnicianOtpLoginScreen(
    repository: BlinkitRepository,
    onLoginSuccess: (TechnicianPartnerSession) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var authMode by remember { mutableStateOf(PartnerAuthMode.SIGN_IN) }

    // LOGIN STATE
    var loginPhone by remember { mutableStateOf("9845012345") }
    var loginOtpStep by remember { mutableStateOf(false) }
    var loginEnteredOtp by remember { mutableStateOf("") }
    var loginGeneratedOtp by remember { mutableStateOf("4829") }

    // Anti-Bot Human Verification State for Login
    var loginCaptchaAnswer by remember { mutableStateOf("") }
    var loginCaptchaPassed by remember { mutableStateOf(true) }

    // Brute Force & Rate Limit Protection for OTP
    var failedOtpAttempts by remember { mutableStateOf(0) }
    var isOtpLockedOut by remember { mutableStateOf(false) }
    var otpLockoutSeconds by remember { mutableStateOf(0) }

    // REGISTRATION FORM STATE
    var regFullName by remember { mutableStateOf("Rajesh Kumar") }
    var regPhone by remember { mutableStateOf("9812345678") }
    var regSelectedTradeId by remember { mutableStateOf("cat_plumbing") }
    var regSpeciality by remember { mutableStateOf("Certified Master Plumber") }
    var regExperienceYears by remember { mutableStateOf("3-5 Years") }
    var regSelectedHub by remember { mutableStateOf("Indiranagar Hub #14") }
    var regVehicleType by remember { mutableStateOf("Electric Scooter (EV)") }
    var regVehicleNumber by remember { mutableStateOf("KA 05 MN 4820") }
    var regGovtIdNumber by remember { mutableStateOf("8921-4432-1092") }
    var regSelectedTools by remember { mutableStateOf(setOf("Pipe Wrench Pro", "Laser Leak Detector", "O-Ring Seal Kit")) }

    var regOtpStep by remember { mutableStateOf(false) }
    var regEnteredOtp by remember { mutableStateOf("") }
    var regGeneratedOtp by remember { mutableStateOf("3819") }
    var regSuccessDialogSession by remember { mutableStateOf<TechnicianPartnerSession?>(null) }

    // Shared State
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSmsBanner by remember { mutableStateOf(false) }
    var showSecurityInspectorDialog by remember { mutableStateOf(false) }

    // Resend countdown timer
    var resendTimer by remember { mutableStateOf(30) }
    var isTimerActive by remember { mutableStateOf(false) }

    val accentEmerald = Color(0xFF10B981)
    val securityCyan = Color(0xFF38BDF8)

    // Lockout countdown timer
    LaunchedEffect(isOtpLockedOut, otpLockoutSeconds) {
        if (isOtpLockedOut && otpLockoutSeconds > 0) {
            delay(1000L)
            otpLockoutSeconds -= 1
        } else if (otpLockoutSeconds <= 0 && isOtpLockedOut) {
            isOtpLockedOut = false
            failedOtpAttempts = 0
            errorMessage = null
        }
    }

    LaunchedEffect(isTimerActive, resendTimer) {
        if (isTimerActive && resendTimer > 0) {
            delay(1000L)
            resendTimer -= 1
        } else if (resendTimer <= 0) {
            isTimerActive = false
        }
    }

    val demoTechs = remember {
        listOf(
            DemoTechProfile("Ramesh Sharma", "9845012345", "Plumbing Lead", "Indiranagar Hub #14", "👨🏽‍🔧", 4.96),
            DemoTechProfile("Vikas Sundaram", "9876543210", "Master Electrician", "Koramangala Hub #09", "⚡", 4.92),
            DemoTechProfile("Priya Nair", "9123456789", "Deep Clean Pro", "Indiranagar Hub #14", "✨", 4.98),
            DemoTechProfile("Karthik Raja", "9988776655", "AC & HVAC Tech", "HSR Layout Hub #02", "❄️", 4.89)
        )
    }

    val tradeCategories = remember {
        listOf(
            TradeCategoryOption("cat_plumbing", "Plumbing", "👨🏽‍🔧", "Certified Plumbing Specialist", listOf("Pipe Wrench Pro", "Laser Leak Detector", "O-Ring Seal Kit", "Pipe Threader")),
            TradeCategoryOption("cat_electric", "Electrical", "⚡", "Master Certified Electrician", listOf("Fluke Multimeter", "Insulated VDE Set", "Circuit Tracer", "Wire Stripper")),
            TradeCategoryOption("cat_appliance", "AC & Appliance", "❄️", "HVAC & Appliance Specialist", listOf("Refrigerant Manifold", "Digital Thermometer", "Fin Straightener", "Vacuum Pump")),
            TradeCategoryOption("cat_cleaning", "Deep Clean", "✨", "Sanitization & Hygiene Pro", listOf("HEPA Steam Vacuum", "UV Sterilizer", "Bio-Enzyme Pack", "Surface Polisher")),
            TradeCategoryOption("cat_carpentry", "Carpentry", "🪚", "Precision Woodwork Expert", listOf("Laser Precision Level", "Jigsaw Pro", "Pocket Hole Jig", "Chisel Set")),
            TradeCategoryOption("cat_painting", "Painting", "🎨", "Wall Finish & Paint Specialist", listOf("Airless Paint Sprayer", "Moisture Meter", "Surface Sander", "Edge Masker"))
        )
    }

    val hubOptions = remember {
        listOf("Indiranagar Hub #14", "Koramangala Hub #09", "HSR Layout Hub #02", "Whitefield Hub #05", "Jayanagar Hub #07")
    }

    val vehicleOptions = remember {
        listOf("Electric Scooter (EV)", "Petrol Motorcycle / Scooter", "Service Cargo Van", "Bicycle Express")
    }

    val experienceOptions = remember {
        listOf("1-2 Years", "3-5 Years", "5+ Years Master Pro")
    }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E293B),
                        BlinkitBackground
                    ),
                    startY = 0f,
                    endY = 700f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: QuickIt Partner Pro Badge + Security Attestation Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(BlinkitYellow, BlinkitYellowDark)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (authMode == PartnerAuthMode.REGISTER) "📝" else "👨🏽‍🔧",
                            fontSize = 24.sp
                        )
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("QuickIt Pro", color = BlinkitYellow, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            Surface(color = BlinkitGreen, shape = RoundedCornerShape(4.dp)) {
                                Text("SECURED", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                            }
                        }
                        Text("Partner & Fleet Onboarding", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }

                // Security Telemetry Pill
                Surface(
                    color = securityCyan.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(100.dp),
                    border = BorderStroke(1.dp, securityCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.clickable { showSecurityInspectorDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = securityCyan, modifier = Modifier.size(12.dp))
                        Text("SIM Slot 1 Bound", color = securityCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Hardware Security & Play Integrity Status Card
            Surface(
                color = Color(0xFF1E293B).copy(alpha = 0.85f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.PhonelinkLock, contentDescription = null, tint = accentEmerald, modifier = Modifier.size(16.dp))
                        Column {
                            Text("Play Integrity: MEETS_STRONG_INTEGRITY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("Hub #14 Geofence: 0.6 km (Radar Active)", color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp)
                        }
                    }
                    Surface(color = accentEmerald.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                        Text("PASSED", color = accentEmerald, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }

            // Auth Mode Toggle (Sign In vs Register Form)
            Surface(
                color = Color(0xFF1E293B).copy(alpha = 0.9f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                ) {
                    // Sign In Tab
                    Surface(
                        color = if (authMode == PartnerAuthMode.SIGN_IN) BlinkitGreen else Color.Transparent,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                authMode = PartnerAuthMode.SIGN_IN
                                errorMessage = null
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "⚡ Partner Login",
                                color = if (authMode == PartnerAuthMode.SIGN_IN) Color.White else Color.White.copy(alpha = 0.7f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Register Tab
                    Surface(
                        color = if (authMode == PartnerAuthMode.REGISTER) BlinkitGreen else Color.Transparent,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                authMode = PartnerAuthMode.REGISTER
                                errorMessage = null
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "📝 Register New Pro",
                                color = if (authMode == PartnerAuthMode.REGISTER) Color.White else Color.White.copy(alpha = 0.7f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // MAIN CONTAINER CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                border = BorderStroke(1.dp, BlinkitBorder)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // RATE LIMIT LOCKOUT BANNER
                    if (isOtpLockedOut) {
                        Surface(
                            color = BlinkitRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BlinkitRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.LockClock, contentDescription = null, tint = BlinkitRed, modifier = Modifier.size(18.dp))
                                    Text("OTP RATE LIMIT COOLDOWN", color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                                Text("3 wrong OTP attempts. Temporary cooldown to prevent SIM hijack.", color = BlinkitTextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center)
                                Text("Unlock in ${otpLockoutSeconds}s", color = BlinkitDark, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    if (authMode == PartnerAuthMode.SIGN_IN) {
                        // ==========================================
                        // MODE 1: EXISTING PARTNER SIGN-IN
                        // ==========================================
                        AnimatedContent(
                            targetState = loginOtpStep,
                            label = "LoginOtpStepTransition"
                        ) { isOtpScreen ->
                            if (!isOtpScreen) {
                                // STEP 1: MOBILE NUMBER INPUT
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            "Technician Login",
                                            color = BlinkitTextPrimary,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "Enter registered mobile to receive secure 4-digit SMS OTP code.",
                                            color = BlinkitTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }

                                    // Mobile Input Field
                                    OutlinedTextField(
                                        value = loginPhone,
                                        onValueChange = { input ->
                                            val digitsOnly = input.filter { it.isDigit() }
                                            if (digitsOnly.length <= 10) {
                                                loginPhone = digitsOnly
                                                errorMessage = null
                                            }
                                        },
                                        enabled = !isOtpLockedOut,
                                        leadingIcon = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                                            ) {
                                                Text("🇮🇳", fontSize = 16.sp)
                                                Text("+91", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BlinkitTextPrimary)
                                                Box(modifier = Modifier.height(18.dp).width(1.dp).background(BlinkitBorder))
                                            }
                                        },
                                        trailingIcon = {
                                            if (loginPhone.isNotEmpty()) {
                                                IconButton(onClick = { loginPhone = "" }) {
                                                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = BlinkitTextSecondary, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        },
                                        placeholder = { Text("10-digit mobile number", color = BlinkitTextMuted, fontSize = 13.sp) },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = BlinkitGreen,
                                            unfocusedBorderColor = BlinkitBorder,
                                            focusedContainerColor = BlinkitSurfaceVariant,
                                            unfocusedContainerColor = BlinkitSurfaceVariant
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Anti-Bot Human Challenge
                                    Surface(
                                        color = if (loginCaptchaPassed) BlinkitGreenLight else BlinkitSurfaceVariant,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (loginCaptchaPassed) BlinkitGreen else BlinkitBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    if (loginCaptchaPassed) Icons.Default.CheckCircle else Icons.Default.SmartToy,
                                                    contentDescription = null,
                                                    tint = if (loginCaptchaPassed) BlinkitGreenDark else BlinkitTextSecondary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Text(
                                                    if (loginCaptchaPassed) "Anti-Bot Verification: Cleared" else "Tap to verify human partner",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (loginCaptchaPassed) BlinkitGreenDark else BlinkitTextPrimary
                                                )
                                            }
                                            if (!loginCaptchaPassed) {
                                                Button(
                                                    onClick = { loginCaptchaPassed = true },
                                                    shape = RoundedCornerShape(6.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Verify", fontSize = 10.sp, color = Color.White)
                                                }
                                            }
                                        }
                                    }

                                    errorMessage?.let { err ->
                                        Text(err, color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    // Demo Technicians Quick Select
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("⚡ Quick Select Verified Partner:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            items(demoTechs) { tech ->
                                                val isSelected = loginPhone == tech.phone
                                                Surface(
                                                    color = if (isSelected) BlinkitYellowLight else BlinkitSurfaceVariant,
                                                    shape = RoundedCornerShape(10.dp),
                                                    border = BorderStroke(1.dp, if (isSelected) BlinkitYellowDark else BlinkitBorder),
                                                    modifier = Modifier.clickable {
                                                        loginPhone = tech.phone
                                                        errorMessage = null
                                                    }
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        Text(tech.emoji, fontSize = 14.sp)
                                                        Column {
                                                            Text(tech.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                                            Text("${tech.speciality} • ${tech.phone}", fontSize = 9.sp, color = BlinkitTextSecondary)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Send OTP Button
                                    Button(
                                        onClick = {
                                            if (isOtpLockedOut) return@Button
                                            if (loginPhone.length < 10) {
                                                errorMessage = "Please enter a valid 10-digit mobile number"
                                            } else {
                                                isLoading = true
                                                errorMessage = null
                                                coroutineScope.launch {
                                                    delay(400L)
                                                    val code = repository.sendTechnicianOtp(loginPhone)
                                                    loginGeneratedOtp = code
                                                    isLoading = false
                                                    loginOtpStep = true
                                                    showSmsBanner = true
                                                    resendTimer = 30
                                                    isTimerActive = true
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark),
                                        enabled = !isLoading && !isOtpLockedOut
                                    ) {
                                        if (isLoading) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        } else {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text("Get OTP via SMS", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            } else {
                                // STEP 2: OTP VERIFICATION
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Verify OTP Code", color = BlinkitTextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                            Text("Sent to +91 $loginPhone (SIM 1 Verified)", color = BlinkitGreenDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                        TextButton(onClick = { loginOtpStep = false; loginEnteredOtp = ""; errorMessage = null }) {
                                            Text("Change", color = BlinkitTextSecondary, fontSize = 12.sp)
                                        }
                                    }

                                    // SMS Banner
                                    if (showSmsBanner) {
                                        SmsAutoDetectionBanner(
                                            otpCode = loginGeneratedOtp,
                                            onAutoFill = {
                                                loginEnteredOtp = loginGeneratedOtp
                                                errorMessage = null
                                            }
                                        )
                                    }

                                    // Visual 4-Digit Boxes
                                    OtpVisualBoxes(enteredOtp = loginEnteredOtp)

                                    // Input Field
                                    OutlinedTextField(
                                        value = loginEnteredOtp,
                                        onValueChange = { input ->
                                            if (isOtpLockedOut) return@OutlinedTextField
                                            val digits = input.filter { it.isDigit() }.take(4)
                                            loginEnteredOtp = digits
                                            errorMessage = null
                                            if (digits.length == 4) {
                                                val verified = repository.verifyTechnicianOtp(loginPhone, digits)
                                                if (verified) {
                                                    repository.activeTechnicianSession.value?.let { onLoginSuccess(it) }
                                                } else {
                                                    failedOtpAttempts += 1
                                                    if (failedOtpAttempts >= 3) {
                                                        isOtpLockedOut = true
                                                        otpLockoutSeconds = 45
                                                        errorMessage = "Security Alert: 3 failed attempts! Rate limit locked."
                                                    } else {
                                                        errorMessage = "Incorrect OTP. Attempt $failedOtpAttempts of 3. Try $loginGeneratedOtp"
                                                    }
                                                }
                                            }
                                        },
                                        enabled = !isOtpLockedOut,
                                        placeholder = { Text("Type 4-digit code", fontSize = 13.sp) },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    errorMessage?.let { err ->
                                        Text(err, color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    ResendTimerRow(
                                        isTimerActive = isTimerActive,
                                        resendTimer = resendTimer,
                                        demoCode = loginGeneratedOtp,
                                        onResend = {
                                            val newCode = repository.sendTechnicianOtp(loginPhone)
                                            loginGeneratedOtp = newCode
                                            resendTimer = 30
                                            isTimerActive = true
                                            showSmsBanner = true
                                        }
                                    )

                                    Button(
                                        onClick = {
                                            if (isOtpLockedOut) return@Button
                                            if (loginEnteredOtp.length < 4) {
                                                errorMessage = "Please enter 4-digit OTP"
                                            } else {
                                                val verified = repository.verifyTechnicianOtp(loginPhone, loginEnteredOtp)
                                                if (verified) {
                                                    repository.activeTechnicianSession.value?.let { onLoginSuccess(it) }
                                                } else {
                                                    failedOtpAttempts += 1
                                                    if (failedOtpAttempts >= 3) {
                                                        isOtpLockedOut = true
                                                        otpLockoutSeconds = 45
                                                        errorMessage = "Security Alert: 3 failed attempts! Rate limit locked."
                                                    } else {
                                                        errorMessage = "Incorrect OTP code. Try $loginGeneratedOtp"
                                                    }
                                                }
                                            }
                                        },
                                        enabled = !isOtpLockedOut,
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                                            Text("Verify & Start Partner Duty", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // ==========================================
                        // MODE 2: TECHNICIAN REGISTRATION FORM
                        // ==========================================
                        AnimatedContent(
                            targetState = regOtpStep,
                            label = "RegOtpStepTransition"
                        ) { isRegOtpScreen ->
                            if (!isRegOtpScreen) {
                                // REGISTRATION STEP 1: FORM FIELDS
                                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            "Technician Registration Form",
                                            color = BlinkitTextPrimary,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "Apply to become a verified QuickIt 10-Minute Service Pro with daily instant payouts.",
                                            color = BlinkitTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }

                                    // Full Name Field
                                    OutlinedTextField(
                                        value = regFullName,
                                        onValueChange = { regFullName = it; errorMessage = null },
                                        label = { Text("Full Name (as per Govt ID)", fontSize = 12.sp) },
                                        leadingIcon = {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = BlinkitTextSecondary, modifier = Modifier.size(18.dp))
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Mobile Number Field
                                    OutlinedTextField(
                                        value = regPhone,
                                        onValueChange = { input ->
                                            val digits = input.filter { it.isDigit() }
                                            if (digits.length <= 10) {
                                                regPhone = digits
                                                errorMessage = null
                                            }
                                        },
                                        label = { Text("Mobile Number (for OTP verification)", fontSize = 12.sp) },
                                        leadingIcon = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                                            ) {
                                                Text("🇮🇳", fontSize = 16.sp)
                                                Text("+91", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BlinkitTextPrimary)
                                                Box(modifier = Modifier.height(16.dp).width(1.dp).background(BlinkitBorder))
                                            }
                                        },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Select Trade / Category
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Primary Trade & Skillset:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            items(tradeCategories) { trade ->
                                                val isSelected = regSelectedTradeId == trade.id
                                                Surface(
                                                    color = if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant,
                                                    shape = RoundedCornerShape(10.dp),
                                                    border = BorderStroke(1.dp, if (isSelected) BlinkitGreen else BlinkitBorder),
                                                    modifier = Modifier.clickable {
                                                        regSelectedTradeId = trade.id
                                                        regSpeciality = trade.defaultSpeciality
                                                        regSelectedTools = trade.defaultTools.take(3).toSet()
                                                    }
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        Text(trade.emoji, fontSize = 16.sp)
                                                        Text(
                                                            trade.name,
                                                            fontSize = 12.sp,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                            color = if (isSelected) BlinkitGreenDark else BlinkitTextPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Speciality Sub-Title
                                    OutlinedTextField(
                                        value = regSpeciality,
                                        onValueChange = { regSpeciality = it },
                                        label = { Text("Professional Title / Speciality", fontSize = 12.sp) },
                                        leadingIcon = {
                                            Icon(Icons.Default.Work, contentDescription = null, tint = BlinkitTextSecondary, modifier = Modifier.size(18.dp))
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    // Nearest Dark Store Hub
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Base Dark Store Hub (10-Min Dispatch Zone):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            items(hubOptions) { hub ->
                                                val isSelected = regSelectedHub == hub
                                                Surface(
                                                    color = if (isSelected) BlinkitYellowLight else BlinkitSurfaceVariant,
                                                    shape = RoundedCornerShape(8.dp),
                                                    border = BorderStroke(1.dp, if (isSelected) BlinkitYellowDark else BlinkitBorder),
                                                    modifier = Modifier.clickable { regSelectedHub = hub }
                                                ) {
                                                    Text(
                                                        hub,
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isSelected) BlinkitDark else BlinkitTextPrimary,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Vehicle & Logistics
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Vehicle Type:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                            var expandedVehicle by remember { mutableStateOf(false) }
                                            Surface(
                                                color = BlinkitSurfaceVariant,
                                                shape = RoundedCornerShape(10.dp),
                                                border = BorderStroke(1.dp, BlinkitBorder),
                                                modifier = Modifier.fillMaxWidth().clickable { expandedVehicle = !expandedVehicle }
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(regVehicleType, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                                }
                                                DropdownMenu(
                                                    expanded = expandedVehicle,
                                                    onDismissRequest = { expandedVehicle = false }
                                                ) {
                                                    vehicleOptions.forEach { v ->
                                                        DropdownMenuItem(
                                                            text = { Text(v, fontSize = 12.sp) },
                                                            onClick = { regVehicleType = v; expandedVehicle = false }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Vehicle Reg No:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                            OutlinedTextField(
                                                value = regVehicleNumber,
                                                onValueChange = { regVehicleNumber = it.uppercase() },
                                                placeholder = { Text("KA 05 MN 4820", fontSize = 11.sp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }

                                    // Experience Level & Masked Aadhaar / Skill Certificate ID
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Experience:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                            var expandedExp by remember { mutableStateOf(false) }
                                            Surface(
                                                color = BlinkitSurfaceVariant,
                                                shape = RoundedCornerShape(10.dp),
                                                border = BorderStroke(1.dp, BlinkitBorder),
                                                modifier = Modifier.fillMaxWidth().clickable { expandedExp = !expandedExp }
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(regExperienceYears, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                                }
                                                DropdownMenu(
                                                    expanded = expandedExp,
                                                    onDismissRequest = { expandedExp = false }
                                                ) {
                                                    experienceOptions.forEach { exp ->
                                                        DropdownMenuItem(
                                                            text = { Text(exp, fontSize = 12.sp) },
                                                            onClick = { regExperienceYears = exp; expandedExp = false }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("Aadhaar / UIDAI:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                                                Text("Masked", fontSize = 9.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                                            }
                                            OutlinedTextField(
                                                value = regGovtIdNumber,
                                                onValueChange = { regGovtIdNumber = it },
                                                placeholder = { Text("XXXX-XXXX-1092", fontSize = 11.sp) },
                                                singleLine = true,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }

                                    // Calibrated Toolkits Selection
                                    val currentTradeTools = tradeCategories.find { it.id == regSelectedTradeId }?.defaultTools ?: emptyList()
                                    if (currentTradeTools.isNotEmpty()) {
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("Issued Toolkits to Carry (Checked at Dark Store Hub):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                items(currentTradeTools) { tool ->
                                                    val isSelected = regSelectedTools.contains(tool)
                                                    Surface(
                                                        color = if (isSelected) BlinkitYellowLight else BlinkitSurfaceVariant,
                                                        shape = RoundedCornerShape(8.dp),
                                                        border = BorderStroke(1.dp, if (isSelected) BlinkitYellowDark else BlinkitBorder),
                                                        modifier = Modifier.clickable {
                                                            regSelectedTools = if (isSelected) regSelectedTools - tool else regSelectedTools + tool
                                                        }
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                        ) {
                                                            Text(if (isSelected) "✓" else "+", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (isSelected) BlinkitDark else BlinkitTextSecondary)
                                                            Text(tool, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = BlinkitTextPrimary)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    errorMessage?.let { err ->
                                        Text(err, color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    // Next: Verify Phone via OTP Button
                                    Button(
                                        onClick = {
                                            if (regFullName.isBlank()) {
                                                errorMessage = "Please enter technician full name"
                                            } else if (regPhone.length < 10) {
                                                errorMessage = "Please enter a valid 10-digit mobile number"
                                            } else {
                                                isLoading = true
                                                errorMessage = null
                                                coroutineScope.launch {
                                                    delay(400L)
                                                    val code = repository.sendTechnicianOtp(regPhone)
                                                    regGeneratedOtp = code
                                                    isLoading = false
                                                    regOtpStep = true
                                                    showSmsBanner = true
                                                    resendTimer = 30
                                                    isTimerActive = true
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark),
                                        enabled = !isLoading
                                    ) {
                                        if (isLoading) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        } else {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text("Verify Mobile via OTP", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            } else {
                                // REGISTRATION STEP 2: VERIFY OTP FOR NEW PARTNER
                                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Verify Registration OTP", color = BlinkitTextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                            Text("Verifying applicant $regFullName (+91 $regPhone)", color = BlinkitGreenDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                        TextButton(onClick = { regOtpStep = false; regEnteredOtp = ""; errorMessage = null }) {
                                            Text("Edit Form", color = BlinkitTextSecondary, fontSize = 12.sp)
                                        }
                                    }

                                    // SMS Banner
                                    if (showSmsBanner) {
                                        SmsAutoDetectionBanner(
                                            otpCode = regGeneratedOtp,
                                            onAutoFill = {
                                                regEnteredOtp = regGeneratedOtp
                                                errorMessage = null
                                            }
                                        )
                                    }

                                    // Visual 4-Digit Boxes
                                    OtpVisualBoxes(enteredOtp = regEnteredOtp)

                                    // Input Field
                                    OutlinedTextField(
                                        value = regEnteredOtp,
                                        onValueChange = { input ->
                                            val digits = input.filter { it.isDigit() }.take(4)
                                            regEnteredOtp = digits
                                            errorMessage = null
                                            if (digits.length == 4) {
                                                val verified = (digits == regGeneratedOtp || digits == "3819" || digits == "4829")
                                                if (verified) {
                                                    val session = repository.registerNewTechnician(
                                                        name = regFullName,
                                                        phone = regPhone,
                                                        speciality = regSpeciality,
                                                        categoryId = regSelectedTradeId,
                                                        darkStoreHub = regSelectedHub,
                                                        vehicleType = regVehicleType,
                                                        vehicleNumber = regVehicleNumber,
                                                        experienceYears = 3,
                                                        selectedToolkits = regSelectedTools.toList(),
                                                        governmentIdNumber = regGovtIdNumber
                                                    )
                                                    regSuccessDialogSession = session
                                                } else {
                                                    errorMessage = "Incorrect OTP code. Try $regGeneratedOtp"
                                                }
                                            }
                                        },
                                        placeholder = { Text("Type 4-digit code", fontSize = 13.sp) },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    errorMessage?.let { err ->
                                        Text(err, color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    ResendTimerRow(
                                        isTimerActive = isTimerActive,
                                        resendTimer = resendTimer,
                                        demoCode = regGeneratedOtp,
                                        onResend = {
                                            val newCode = repository.sendTechnicianOtp(regPhone)
                                            regGeneratedOtp = newCode
                                            resendTimer = 30
                                            isTimerActive = true
                                            showSmsBanner = true
                                        }
                                    )

                                    // Submit & Complete Registration Button
                                    Button(
                                        onClick = {
                                            if (regEnteredOtp.length < 4) {
                                                errorMessage = "Please enter 4-digit OTP"
                                            } else {
                                                val verified = (regEnteredOtp == regGeneratedOtp || regEnteredOtp == "3819" || regEnteredOtp == "4829")
                                                if (verified) {
                                                    val session = repository.registerNewTechnician(
                                                        name = regFullName,
                                                        phone = regPhone,
                                                        speciality = regSpeciality,
                                                        categoryId = regSelectedTradeId,
                                                        darkStoreHub = regSelectedHub,
                                                        vehicleType = regVehicleType,
                                                        vehicleNumber = regVehicleNumber,
                                                        experienceYears = 3,
                                                        selectedToolkits = regSelectedTools.toList(),
                                                        governmentIdNumber = regGovtIdNumber
                                                    )
                                                    regSuccessDialogSession = session
                                                } else {
                                                    errorMessage = "Incorrect OTP code. Try $regGeneratedOtp"
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(48.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                                            Text("Verify OTP & Complete Registration", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Partner Advantages Grid
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "QuickIt Partner Advantages:",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PartnerFeatureCard(
                        icon = "⚡",
                        title = "10-Min SLAs",
                        desc = "Dark Store Hub #14 matched jobs",
                        modifier = Modifier.weight(1f)
                    )
                    PartnerFeatureCard(
                        icon = "💰",
                        title = "Daily Payouts",
                        desc = "Instant UPI direct deposit",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PartnerFeatureCard(
                        icon = "🧰",
                        title = "Issued Toolkits",
                        desc = "Pre-calibrated gear at hubs",
                        modifier = Modifier.weight(1f)
                    )
                    PartnerFeatureCard(
                        icon = "🛡️",
                        title = "Digilocker BGV",
                        desc = "Police KYC clearance active",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Footer note
            Text(
                "QuickIt Certified Partner Network • Hardware-bound SIM Security & TLS 1.3 Encryption",
                color = BlinkitTextSecondary,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }

    // REGISTRATION SUCCESS MODAL / DIALOG WITH CRYPTOGRAPHIC DUTY PASS
    regSuccessDialogSession?.let { newSession ->
        Dialog(onDismissRequest = { /* Require action */ }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(2.dp, BlinkitGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(BlinkitGreenLight)
                            .border(2.dp, BlinkitGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🎉", fontSize = 30.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Partner Onboarded & Verified!",
                            color = BlinkitTextPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            "Cryptographic duty badge activated for Hub dispatch.",
                            color = BlinkitTextSecondary,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Partner ID Card Preview
                    Surface(
                        color = BlinkitDarkCard,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(newSession.avatarEmoji, fontSize = 24.sp)
                                    Column {
                                        Text(newSession.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(newSession.speciality, color = BlinkitYellow, fontSize = 11.sp)
                                    }
                                }
                                Surface(
                                    color = BlinkitGreen,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "KYC PASSED",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("HUB BASE", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Text(newSession.hubName, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("VEHICLE", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Text(newSession.vehicleNumber, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("SESSION ID", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Text("SEC-AES256", color = securityCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    // Button to launch dashboard
                    Button(
                        onClick = {
                            regSuccessDialogSession = null
                            onLoginSuccess(newSession)
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Enter Partner Duty Dashboard", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            Icon(Icons.Default.Check, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }

    // SECURITY INSPECTOR DIALOG
    if (showSecurityInspectorDialog) {
        Dialog(onDismissRequest = { showSecurityInspectorDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, securityCyan.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = securityCyan, modifier = Modifier.size(20.dp))
                            Text("Technician Security Attestation", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        IconButton(onClick = { showSecurityInspectorDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White.copy(alpha = 0.7f))
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                    AuditDetailRow(title = "SIM Card Slot #1 Bind", value = "+91 98450 12345 (PASS)")
                    AuditDetailRow(title = "Play Integrity API", value = "STRONG_INTEGRITY")
                    AuditDetailRow(title = "Hub Geofence Radar", value = "0.6 KM (Indiranagar Hub #14)")
                    AuditDetailRow(title = "Aadhaar UIDAI Masking", value = "XXXX-XXXX-1092")
                    AuditDetailRow(title = "Background Police KYC", value = "Cleared (Digilocker)")
                    AuditDetailRow(title = "Anti-Brute Force Lock", value = "Active (3-Attempt Threshold)")

                    Button(
                        onClick = { showSecurityInspectorDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Acknowledge & Close", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SmsAutoDetectionBanner(
    otpCode: String,
    onAutoFill: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BlinkitYellowLight,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BlinkitYellowDark),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("📲", fontSize = 20.sp)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "SMS Received: QuickIt Pro",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = BlinkitDark
                )
                Text(
                    "Your OTP verification code is $otpCode",
                    fontSize = 11.sp,
                    color = BlinkitDark
                )
            }
            Surface(
                color = BlinkitGreen,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { onAutoFill() }
            ) {
                Text(
                    "Auto-fill",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun OtpVisualBoxes(
    enteredOtp: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for (i in 0 until 4) {
            val char = enteredOtp.getOrNull(i)?.toString() ?: ""
            val isFocused = enteredOtp.length == i
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isFocused) BlinkitYellowLight else BlinkitSurfaceVariant
                    )
                    .border(
                        width = if (isFocused) 2.dp else 1.dp,
                        color = if (isFocused) BlinkitYellowDark else BlinkitBorder,
                        shape = RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = char,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    color = BlinkitTextPrimary
                )
            }
        }
    }
}

@Composable
fun ResendTimerRow(
    isTimerActive: Boolean,
    resendTimer: Int,
    demoCode: String,
    onResend: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isTimerActive) {
            Text(
                "Resend OTP in ${resendTimer}s",
                fontSize = 11.sp,
                color = BlinkitTextSecondary
            )
        } else {
            TextButton(
                onClick = onResend,
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(
                    "Resend OTP",
                    color = BlinkitGreenDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            "Demo Code: $demoCode",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitTextMuted
        )
    }
}

@Composable
fun PartnerFeatureCard(
    icon: String,
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF1E293B).copy(alpha = 0.7f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(icon, fontSize = 16.sp)
            Text(
                title,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                desc,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 9.sp
            )
        }
    }
}
