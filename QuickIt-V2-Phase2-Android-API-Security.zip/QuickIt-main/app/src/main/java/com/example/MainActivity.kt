package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AdminUser
import com.example.data.AppModule
import com.example.data.AppRole
import com.example.data.BlinkitRepository
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val repository = BlinkitRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository.initFirebase(applicationContext)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BlinkitApp(repository = repository)
            }
        }
    }
}

@Composable
fun BlinkitApp(repository: BlinkitRepository) {
    var currentModule by remember { mutableStateOf(AppModule.CUSTOMER) }
    var selectedCustomerTab by remember { mutableStateOf(AppRole.CUSTOMER) }
    var isCartOpen by remember { mutableStateOf(false) }

    val adminUser by repository.adminUser.collectAsState()
    val cart by repository.cart.collectAsState()
    val totalCartItems = cart.sumOf { it.quantity }

    BackHandler(enabled = isCartOpen || currentModule == AppModule.ADMIN) {
        if (isCartOpen) {
            isCartOpen = false
        } else if (currentModule == AppModule.ADMIN) {
            currentModule = AppModule.CUSTOMER
        }
    }

    if (currentModule == AppModule.ADMIN) {
        // Admin Module (Login or Dashboard)
        if (adminUser == null) {
            AdminLoginScreen(
                repository = repository,
                onLoginSuccess = { user ->
                    // user is now authenticated
                },
                onSwitchToCustomer = {
                    currentModule = AppModule.CUSTOMER
                }
            )
        } else {
            AdminDashboardScreen(
                repository = repository,
                onSwitchToCustomer = {
                    currentModule = AppModule.CUSTOMER
                },
                onLogout = {
                    repository.logoutAdmin()
                }
            )
        }
    } else {
        // Customer Module
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = BlinkitBackground,
            bottomBar = {
                if (!isCartOpen) {
                    NavigationBar(
                        containerColor = BlinkitSurface,
                        contentColor = BlinkitTextPrimary,
                        tonalElevation = 8.dp,
                        modifier = Modifier.border(
                            width = 1.dp,
                            color = BlinkitBorder,
                            shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp)
                        )
                    ) {
                        NavigationBarItem(
                            selected = selectedCustomerTab == AppRole.CUSTOMER,
                            onClick = { selectedCustomerTab = AppRole.CUSTOMER },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (totalCartItems > 0) {
                                            Badge(containerColor = BlinkitGreen) {
                                                Text("$totalCartItems", color = Color.White)
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Handyman, contentDescription = "Services")
                                }
                            },
                            label = {
                                Text(
                                    "Services",
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedCustomerTab == AppRole.CUSTOMER) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BlinkitGreenDark,
                                selectedTextColor = BlinkitGreenDark,
                                indicatorColor = BlinkitGreenLight,
                                unselectedIconColor = BlinkitTextSecondary,
                                unselectedTextColor = BlinkitTextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedCustomerTab == AppRole.AI_ASSISTANT,
                            onClick = { selectedCustomerTab = AppRole.AI_ASSISTANT },
                            icon = {
                                Surface(
                                    color = if (selectedCustomerTab == AppRole.AI_ASSISTANT) BlinkitGreen else BlinkitYellowLight,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.AutoAwesome,
                                        contentDescription = "Gemini AI",
                                        tint = if (selectedCustomerTab == AppRole.AI_ASSISTANT) Color.White else BlinkitDark,
                                        modifier = Modifier.padding(4.dp).size(18.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    "Gemini AI",
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedCustomerTab == AppRole.AI_ASSISTANT) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BlinkitGreenDark,
                                selectedTextColor = BlinkitGreenDark,
                                indicatorColor = BlinkitGreenLight,
                                unselectedIconColor = BlinkitTextSecondary,
                                unselectedTextColor = BlinkitTextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedCustomerTab == AppRole.ORDER_TRACKING,
                            onClick = { selectedCustomerTab = AppRole.ORDER_TRACKING },
                            icon = { Icon(Icons.Default.NearMe, contentDescription = "Live Tracker") },
                            label = {
                                Text(
                                    "Tracker",
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedCustomerTab == AppRole.ORDER_TRACKING) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BlinkitGreenDark,
                                selectedTextColor = BlinkitGreenDark,
                                indicatorColor = BlinkitGreenLight,
                                unselectedIconColor = BlinkitTextSecondary,
                                unselectedTextColor = BlinkitTextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedCustomerTab == AppRole.DARK_STORE,
                            onClick = { selectedCustomerTab = AppRole.DARK_STORE },
                            icon = { Icon(Icons.Default.HomeRepairService, contentDescription = "Tools Hub") },
                            label = {
                                Text(
                                    "Tools Hub",
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedCustomerTab == AppRole.DARK_STORE) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BlinkitGreenDark,
                                selectedTextColor = BlinkitGreenDark,
                                indicatorColor = BlinkitGreenLight,
                                unselectedIconColor = BlinkitTextSecondary,
                                unselectedTextColor = BlinkitTextSecondary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedCustomerTab == AppRole.RIDER,
                            onClick = { selectedCustomerTab = AppRole.RIDER },
                            icon = { Icon(Icons.Default.Engineering, contentDescription = "Technician") },
                            label = {
                                Text(
                                    "Technician",
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedCustomerTab == AppRole.RIDER) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BlinkitGreenDark,
                                selectedTextColor = BlinkitGreenDark,
                                indicatorColor = BlinkitGreenLight,
                                unselectedIconColor = BlinkitTextSecondary,
                                unselectedTextColor = BlinkitTextSecondary
                            )
                        )

                        // Admin Panel Shortcut Tab
                        NavigationBarItem(
                            selected = false,
                            onClick = { currentModule = AppModule.ADMIN },
                            icon = {
                                Surface(
                                    color = BlinkitDark,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.AdminPanelSettings,
                                        contentDescription = "Admin Panel",
                                        tint = BlinkitYellow,
                                        modifier = Modifier.padding(3.dp).size(18.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    "Admin HQ",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitDark
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                unselectedIconColor = BlinkitDark,
                                unselectedTextColor = BlinkitDark
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground)
            ) {
                if (isCartOpen) {
                    BookingSummaryScreen(
                        repository = repository,
                        onBack = { isCartOpen = false },
                        onOrderConfirmed = {
                            isCartOpen = false
                            selectedCustomerTab = AppRole.ORDER_TRACKING
                        },
                        onAddMoreServices = { isCartOpen = false }
                    )
                } else {
                    when (selectedCustomerTab) {
                        AppRole.CUSTOMER -> CustomerHomeScreen(
                            repository = repository,
                            onOpenCart = { isCartOpen = true },
                            onOpenOrderTracker = { selectedCustomerTab = AppRole.ORDER_TRACKING },
                            onOpenAiAssistant = { selectedCustomerTab = AppRole.AI_ASSISTANT },
                            onSwitchToAdmin = { currentModule = AppModule.ADMIN }
                        )
                        AppRole.AI_ASSISTANT -> GeminiAiAssistantScreen(
                            repository = repository,
                            onAddToCart = { service ->
                                repository.addToCart(service)
                                isCartOpen = true
                            },
                            onBack = { selectedCustomerTab = AppRole.CUSTOMER }
                        )
                        AppRole.ORDER_TRACKING -> OrderTrackingScreen(
                            repository = repository,
                            onBack = { selectedCustomerTab = AppRole.CUSTOMER }
                        )
                        AppRole.DARK_STORE -> DarkStorePickerScreen(
                            repository = repository
                        )
                        AppRole.RIDER -> RiderDeliveryScreen(
                            repository = repository
                        )
                    }
                }
            }
        }
    }
}
