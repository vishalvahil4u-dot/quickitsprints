package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun AdminDashboardScreen(
    repository: BlinkitRepository,
    onSwitchToCustomer: () -> Unit,
    onLogout: () -> Unit
) {
    val adminUser by repository.adminUser.collectAsState()
    val allOrders by repository.allOrders.collectAsState()
    val services by repository.services.collectAsState()
    val technicians by repository.technicians.collectAsState()
    val hubTools by repository.hubTools.collectAsState()
    val categories by repository.categories.collectAsState()

    var selectedTab by remember { mutableStateOf(AdminTab.OVERVIEW) }

    // Dialog states for Catalog Management
    var showAddServiceDialog by remember { mutableStateOf(false) }
    var serviceToEdit by remember { mutableStateOf<ServiceItem?>(null) }
    var serviceToDelete by remember { mutableStateOf<ServiceItem?>(null) }

    // Dialog states for Dispatch
    var orderToReassign by remember { mutableStateOf<OrderItem?>(null) }

    val adminBg = Color(0xFF0F172A)
    val adminCardBg = Color(0xFF1E293B)
    val adminAccent = Color(0xFF10B981)

    Scaffold(
        topBar = {
            // Enterprise Admin Header
            Surface(
                color = adminBg,
                shadowElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Title & Hub Location
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(BlinkitYellow),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("⚡", fontSize = 20.sp)
                            }
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        "QuickIt",
                                        color = BlinkitYellow,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Surface(
                                        color = Color.White.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            "ADMIN HQ",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    adminUser?.hubName ?: "Hub #14 (Indiranagar)",
                                    color = Color.White.copy(alpha = 0.65f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Right actions (Switch to Customer & Logout)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Switch to customer mode
                            Button(
                                onClick = onSwitchToCustomer,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White.copy(alpha = 0.12f),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Customer", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }

                            // Logout Icon
                            IconButton(
                                onClick = onLogout,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFEF4444).copy(alpha = 0.15f))
                            ) {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = "Logout",
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // Admin user profile snippet
                    adminUser?.let { user ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = Color.White.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(user.avatarEmoji, fontSize = 18.sp)
                                    Column {
                                        Text(
                                            user.name,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "${user.role} • ${user.email}",
                                            color = BlinkitYellow,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Surface(
                                    color = adminAccent.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "🟢 LIVE DISPATCH",
                                        color = adminAccent,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Admin Navigation Tabs Rail
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(AdminTab.values()) { tab ->
                            val isSelected = selectedTab == tab
                            Surface(
                                color = if (isSelected) BlinkitYellow else Color.White.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.clickable { selectedTab = tab }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val icon = when (tab) {
                                        AdminTab.OVERVIEW -> Icons.Default.Dashboard
                                        AdminTab.CATALOG -> Icons.Default.Handyman
                                        AdminTab.DISPATCH -> Icons.Default.NearMe
                                        AdminTab.VERIFICATION -> Icons.Default.VideoCameraFront
                                        AdminTab.TECHNICIANS -> Icons.Default.Engineering
                                        AdminTab.INVENTORY -> Icons.Default.Inventory2
                                    }
                                    Icon(
                                        icon,
                                        contentDescription = null,
                                        tint = if (isSelected) BlinkitDark else Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        tab.label,
                                        color = if (isSelected) BlinkitDark else Color.White.copy(alpha = 0.9f),
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        containerColor = adminBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(adminBg)
        ) {
            when (selectedTab) {
                AdminTab.OVERVIEW -> AdminOverviewTab(
                    repository = repository,
                    onNavigateToTab = { selectedTab = it },
                    onOpenAddService = { showAddServiceDialog = true }
                )
                AdminTab.CATALOG -> AdminCatalogTab(
                    repository = repository,
                    onAddNewService = { showAddServiceDialog = true },
                    onEditService = { serviceToEdit = it },
                    onDeleteService = { serviceToDelete = it }
                )
                AdminTab.DISPATCH -> AdminDispatchTab(
                    repository = repository,
                    onReassignTech = { orderToReassign = it }
                )
                AdminTab.VERIFICATION -> AdminVerificationTab(
                    repository = repository
                )
                AdminTab.TECHNICIANS -> AdminTechniciansTab(
                    repository = repository
                )
                AdminTab.INVENTORY -> AdminInventoryTab(
                    repository = repository
                )
            }
        }
    }

    // Modal: Add Service
    if (showAddServiceDialog) {
        AddEditServiceDialog(
            service = null,
            categories = categories,
            onDismiss = { showAddServiceDialog = false },
            onSave = { newService ->
                repository.addService(newService)
                showAddServiceDialog = false
            }
        )
    }

    // Modal: Edit Service
    serviceToEdit?.let { srv ->
        AddEditServiceDialog(
            service = srv,
            categories = categories,
            onDismiss = { serviceToEdit = null },
            onSave = { updated ->
                repository.updateService(updated)
                serviceToEdit = null
            }
        )
    }

    // Modal: Confirm Delete Service
    serviceToDelete?.let { srv ->
        AlertDialog(
            onDismissRequest = { serviceToDelete = null },
            title = { Text("Delete Service?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Are you sure you want to permanently remove \"${srv.name}\" from the service catalog?",
                    color = Color.White.copy(alpha = 0.8f)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        repository.deleteService(srv.id)
                        serviceToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { serviceToDelete = null }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = adminCardBg
        )
    }

    // Modal: Reassign Technician
    orderToReassign?.let { order ->
        ReassignTechnicianDialog(
            order = order,
            technicians = technicians,
            onDismiss = { orderToReassign = null },
            onSelectTechnician = { tech ->
                repository.assignTechnicianToOrder(order.id, tech.id)
                orderToReassign = null
            }
        )
    }
}

// =========================================================================
// TAB 1: OVERVIEW & ANALYTICS
// =========================================================================
@Composable
fun AdminOverviewTab(
    repository: BlinkitRepository,
    onNavigateToTab: (AdminTab) -> Unit,
    onOpenAddService: () -> Unit
) {
    val allOrders by repository.allOrders.collectAsState()
    val technicians by repository.technicians.collectAsState()
    val services by repository.services.collectAsState()
    val hubTools by repository.hubTools.collectAsState()

    val totalRevenue = allOrders.sumOf { it.grandTotal } + 28450.0 // seeded base revenue
    val activeOrdersCount = allOrders.count { it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED }
    val onDutyTechsCount = technicians.count { it.status != TechnicianStatus.OFF_DUTY }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top KPI Grid (2x2)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Hub #14 Performance Snapshot",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminKpiCard(
                        title = "Today's Gross Rev",
                        value = "₹" + String.format("%.0f", totalRevenue),
                        subtitle = "↗ +22.4% vs avg",
                        icon = Icons.Default.CurrencyRupee,
                        accentColor = BlinkitYellow,
                        modifier = Modifier.weight(1f)
                    )
                    AdminKpiCard(
                        title = "10-Min SLA Rate",
                        value = "97.6%",
                        subtitle = "Avg ETA 8.2 mins",
                        icon = Icons.Default.Timer,
                        accentColor = Color(0xFF10B981),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminKpiCard(
                        title = "Active Bookings",
                        value = "$activeOrdersCount Jobs",
                        subtitle = "${allOrders.size} total today",
                        icon = Icons.Default.ElectricMoped,
                        accentColor = Color(0xFF38BDF8),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(AdminTab.DISPATCH) }
                    )
                    AdminKpiCard(
                        title = "Fleet Available",
                        value = "$onDutyTechsCount / ${technicians.size} Techs",
                        subtitle = "Hub Indiranagar",
                        icon = Icons.Default.Engineering,
                        accentColor = Color(0xFFA855F7),
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(AdminTab.TECHNICIANS) }
                    )
                }
            }
        }

        // Quick Administrative Action Shortcuts
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "⚡ Quick Administrative Actions",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenAddService,
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow, contentColor = BlinkitDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Service", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onNavigateToTab(AdminTab.DISPATCH) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f), contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.NearMe, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("View Queue", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Live Dispatch Activity Feed
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "🔴 Live Dispatch Radar Feed",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Auto-syncing (5s)",
                        color = Color(0xFF10B981),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }

                allOrders.take(4).forEach { order ->
                    Surface(
                        color = Color(0xFF1E293B),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToTab(AdminTab.DISPATCH) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val icon = when (order.status) {
                                    OrderStatus.PLACED -> "📥"
                                    OrderStatus.PACKING -> "🧰"
                                    OrderStatus.OUT_FOR_DELIVERY -> "🛵"
                                    OrderStatus.IN_SERVICE -> "🔧"
                                    OrderStatus.DELIVERED -> "✅"
                                    OrderStatus.CANCELLED -> "❌"
                                }
                                Text(icon, fontSize = 22.sp)

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            order.orderNumber,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text("•", color = Color.White.copy(alpha = 0.4f))
                                        Text(
                                            order.placedAtTime,
                                            color = Color.White.copy(alpha = 0.6f),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        order.items.joinToString(", ") { "${it.quantity}x ${it.service.name}" },
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "Assigned: ${order.riderName} (${order.riderVehicle})",
                                        color = BlinkitYellow,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "₹" + String.format("%.0f", order.grandTotal),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    color = when (order.status) {
                                        OrderStatus.OUT_FOR_DELIVERY -> Color(0xFF2563EB).copy(alpha = 0.2f)
                                        OrderStatus.DELIVERED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                        OrderStatus.IN_SERVICE -> Color(0xFFD97706).copy(alpha = 0.2f)
                                        else -> Color.White.copy(alpha = 0.1f)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        order.status.displayName,
                                        color = when (order.status) {
                                            OrderStatus.OUT_FOR_DELIVERY -> Color(0xFF60A5FA)
                                            OrderStatus.DELIVERED -> Color(0xFF34D399)
                                            OrderStatus.IN_SERVICE -> Color(0xFFFBBF24)
                                            else -> Color.White.copy(alpha = 0.8f)
                                        },
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminKpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(14.dp))
                }
            }
            Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = accentColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// =========================================================================
// TAB 2: CATALOG & RATE CARD MANAGER
// =========================================================================
@Composable
fun AdminCatalogTab(
    repository: BlinkitRepository,
    onAddNewService: () -> Unit,
    onEditService: (ServiceItem) -> Unit,
    onDeleteService: (ServiceItem) -> Unit
) {
    val services by repository.services.collectAsState()
    val categories by repository.categories.collectAsState()

    var selectedCatId by remember { mutableStateOf("cat_all") }
    var searchQuery by remember { mutableStateOf("") }

    val filteredServices = remember(services, selectedCatId, searchQuery) {
        services.filter { srv ->
            (selectedCatId == "cat_all" || srv.categoryId == selectedCatId) &&
            (searchQuery.isBlank() || srv.name.contains(searchQuery, ignoreCase = true) || srv.toolkitRequired.contains(searchQuery, ignoreCase = true))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search & Add Button Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search services, toolkits, rates...", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BlinkitYellow) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = BlinkitYellow,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            )

            Button(
                onClick = onAddNewService,
                colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow, contentColor = BlinkitDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(52.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Service", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Category Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                val isSelected = selectedCatId == cat.id
                Surface(
                    color = if (isSelected) BlinkitYellow else Color(0xFF1E293B),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (isSelected) BlinkitYellow else Color.White.copy(alpha = 0.1f)),
                    modifier = Modifier.clickable { selectedCatId = cat.id }
                ) {
                    Text(
                        "${cat.iconEmoji} ${cat.name}",
                        color = if (isSelected) BlinkitDark else Color.White,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Text(
            "Showing ${filteredServices.size} instant services in catalog",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 11.sp
        )

        // Services List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredServices, key = { it.id }) { service ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (service.isAvailable) Color(0xFF1E293B) else Color(0xFF1E293B).copy(alpha = 0.6f)
                    ),
                    border = BorderStroke(1.dp, if (service.isAvailable) Color.White.copy(alpha = 0.08f) else Color(0xFFEF4444).copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(service.emoji, fontSize = 28.sp)
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            service.name,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (!service.isAvailable) {
                                            Surface(
                                                color = Color(0xFFEF4444).copy(alpha = 0.2f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    "PAUSED",
                                                    color = Color(0xFFFCA5A5),
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        "Duration: ${service.duration} • ETA: ${service.etaMinutes} • ${service.warranty}",
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        "🧰 Toolkit: ${service.toolkitRequired}",
                                        color = BlinkitYellow,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // Price Column
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "₹" + String.format("%.0f", service.price),
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    "₹" + String.format("%.0f", service.originalPrice),
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 11.sp,
                                    textDecoration = TextDecoration.LineThrough
                                )
                            }
                        }

                        HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                        // Controls Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Active / Paused Switch
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Switch(
                                    checked = service.isAvailable,
                                    onCheckedChange = { isChecked ->
                                        repository.toggleServiceAvailability(service.id, isChecked)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = BlinkitDark,
                                        checkedTrackColor = BlinkitYellow,
                                        uncheckedThumbColor = Color.White.copy(alpha = 0.6f),
                                        uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                                Text(
                                    if (service.isAvailable) "Active in App" else "Paused",
                                    color = if (service.isAvailable) Color(0xFF10B981) else Color(0xFFEF4444),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Action buttons (Edit & Delete)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { onEditService(service) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White.copy(alpha = 0.1f),
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", fontSize = 11.sp)
                                }

                                IconButton(
                                    onClick = { onDeleteService(service) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFEF4444).copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFF87171),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 3: LIVE DISPATCH & BOOKINGS CONTROL
// =========================================================================
@Composable
fun AdminDispatchTab(
    repository: BlinkitRepository,
    onReassignTech: (OrderItem) -> Unit
) {
    val allOrders by repository.allOrders.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Live Booking Queue (${allOrders.size})",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Hub #14 Indiranagar",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 11.sp
                )
            }
        }

        items(allOrders, key = { it.id }) { order ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Order header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                order.orderNumber,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Surface(
                                color = when (order.status) {
                                    OrderStatus.OUT_FOR_DELIVERY -> Color(0xFF2563EB).copy(alpha = 0.2f)
                                    OrderStatus.DELIVERED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    OrderStatus.IN_SERVICE -> Color(0xFFD97706).copy(alpha = 0.2f)
                                    OrderStatus.PACKING -> Color(0xFF8B5CF6).copy(alpha = 0.2f)
                                    OrderStatus.CANCELLED -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                    else -> Color.White.copy(alpha = 0.1f)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    order.status.displayName,
                                    color = when (order.status) {
                                        OrderStatus.OUT_FOR_DELIVERY -> Color(0xFF60A5FA)
                                        OrderStatus.DELIVERED -> Color(0xFF34D399)
                                        OrderStatus.IN_SERVICE -> Color(0xFFFBBF24)
                                        OrderStatus.PACKING -> Color(0xFFA78BFA)
                                        OrderStatus.CANCELLED -> Color(0xFFFCA5A5)
                                        else -> Color.White
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // OTP Badge
                        Surface(
                            color = BlinkitYellow.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, BlinkitYellow.copy(alpha = 0.4f))
                        ) {
                            Text(
                                "OTP: ${order.otpCode}",
                                color = BlinkitYellow,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Customer & Address info
                    Surface(
                        color = Color(0xFF0F172A).copy(alpha = 0.6f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "👤 ${order.address.receiverName} (${order.address.phone})",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text("₹" + String.format("%.0f", order.grandTotal), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                "📍 ${order.address.label}: ${order.address.addressLine}, ${order.address.landmark}",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                            if (order.instructions.isNotEmpty()) {
                                Text(
                                    "📝 Client notes: ${order.instructions.joinToString(" • ")}",
                                    color = BlinkitYellow,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Services in order
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        order.items.forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${item.service.emoji} ${item.quantity}x ${item.service.name}",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 12.sp
                                )
                                Text(
                                    "₹" + String.format("%.0f", item.service.price * item.quantity),
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Assigned Technician
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("👷‍♂️", fontSize = 16.sp)
                            Column {
                                Text(order.riderName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("${order.riderVehicle} • ${order.riderPhone}", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                            }
                        }

                        TextButton(
                            onClick = { onReassignTech(order) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Reassign", color = BlinkitYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    // Status Advance Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        when (order.status) {
                            OrderStatus.PLACED -> {
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.PACKING) },
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow, contentColor = BlinkitDark),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dispatch Kit Prep (Pack)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.PACKING -> {
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.OUT_FOR_DELIVERY) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB), contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dispatch Tech En Route", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.OUT_FOR_DELIVERY -> {
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.IN_SERVICE) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706), contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Mark Service In-Progress", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.IN_SERVICE -> {
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.DELIVERED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Complete Job (Verify OTP)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OrderStatus.DELIVERED -> {
                                Text(
                                    "✅ Job Successfully Completed & Verified",
                                    color = Color(0xFF10B981),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            OrderStatus.CANCELLED -> {
                                Text(
                                    "❌ Booking Cancelled & Refunded",
                                    color = Color(0xFFEF4444),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (order.status != OrderStatus.DELIVERED && order.status != OrderStatus.CANCELLED) {
                            OutlinedButton(
                                onClick = { repository.cancelOrderByAdmin(order.id, "Admin manual cancellation") },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Cancel", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 4: FLEET & TECHNICIANS OPERATIONS
// =========================================================================
@Composable
fun AdminTechniciansTab(
    repository: BlinkitRepository
) {
    val technicians by repository.technicians.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Service Fleet & Pro Technicians (${technicians.size})",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = Color(0xFF10B981).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "Hub #14 Fleet Live",
                        color = Color(0xFF10B981),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }
        }

        items(technicians, key = { it.id }) { tech ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(tech.avatarEmoji, fontSize = 22.sp)
                            }

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        tech.name,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        color = tech.status.color.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            tech.status.label,
                                            color = tech.status.color,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    tech.speciality,
                                    color = BlinkitYellow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    "🛵 ${tech.vehicleNumber} (${tech.vehicleType}) • 📞 ${tech.phone}",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Metrics Strip (Rating, Jobs Today, Battery Level)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TechMetricPill(
                            label = "Rating",
                            value = "★ ${tech.rating}",
                            modifier = Modifier.weight(1f)
                        )
                        TechMetricPill(
                            label = "Jobs Today",
                            value = "${tech.completedJobsToday} done",
                            modifier = Modifier.weight(1f)
                        )
                        TechMetricPill(
                            label = "EV Battery",
                            value = "⚡ ${tech.batteryPercent}%",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Status Change Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                repository.updateTechnicianStatus(
                                    tech.id,
                                    if (tech.status == TechnicianStatus.AVAILABLE) TechnicianStatus.OFF_DUTY else TechnicianStatus.AVAILABLE
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tech.status == TechnicianStatus.AVAILABLE) Color.White.copy(alpha = 0.1f) else Color(0xFF10B981),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(34.dp)
                        ) {
                            Text(
                                if (tech.status == TechnicianStatus.AVAILABLE) "Mark Off-Duty" else "Mark Ready @ Hub",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TechMetricPill(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xFF0F172A).copy(alpha = 0.7f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
            Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// =========================================================================
// TAB 5: DARK STORE HUB INVENTORY
// =========================================================================
@Composable
fun AdminInventoryTab(
    repository: BlinkitRepository
) {
    val tools by repository.hubTools.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Dark Store Hub #14 Equipment (${tools.size})",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Tools Ready for 10m Dispatch",
                    color = BlinkitYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        items(tools, key = { it.id }) { tool ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, if (tool.isCritical) BlinkitYellow.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.08f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(tool.emoji, fontSize = 24.sp)
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        tool.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (tool.isCritical) {
                                        Surface(
                                            color = BlinkitYellow.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "PRO ESSENTIAL",
                                                color = BlinkitYellow,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    "Category: ${tool.category} • Condition: ${tool.condition}",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Stock indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column {
                                Text("Total Stock", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                                Text("${tool.totalStock} units", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("In Use (Dispatched)", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                                Text("${tool.inUseCount} units", color = Color(0xFF38BDF8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Available at Hub", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                                Text("${tool.totalStock - tool.inUseCount} units", color = Color(0xFF10B981), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Restock & Maintenance actions
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { repository.restockTool(tool.id, 2) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White.copy(alpha = 0.1f),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("+2 Stock", fontSize = 10.sp)
                            }

                            Button(
                                onClick = { repository.toggleToolCondition(tool.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BlinkitYellow.copy(alpha = 0.15f),
                                    contentColor = BlinkitYellow
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Calibrate", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB: WORK VERIFICATION & PAYMENT DISPUTES (ADMIN REVIEW)
// =========================================================================
@Composable
fun AdminVerificationTab(
    repository: BlinkitRepository
) {
    val allOrders by repository.allOrders.collectAsState()
    val activeOrder by repository.activeOrder.collectAsState()

    // Combine active order and past orders
    val ordersWithProof = remember(allOrders, activeOrder) {
        val combined = mutableListOf<OrderItem>()
        activeOrder?.let { if (it.workProof != null) combined.add(it) }
        allOrders.forEach { ord ->
            if (ord.workProof != null && combined.none { it.id == ord.id }) {
                combined.add(ord)
            }
        }
        combined
    }

    var selectedFilter by remember { mutableStateOf("ALL") }
    var orderToResolve by remember { mutableStateOf<OrderItem?>(null) }
    var resolutionAction by remember { mutableStateOf<String?>(null) } // "APPROVE" or "REFUND"
    var adminNotes by remember { mutableStateOf("") }
    var videoPreviewOrder by remember { mutableStateOf<OrderItem?>(null) }
    var isSimulatingPlay by remember { mutableStateOf(false) }

    val filteredOrders = remember(ordersWithProof, selectedFilter) {
        when (selectedFilter) {
            "ON_HOLD" -> ordersWithProof.filter { it.workProof?.isPaymentOnHold == true || it.workProof?.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD }
            "RESOLVED" -> ordersWithProof.filter { it.workProof?.status == WorkProofStatus.ADMIN_APPROVED || it.workProof?.status == WorkProofStatus.ADMIN_REFUNDED }
            "SUBMITTED" -> ordersWithProof.filter { it.workProof?.status == WorkProofStatus.SUBMITTED }
            else -> ordersWithProof
        }
    }

    val onHoldCount = ordersWithProof.count { it.workProof?.isPaymentOnHold == true || it.workProof?.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Overview Summary Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = BorderStroke(1.dp, if (onHoldCount > 0) Color(0xFFF59E0B) else Color.White.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🛡️", fontSize = 20.sp)
                            Text(
                                "Proof Verification & Payment Escrow",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Review technician video recordings, customer local device counter-proofs, and resolve held payments.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                    if (onHoldCount > 0) {
                        Surface(
                            color = Color(0xFFEF4444).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFEF4444))
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("$onHoldCount", color = Color(0xFFF87171), fontSize = 16.sp, fontWeight = FontWeight.Black)
                                Text("ON HOLD", color = Color(0xFFF87171), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val filterList = listOf(
                    "ALL" to "All Proofs (${ordersWithProof.size})",
                    "ON_HOLD" to "⚠️ Payment On Hold ($onHoldCount)",
                    "SUBMITTED" to "📹 Submitted (${ordersWithProof.count { it.workProof?.status == WorkProofStatus.SUBMITTED }})",
                    "RESOLVED" to "✅ Resolved (${ordersWithProof.count { it.workProof?.status == WorkProofStatus.ADMIN_APPROVED || it.workProof?.status == WorkProofStatus.ADMIN_REFUNDED }})"
                )
                items(filterList) { (key, label) ->
                    val isSel = selectedFilter == key
                    Surface(
                        color = if (isSel) BlinkitYellow else Color(0xFF1E293B),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isSel) BlinkitYellow else Color.White.copy(alpha = 0.1f)),
                        modifier = Modifier.clickable { selectedFilter = key }
                    ) {
                        Text(
                            label,
                            color = if (isSel) BlinkitDark else Color.White,
                            fontSize = 12.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        if (filteredOrders.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📹", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No Proofs in this category", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                    }
                }
            }
        } else {
            items(filteredOrders) { order ->
                val proof = order.workProof ?: return@items
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(
                        1.dp,
                        when (proof.status) {
                            WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEF4444)
                            WorkProofStatus.ADMIN_APPROVED -> Color(0xFF10B981)
                            WorkProofStatus.ADMIN_REFUNDED -> Color(0xFFA855F7)
                            WorkProofStatus.APPROVED_BY_CLIENT -> Color(0xFF10B981)
                            else -> Color.White.copy(alpha = 0.1f)
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Header: Order ID, Amount, Status Badge
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    order.orderNumber,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    order.items.joinToString { it.service.name },
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp
                                )
                            }

                            Surface(
                                color = when (proof.status) {
                                    WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                    WorkProofStatus.ADMIN_APPROVED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    WorkProofStatus.ADMIN_REFUNDED -> Color(0xFFA855F7).copy(alpha = 0.2f)
                                    WorkProofStatus.APPROVED_BY_CLIENT -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    else -> BlinkitYellow.copy(alpha = 0.2f)
                                },
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(
                                    1.dp,
                                    when (proof.status) {
                                        WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFEF4444)
                                        WorkProofStatus.ADMIN_APPROVED -> Color(0xFF10B981)
                                        WorkProofStatus.ADMIN_REFUNDED -> Color(0xFFA855F7)
                                        else -> BlinkitYellow
                                    }
                                )
                            ) {
                                Text(
                                    when (proof.status) {
                                        WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> "⚠️ PAYMENT ON HOLD"
                                        WorkProofStatus.ADMIN_APPROVED -> "✅ ADMIN APPROVED"
                                        WorkProofStatus.ADMIN_REFUNDED -> "💸 ADMIN REFUNDED"
                                        WorkProofStatus.APPROVED_BY_CLIENT -> "⭐ CLIENT APPROVED"
                                        WorkProofStatus.SUBMITTED -> "📹 PROOF SUBMITTED"
                                        else -> proof.status.name
                                    },
                                    color = when (proof.status) {
                                        WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD -> Color(0xFFF87171)
                                        WorkProofStatus.ADMIN_APPROVED -> Color(0xFF34D399)
                                        WorkProofStatus.ADMIN_REFUNDED -> Color(0xFFC084FC)
                                        else -> BlinkitYellow
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Divider(color = Color.White.copy(alpha = 0.08f))

                        // Customer & Technician Info Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Customer", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                                Text(order.address.receiverName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text(order.address.phone, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Technician", color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
                                Text(order.riderName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text(order.riderPhone, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            }
                        }

                        // Technician Video Proof Details Card
                        Surface(
                            color = Color(0xFF0F172A),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Default.Videocam, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(16.dp))
                                        Text("Technician Video Proof", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("${proof.videoDurationSec}s • ${proof.videoResolution}", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                                }
                                Text("Path: ${proof.savedLocalPhonePath}", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Text("Notes: ${proof.technicianRemarks}", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)

                                Button(
                                    onClick = {
                                        videoPreviewOrder = order
                                        isSimulatingPlay = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f), contentColor = Color.White),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Preview Tech Recording", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Customer Dispute / Counter Proof Section (if present)
                        if (!proof.customerIssueNotes.isNullOrBlank() || proof.isPaymentOnHold) {
                            Surface(
                                color = Color(0xFFEF4444).copy(alpha = 0.08f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("⚠️", fontSize = 14.sp)
                                        Text("Customer Dispute & Rebuttal", color = Color(0xFFF87171), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    proof.issueCategory?.let {
                                        Text("Category: $it", color = BlinkitYellow, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("Reason: ${proof.customerIssueNotes ?: proof.paymentHoldReason ?: "Customer reported issue after reviewing proof"}", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)

                                    if (proof.customerLocalVideoPath != null) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Surface(
                                            color = Color.Black.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.FileUpload, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(14.dp))
                                                Column {
                                                    Text("Customer Local Device Video Uploaded", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    Text(proof.customerLocalVideoPath, color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // If already resolved by Admin, show resolution summary
                        if (proof.status == WorkProofStatus.ADMIN_APPROVED || proof.status == WorkProofStatus.ADMIN_REFUNDED) {
                            Surface(
                                color = Color.White.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        if (proof.status == WorkProofStatus.ADMIN_APPROVED) Icons.Default.CheckCircle else Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = if (proof.status == WorkProofStatus.ADMIN_APPROVED) Color(0xFF10B981) else Color(0xFFA855F7),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            if (proof.status == WorkProofStatus.ADMIN_APPROVED) "Approved by ${proof.adminReviewerName ?: "Admin"} • Payout Released"
                                            else "Refunded by ${proof.adminReviewerName ?: "Admin"} • ₹${order.grandTotal.toInt()} returned to customer",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        proof.adminApprovalNotes?.let {
                                            Text("Notes: $it", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Admin Action Buttons (When on hold or pending admin review)
                        if (proof.isPaymentOnHold || proof.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD || proof.status == WorkProofStatus.SUBMITTED) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Approve and release payment button
                                Button(
                                    onClick = {
                                        orderToResolve = order
                                        resolutionAction = "APPROVE"
                                        adminNotes = "Technician proof is verified and complies with standard SOP."
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve & Release", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                // Reject & Refund button
                                Button(
                                    onClick = {
                                        orderToResolve = order
                                        resolutionAction = "REFUND"
                                        adminNotes = "Customer claim validated from video evidence. Full refund approved."
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Refund Customer", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Admin Action Confirmation & Notes
    orderToResolve?.let { order ->
        val isApprove = resolutionAction == "APPROVE"
        AlertDialog(
            onDismissRequest = { orderToResolve = null },
            title = {
                Text(
                    if (isApprove) "Approve Video Proof & Release Payout?" else "Issue Customer Refund?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (isApprove) "Approving this work proof will clear the payment hold and release ₹${order.grandTotal.toInt()} payout to technician ${order.riderName}."
                        else "Approving the customer dispute will refund ₹${order.grandTotal.toInt()} back to the customer's payment method.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = adminNotes,
                        onValueChange = { adminNotes = it },
                        label = { Text("Admin Audit Log Notes", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = if (isApprove) Color(0xFF10B981) else Color(0xFFEF4444),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isApprove) {
                            repository.adminApproveVideoProof(order.id, adminNotes)
                        } else {
                            repository.adminRejectAndRefund(order.id, adminNotes)
                        }
                        orderToResolve = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApprove) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                ) {
                    Text(if (isApprove) "Confirm Approval" else "Process Refund", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToResolve = null }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // Modal: Simulated Video Player Preview
    videoPreviewOrder?.let { order ->
        val proof = order.workProof
        Dialog(onDismissRequest = { videoPreviewOrder = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.dp, BlinkitYellow),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Video Proof Playback Preview", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        IconButton(onClick = { videoPreviewOrder = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Video Preview Viewport
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("📹", fontSize = 36.sp)
                            Text(
                                "PLAYING: ${proof?.videoResolution ?: "1080p FHD"}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Duration: ${proof?.videoDurationSec ?: 20}s • Local DCIM Stream",
                                color = BlinkitYellow,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { videoPreviewOrder = null },
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow, contentColor = BlinkitDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Close Preview", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// DIALOG: ADD / EDIT SERVICE MODAL
// =========================================================================
@Composable
fun AddEditServiceDialog(
    service: ServiceItem?,
    categories: List<CategoryItem>,
    onDismiss: () -> Unit,
    onSave: (ServiceItem) -> Unit
) {
    var name by remember { mutableStateOf(service?.name ?: "") }
    var categoryId by remember { mutableStateOf(service?.categoryId ?: categories.firstOrNull()?.id ?: "cat_plumbing") }
    var subCategory by remember { mutableStateOf(service?.subCategory ?: "General") }
    var priceText by remember { mutableStateOf(service?.price?.toInt()?.toString() ?: "199") }
    var origPriceText by remember { mutableStateOf(service?.originalPrice?.toInt()?.toString() ?: "299") }
    var duration by remember { mutableStateOf(service?.duration ?: "30 mins") }
    var emoji by remember { mutableStateOf(service?.emoji ?: "🔧") }
    var etaMinutes by remember { mutableStateOf(service?.etaMinutes ?: "10-15 mins") }
    var warranty by remember { mutableStateOf(service?.warranty ?: "30-Day Guarantee") }
    var toolkitRequired by remember { mutableStateOf(service?.toolkitRequired ?: "Pro Service Toolkit") }
    var description by remember { mutableStateOf(service?.description ?: "Certified expert technician with sanitized tools.") }

    val adminCardBg = Color(0xFF1E293B)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = adminCardBg),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (service == null) "Add New Instant Service" else "Edit Rate Card Service",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        // Emoji & Name
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = emoji,
                                onValueChange = { emoji = it },
                                label = { Text("Icon", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.width(64.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )

                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("Service Title", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )
                        }
                    }

                    item {
                        // Category Selector
                        Text("Category", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories.filter { it.id != "cat_all" }) { cat ->
                                val isSel = categoryId == cat.id
                                Surface(
                                    color = if (isSel) BlinkitYellow else Color(0xFF0F172A),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (isSel) BlinkitYellow else Color.White.copy(alpha = 0.1f)),
                                    modifier = Modifier.clickable { categoryId = cat.id }
                                ) {
                                    Text(
                                        "${cat.iconEmoji} ${cat.name}",
                                        color = if (isSel) BlinkitDark else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        // Prices
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = priceText,
                                onValueChange = { priceText = it },
                                label = { Text("Discounted Price (₹)", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )

                            OutlinedTextField(
                                value = origPriceText,
                                onValueChange = { origPriceText = it },
                                label = { Text("Original Price (₹)", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )
                        }
                    }

                    item {
                        // Duration & ETA
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = duration,
                                onValueChange = { duration = it },
                                label = { Text("Duration (e.g. 30 mins)", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )

                            OutlinedTextField(
                                value = etaMinutes,
                                onValueChange = { etaMinutes = it },
                                label = { Text("Dispatch ETA", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BlinkitYellow,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                                )
                            )
                        }
                    }

                    item {
                        // Toolkit Required & Warranty
                        OutlinedTextField(
                            value = toolkitRequired,
                            onValueChange = { toolkitRequired = it },
                            label = { Text("Hub Toolkit & Equipment Needed", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BlinkitYellow,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = warranty,
                            onValueChange = { warranty = it },
                            label = { Text("Warranty Guarantee (e.g. 30-Day Guarantee)", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BlinkitYellow,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Customer Facing Description", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = BlinkitYellow,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val pr = priceText.toDoubleOrNull() ?: 199.0
                            val origPr = origPriceText.toDoubleOrNull() ?: (pr * 1.3)
                            val disc = if (origPr > 0) (((origPr - pr) / origPr) * 100).toInt() else 0

                            val item = ServiceItem(
                                id = service?.id ?: ("s_" + System.currentTimeMillis()),
                                name = name.ifBlank { "Instant Pro Service" },
                                categoryId = categoryId,
                                subCategory = subCategory,
                                duration = duration.ifBlank { "30 mins" },
                                price = pr,
                                originalPrice = origPr,
                                discountPercent = disc,
                                emoji = emoji.ifBlank { "⚡" },
                                etaMinutes = etaMinutes.ifBlank { "10-15 mins" },
                                warranty = warranty.ifBlank { "30-Day Guarantee" },
                                toolkitRequired = toolkitRequired.ifBlank { "Standard Pro Tool Kit" },
                                rating = service?.rating ?: 4.9,
                                ratingCount = service?.ratingCount ?: 120,
                                description = description.ifBlank { "Expert certified technician service with quality guarantee." },
                                isBestseller = service?.isBestseller ?: false,
                                isAvailable = service?.isAvailable ?: true
                            )
                            onSave(item)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow, contentColor = BlinkitDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Save Service to Catalog", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// =========================================================================
// DIALOG: REASSIGN TECHNICIAN MODAL
// =========================================================================
@Composable
fun ReassignTechnicianDialog(
    order: OrderItem,
    technicians: List<TechnicianProfile>,
    onDismiss: () -> Unit,
    onSelectTechnician: (TechnicianProfile) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Reassign Technician for ${order.orderNumber}",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Select an on-duty technician at Hub #14 to dispatch immediately:",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(technicians) { tech ->
                        Surface(
                            color = Color(0xFF0F172A),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectTechnician(tech) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(tech.avatarEmoji, fontSize = 20.sp)
                                    Column {
                                        Text(tech.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(tech.speciality, color = BlinkitYellow, fontSize = 10.sp)
                                        Text("🛵 ${tech.vehicleNumber} • ⚡ ${tech.batteryPercent}%", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
                                    }
                                }

                                Surface(
                                    color = tech.status.color.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        tech.status.label,
                                        color = tech.status.color,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}
