package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

data class ServiceStepInfo(
    val status: OrderStatus,
    val stepIndex: Int,
    val shortTitle: String,
    val fullTitle: String,
    val icon: ImageVector,
    val emoji: String,
    val description: String,
    val estimateText: String
)

val SERVICE_STEPS = listOf(
    ServiceStepInfo(
        status = OrderStatus.PLACED,
        stepIndex = 0,
        shortTitle = "Requested",
        fullTitle = "1. Booking Requested",
        icon = Icons.Default.ReceiptLong,
        emoji = "📋",
        description = "Service request received & Dark Store Hub #14 matching verified pro",
        estimateText = "0 min"
    ),
    ServiceStepInfo(
        status = OrderStatus.PACKING,
        stepIndex = 1,
        shortTitle = "Hub Prep",
        fullTitle = "2. Hub & Tool Prep",
        icon = Icons.Default.HomeRepairService,
        emoji = "🧰",
        description = "Calibrated tools, safety gear & genuine spare parts verified at Hub",
        estimateText = "2-3 mins"
    ),
    ServiceStepInfo(
        status = OrderStatus.OUT_FOR_DELIVERY,
        stepIndex = 2,
        shortTitle = "En Route",
        fullTitle = "3. Technician En Route",
        icon = Icons.Default.ElectricScooter,
        emoji = "🛵",
        description = "Pro technician on Ather EV scooter with rapid toolbag in transit",
        estimateText = "8-10 mins"
    ),
    ServiceStepInfo(
        status = OrderStatus.IN_SERVICE,
        stepIndex = 3,
        shortTitle = "In Service",
        fullTitle = "4. Service In Progress",
        icon = Icons.Default.Build,
        emoji = "⚙️",
        description = "On-site diagnosis, high-pressure repair & sanitization at your premises",
        estimateText = "30-45 mins"
    ),
    ServiceStepInfo(
        status = OrderStatus.DELIVERED,
        stepIndex = 4,
        shortTitle = "Completed",
        fullTitle = "5. Service Completed",
        icon = Icons.Default.Verified,
        emoji = "🛡️",
        description = "Job finished with verified OTP & active 30-Day QuickIt Guarantee",
        estimateText = "Done"
    )
)

/**
 * Visual Step-Tracker Component for User Dashboard 'My Bookings' section.
 * Shows real-time progression from 'Requested' -> 'Hub Prep' -> 'En Route' -> 'In Service' -> 'Completed'.
 */
@Composable
fun BookingVisualStepTracker(
    order: OrderItem,
    onAdvanceStatus: ((OrderStatus) -> Unit)? = null,
    onOpenTracker: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    isExpandedDefault: Boolean = false
) {
    var isDetailTimelineExpanded by remember { mutableStateOf(isExpandedDefault) }
    val currentStepIndex = remember(order.status) {
        when (order.status) {
            OrderStatus.PLACED -> 0
            OrderStatus.PACKING -> 1
            OrderStatus.OUT_FOR_DELIVERY -> 2
            OrderStatus.IN_SERVICE -> 3
            OrderStatus.DELIVERED -> 4
            OrderStatus.CANCELLED -> -1
        }
    }

    val isCompleted = order.status == OrderStatus.DELIVERED
    val isCancelled = order.status == OrderStatus.CANCELLED

    // Animated glow pulse on active step node
    val infiniteTransition = rememberInfiniteTransition(label = "StepGlow")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseAlpha"
    )

    // Animated progression percentage for the progress line (0.0 to 1.0)
    val targetProgress = remember(currentStepIndex, isCancelled) {
        if (isCancelled) 0f
        else (currentStepIndex.coerceAtLeast(0) / 4.0f).coerceIn(0f, 1f)
    }
    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "StepProgressAnim"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("booking_step_tracker_${order.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) Color(0xFFF6FBF6) else BlinkitSurface
        ),
        border = BorderStroke(
            1.2.dp,
            when {
                isCompleted -> BlinkitGreen.copy(alpha = 0.6f)
                isCancelled -> Color.Red.copy(alpha = 0.4f)
                else -> BlinkitYellowDark.copy(alpha = 0.6f)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ==========================================
            // 1. TOP STATUS HEADER & REAL-TIME BADGE
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted -> BlinkitGreenLight
                                    isCancelled -> Color(0xFFFFEBEE)
                                    else -> BlinkitYellowLight
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when {
                                isCompleted -> "🛡️"
                                isCancelled -> "❌"
                                currentStepIndex == 0 -> "📋"
                                currentStepIndex == 1 -> "🧰"
                                currentStepIndex == 2 -> "🛵"
                                else -> "⚙️"
                            },
                            fontSize = 18.sp
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                if (isCancelled) "Booking Cancelled" else order.status.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isCompleted) BlinkitGreenDark else BlinkitTextPrimary
                            )

                            if (!isCompleted && !isCancelled) {
                                Surface(
                                    color = BlinkitGreen,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "LIVE",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            if (isCompleted) "Job completed • 30-Day warranty active" else "Stage ${currentStepIndex + 1} of 5 • ${order.placedAtTime}",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }

                // ETA or Status pill
                if (!isCompleted && !isCancelled) {
                    Surface(
                        color = BlinkitDark,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("⚡", fontSize = 10.sp)
                            Text(
                                "${order.etaMinutesLeft}m ETA",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitYellow
                            )
                        }
                    }
                } else if (isCompleted) {
                    Surface(
                        color = BlinkitGreenLight,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            "✓ VERIFIED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // =========================================================================
            // 2. HORIZONTAL VISUAL STEP-TRACKER CONNECTED PIPELINE (Real-Time Stepper)
            // =========================================================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Stepper Canvas Line & Nodes Row
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    // Background Connecting Line & Animated Active Line
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .align(Alignment.Center)
                    ) {
                        val nodeCount = SERVICE_STEPS.size
                        val stepSpacing = size.width / (nodeCount - 1)
                        val lineY = size.height / 2f

                        // Draw background track (inactive gray)
                        drawLine(
                            color = Color(0xFFE2E8F0),
                            start = Offset(0f, lineY),
                            end = Offset(size.width, lineY),
                            strokeWidth = 6.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Draw completed/active green animated progress line
                        val progressEndX = size.width * animatedProgress
                        if (progressEndX > 0f) {
                            drawLine(
                                brush = Brush.horizontalGradient(
                                    listOf(
                                        Color(0xFF0C831F),
                                        Color(0xFF22C55E),
                                        if (isCompleted) Color(0xFF0C831F) else Color(0xFFFCD34D)
                                    )
                                ),
                                start = Offset(0f, lineY),
                                end = Offset(progressEndX, lineY),
                                strokeWidth = 6.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    // Stepper Node Markers overlaid horizontally
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SERVICE_STEPS.forEachIndexed { index, step ->
                            val isStepPassed = currentStepIndex > index
                            val isStepActive = currentStepIndex == index
                            val isStepFuture = currentStepIndex < index

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clickable {
                                        // Allow interactive tap to inspect or advance
                                        onAdvanceStatus?.invoke(step.status)
                                    }
                            ) {
                                // Pulsing halo on currently active step
                                if (isStepActive && !isCancelled) {
                                    Box(
                                        modifier = Modifier
                                            .size((34 * pulseScale).dp)
                                            .clip(CircleShape)
                                            .background(
                                                (if (isCompleted) BlinkitGreen else BlinkitYellowDark).copy(alpha = pulseAlpha)
                                            )
                                    )
                                }

                                // Node Circle
                                Box(
                                    modifier = Modifier
                                        .size(if (isStepActive) 28.dp else 22.dp)
                                        .shadow(if (isStepActive) 4.dp else 1.dp, CircleShape)
                                        .background(
                                            when {
                                                isStepPassed -> BlinkitGreen
                                                isStepActive -> if (isCompleted) BlinkitGreen else BlinkitYellow
                                                else -> Color.White
                                            },
                                            CircleShape
                                        )
                                        .border(
                                            width = if (isStepActive) 2.5.dp else 1.5.dp,
                                            color = when {
                                                isStepPassed -> BlinkitGreenDark
                                                isStepActive -> BlinkitDark
                                                else -> Color(0xFFCBD5E1)
                                            },
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    when {
                                        isStepPassed -> {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = "Passed",
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                        isStepActive -> {
                                            Text(
                                                step.emoji,
                                                fontSize = if (isCompleted) 14.sp else 12.sp
                                            )
                                        }
                                        else -> {
                                            Text(
                                                "${index + 1}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF94A3B8)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Step Labels Row beneath nodes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SERVICE_STEPS.forEachIndexed { index, step ->
                        val isStepActive = currentStepIndex == index
                        val isStepPassed = currentStepIndex > index
                        Text(
                            text = step.shortTitle,
                            fontSize = if (isStepActive) 10.sp else 9.sp,
                            fontWeight = if (isStepActive) FontWeight.ExtraBold else if (isStepPassed) FontWeight.Bold else FontWeight.Normal,
                            color = when {
                                isStepActive -> if (isCompleted) BlinkitGreenDark else BlinkitDark
                                isStepPassed -> BlinkitGreenDark
                                else -> BlinkitTextSecondary
                            },
                            textAlign = when (index) {
                                0 -> TextAlign.Start
                                SERVICE_STEPS.lastIndex -> TextAlign.End
                                else -> TextAlign.Center
                            },
                            modifier = Modifier.width(60.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Current Step Descriptive Banner
            val currentStepInfo = SERVICE_STEPS.getOrNull(currentStepIndex.coerceAtLeast(0)) ?: SERVICE_STEPS.first()
            Surface(
                color = if (isCompleted) BlinkitGreenLight else Color(0xFFF1F5F9),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(0.5.dp, if (isCompleted) BlinkitGreen else BlinkitBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(currentStepInfo.emoji, fontSize = 18.sp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            currentStepInfo.fullTitle,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitDark
                        )
                        Text(
                            currentStepInfo.description,
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // =========================================================================
            // 3. EXPANDABLE DETAILED TIMELINE (Shows real-time transitions checklist)
            // =========================================================================
            AnimatedVisibility(
                visible = isDetailTimelineExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = BlinkitBorder)

                    Text(
                        "Live Transition Milestones",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )

                    SERVICE_STEPS.forEachIndexed { idx, step ->
                        val isPassed = currentStepIndex > idx
                        val isActive = currentStepIndex == idx
                        val isFuture = currentStepIndex < idx

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onAdvanceStatus?.invoke(step.status)
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Milestone Icon
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(
                                        when {
                                            isPassed -> BlinkitGreen
                                            isActive -> BlinkitYellow
                                            else -> Color(0xFFE2E8F0)
                                        },
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isPassed) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                } else {
                                    Text(
                                        step.emoji,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            // Milestone details
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        step.fullTitle,
                                        fontSize = 12.sp,
                                        fontWeight = if (isActive || isPassed) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isFuture) BlinkitTextSecondary else BlinkitDark
                                    )
                                    if (isActive) {
                                        Surface(
                                            color = BlinkitGreenLight,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "CURRENT",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = BlinkitGreenDark,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    step.description,
                                    fontSize = 10.sp,
                                    color = BlinkitTextSecondary
                                )
                            }

                            Text(
                                if (isPassed) "Done ✓" else if (isActive) "In Progress" else step.estimateText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPassed) BlinkitGreenDark else if (isActive) BlinkitDark else BlinkitTextSecondary
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // 4. ACTION BAR & STATUS TRANSITION SIMULATOR
            // =========================================================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Expand / Collapse Detailed Timeline Button
                TextButton(
                    onClick = { isDetailTimelineExpanded = !isDetailTimelineExpanded },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            if (isDetailTimelineExpanded) "Hide Milestones" else "View All Milestones",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitGreenDark
                        )
                        Icon(
                            if (isDetailTimelineExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = BlinkitGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Advance Step Transition Simulator Action
                    if (onAdvanceStatus != null) {
                        val nextStatus = when (order.status) {
                            OrderStatus.PLACED -> OrderStatus.PACKING
                            OrderStatus.PACKING -> OrderStatus.OUT_FOR_DELIVERY
                            OrderStatus.OUT_FOR_DELIVERY -> OrderStatus.IN_SERVICE
                            OrderStatus.IN_SERVICE -> OrderStatus.DELIVERED
                            OrderStatus.DELIVERED -> OrderStatus.PLACED
                            OrderStatus.CANCELLED -> OrderStatus.PLACED
                        }

                        FilledTonalButton(
                            onClick = { onAdvanceStatus(nextStatus) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = BlinkitYellowLight,
                                contentColor = BlinkitDark
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.FastForward,
                                    contentDescription = "Advance Stage",
                                    tint = BlinkitDark,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    if (isCompleted) "Reset ↺" else "Next Step ➔",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Open Full Live Tracker Action
                    if (onOpenTracker != null && !isCompleted && !isCancelled) {
                        Button(
                            onClick = onOpenTracker,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.NearMe,
                                    contentDescription = "Track Pro",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    "Live Track",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
