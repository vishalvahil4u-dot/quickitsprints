package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Blinkit Signature Brand Colors
val BlinkitYellow = Color(0xFFF8CB46)
val BlinkitYellowDark = Color(0xFFE5B017)
val BlinkitYellowLight = Color(0xFFFFF7DB)
val BlinkitYellowSoft = Color(0xFFFEF9E7)

val BlinkitGreen = Color(0xFF0C831F)
val BlinkitGreenDark = Color(0xFF075E14)
val BlinkitGreenLight = Color(0xFFE8F6EA)
val BlinkitGreenContainer = Color(0xFFD2ECD5)

val BlinkitDark = Color(0xFF1C1C1C)
val BlinkitDarkCard = Color(0xFF121212)
val BlinkitSurface = Color(0xFFFFFFFF)
val BlinkitBackground = Color(0xFFF4F6FB)
val BlinkitSurfaceVariant = Color(0xFFF8F9FD)

val BlinkitTextPrimary = Color(0xFF1E2022)
val BlinkitTextSecondary = Color(0xFF686B78)
val BlinkitTextMuted = Color(0xFF9E9E9E)

val BlinkitBorder = Color(0xFFE8E8E8)
val BlinkitBorderSubtle = Color(0xFFF0F0F0)

val BlinkitRed = Color(0xFFE23744)
val BlinkitRedLight = Color(0xFFFFECEE)
val BlinkitOrange = Color(0xFFFF6D00)
val BlinkitOrangeLight = Color(0xFFFFF3E0)
val BlinkitBlue = Color(0xFF1976D2)
val BlinkitBlueLight = Color(0xFFE3F2FD)
val BlinkitPurple = Color(0xFF7B1FA2)
val BlinkitPurpleLight = Color(0xFFF3E5F5)

// Category pastel container accents
val CatVeggiesBg = Color(0xFFE8F5E9)
val CatDairyBg = Color(0xFFE1F5FE)
val CatSnacksBg = Color(0xFFFFF8E1)
val CatDrinksBg = Color(0xFFFFEBEE)
val CatInstantBg = Color(0xFFEDE7F6)
val CatBakeryBg = Color(0xFFFFF3E0)
val CatCareBg = Color(0xFFF3E5F5)
val CatCleanBg = Color(0xFFE0F2F1)
val CatPaanBg = Color(0xFFDCEDC8)
