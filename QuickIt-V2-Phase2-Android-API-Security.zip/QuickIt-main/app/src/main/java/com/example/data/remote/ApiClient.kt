package com.example.data.remote

import android.content.Context
import com.example.BuildConfig
import com.example.data.auth.AuthSessionStore
import com.squareup.moshi.Moshi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.UUID
import java.util.concurrent.TimeUnit

class AuthInterceptor(private val sessionStore: AuthSessionStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .header("Accept", "application/json")
            .header("X-Request-ID", UUID.randomUUID().toString())

        val token = runBlocking { sessionStore.token.first() }
        if (!token.isNullOrBlank()) {
            request.header("Authorization", "Bearer $token")
        }
        return chain.proceed(request.build())
    }
}

object ApiClient {
    @Volatile private var api: QuickItApi? = null

    fun initialize(context: Context): QuickItApi {
        return api ?: synchronized(this) {
            api ?: build(context.applicationContext).also { api = it }
        }
    }

    private fun build(context: Context): QuickItApi {
        val baseUrl = BuildConfig.API_BASE_URL.trim().let {
            if (it.endsWith('/')) it else "$it/"
        }
        require(baseUrl.startsWith("https://")) {
            "API_BASE_URL must use HTTPS in production"
        }

        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(AuthSessionStore(context)))
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(Moshi.Builder().build()))
            .build()
            .create(QuickItApi::class.java)
    }
}
