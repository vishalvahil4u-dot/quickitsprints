package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.BlinkitRepository
import com.example.data.NearbyServiceProvider
import com.example.data.ServiceItem
import com.example.data.TechnicianStatus
import com.example.ui.theme.*

/**
 * Service Offering Category Pillar definition with visual iconography and styling.
 */
enum class ServiceCategoryPillar(
    val categoryId: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val emoji: String,
    val badge: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val accentColor: Color,
    val lightBg: Color,
    val darkStoreTechsReady: Int,
    val guaranteeText: String
) {
    PLUMBING(
        categoryId = "cat_plumbing",
        title = "Plumbing",
        subtitle = "Taps, Drains, Pipes & Water Tanks",
        icon = Icons.Default.Plumbing,
        emoji = "🔧",
        badge = "⚡ 10-Min Dispatch",
        primaryColor = Color(0xFF00897B),
        secondaryColor = Color(0xFF004D40),
        accentColor = Color(0xFF26A69A),
        lightBg = Color(0xFFE0F2F1),
        darkStoreTechsReady = 8,
        guaranteeText = "30-Day Zero Leak Guarantee • CPVC & Brass Parts"
    ),
    ELECTRICAL(
        categoryId = "cat_electric",
        title = "Electrical",
        subtitle = "Wiring, Fans, MCB & Sockets",
        icon = Icons.Default.ElectricalServices,
        emoji = "⚡",
        badge = "🦺 1000V Insulated",
        primaryColor = Color(0xFFE65100),
        secondaryColor = Color(0xFFBF360C),
        accentColor = Color(0xFFFFB300),
        lightBg = Color(0xFFFFF3E0),
        darkStoreTechsReady = 7,
        guaranteeText = "BIS Compliant • Fire-Safe Insulated Tools"
    ),
    CLEANING(
        categoryId = "cat_cleaning",
        title = "Deep Cleaning",
        subtitle = "Bathrooms, Kitchens & Sofas",
        icon = Icons.Default.CleaningServices,
        emoji = "✨",
        badge = "💧 Sparkle Clean",
        primaryColor = Color(0xFF0288D1),
        secondaryColor = Color(0xFF01579B),
        accentColor = Color(0xFF29B6F6),
        lightBg = Color(0xFFE1F5FE),
        darkStoreTechsReady = 9,
        guaranteeText = "100% Sparkle Guarantee • Eco-Safe Diversey Solvents"
    ),
    APPLIANCE_CARE(
        categoryId = "cat_appliance",
        title = "Appliance Care",
        subtitle = "AC Jet Wash, Fridge & Washing",
        icon = Icons.Default.HomeRepairService,
        emoji = "❄️",
        badge = "🛡️ 60-Day SLA",
        primaryColor = Color(0xFF6A1B9A),
        secondaryColor = Color(0xFF4A148C),
        accentColor = Color(0xFFAB47BC),
        lightBg = Color(0xFFEDE7F6),
        darkStoreTechsReady = 6,
        guaranteeText = "60-Day Cooling & Rework Guarantee • Genuine Spares"
    );

    companion object {
        fun fromCategoryId(id: String): ServiceCategoryPillar? {
            return entries.firstOrNull { it.categoryId == id }
        }
    }
}

/**
 * Real-time capacity data computed per category based on active technicians in vicinity.
 */
data class CategoryVicinityCapacity(
    val pillar: ServiceCategoryPillar,
    val availableCount: Int,
    val totalNearbyCount: Int,
    val fastestEtaMinutes: Int,
    val closestDistanceKm: Double,
    val closestLandmark: String,
    val leadTechnician: NearbyServiceProvider?,
    val isAvailableNow: Boolean,
    val capacityLevel: String // "High Availability", "Moderate", "Limited"
)

/**
 * High-fidelity Service Selection Component categorizing offerings into
 * Plumbing, Electrical, Cleaning, and Appliance Care with real-time 'Available Now' indicators.
 */
@Composable
fun ServiceSelectionComponent(
    repository: BlinkitRepository,
    modifier: Modifier = Modifier,
    selectedCategoryPillar: ServiceCategoryPillar = ServiceCategoryPillar.PLUMBING,
    onCategoryChanged: (ServiceCategoryPillar) -> Unit = {},
    onServiceSelected: (ServiceItem) -> Unit = {},
    showSearchAndFilters: Boolean = true
) {
    val allServices by repository.services.collectAsState()
    val nearbyProviders by repository.nearbyProviders.collectAsState()

    var activePillar by remember(selectedCategoryPillar) { mutableStateOf(selectedCategoryPillar) }
    var selectedSubCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var filterBestsellersOnly by remember { mutableStateOf(false) }
    var selectedServiceForModal by remember { mutableStateOf<ServiceItem?>(null) }
    var showFleetInspectionModal by remember { mutableStateOf<CategoryVicinityCapacity?>(null) }

    // Real-time calculation of technician vicinity capacity for all category pillars
    val vicinityCapacities = remember(nearbyProviders) {
        ServiceCategoryPillar.entries.associateWith { pillar ->
            val matchingProviders = nearbyProviders.filter { it.categoryId == pillar.categoryId }
            val availableProviders = matchingProviders.filter {
                it.status == TechnicianStatus.AVAILABLE && it.isAvailableNow
            }
            val closestTech = availableProviders.minByOrNull { it.distanceKm } ?: matchingProviders.minByOrNull { it.distanceKm }
            val availableCount = availableProviders.size
            val isAvail = availableCount > 0

            val capacityLevel = when {
                availableCount >= 2 -> "High Capacity"
                availableCount == 1 -> "1 Pro Ready"
                else -> "Next Slot in 20m"
            }

            CategoryVicinityCapacity(
                pillar = pillar,
                availableCount = availableCount,
                totalNearbyCount = matchingProviders.size,
                fastestEtaMinutes = closestTech?.etaMinutes ?: 10,
                closestDistanceKm = closestTech?.distanceKm ?: 0.5,
                closestLandmark = closestTech?.currentVicinityLandmark ?: "Indiranagar 100ft Hub",
                leadTechnician = closestTech,
                isAvailableNow = isAvail,
                capacityLevel = capacityLevel
            )
        }
    }

    val activeCapacity = vicinityCapacities[activePillar] ?: CategoryVicinityCapacity(
        pillar = activePillar,
        availableCount = 2,
        totalNearbyCount = 2,
        fastestEtaMinutes = 6,
        closestDistanceKm = 0.4,
        closestLandmark = "Indiranagar 100ft Metro",
        leadTechnician = null,
        isAvailableNow = true,
        capacityLevel = "High Capacity"
    )

    // Filter services belonging to the active pillar
    val pillarServices = remember(allServices, activePillar, selectedSubCategory, searchQuery, filterBestsellersOnly) {
        allServices.filter { service ->
            val matchesCategory = service.categoryId == activePillar.categoryId
            val matchesSub = selectedSubCategory == "All" || service.subCategory.equals(selectedSubCategory, ignoreCase = true)
            val matchesSearch = searchQuery.isEmpty() ||
                    service.name.contains(searchQuery, ignoreCase = true) ||
                    service.subCategory.contains(searchQuery, ignoreCase = true) ||
                    service.description.contains(searchQuery, ignoreCase = true)
            val matchesBestseller = !filterBestsellersOnly || service.isBestseller
            matchesCategory && matchesSub && matchesSearch && matchesBestseller
        }
    }

    // Extract unique subcategories for the active pillar
    val subCategories = remember(allServices, activePillar) {
        val subs = allServices
            .filter { it.categoryId == activePillar.categoryId }
            .map { it.subCategory }
            .distinct()
        listOf("All") + subs
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("service_selection_component"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Component Section Header with Global Vicinity Technician Ready Summary
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.Category,
                        contentDescription = null,
                        tint = BlinkitGreenDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        "Service Categories",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )
                }
                Text(
                    "Real-time technician dispatch across 4 pillars",
                    fontSize = 11.sp,
                    color = BlinkitTextSecondary
                )
            }

            // Live Pulse Badge showing instant availability
            Box(
                modifier = Modifier
                    .background(BlinkitGreenLight, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    PulsingLiveDot(color = BlinkitGreen, sizeDp = 7)
                    Text(
                        "Vicinity Fleet Live",
                        color = BlinkitGreenDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        // 2. Visual Category Selection Cards with Live 'Available Now' Indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ServiceCategoryPillar.entries.forEach { pillar ->
                val isSelected = activePillar == pillar
                val count = allServices.count { it.categoryId == pillar.categoryId }
                val capacity = vicinityCapacities[pillar]

                VisualCategoryCard(
                    pillar = pillar,
                    serviceCount = count,
                    capacity = capacity,
                    isSelected = isSelected,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        activePillar = pillar
                        selectedSubCategory = "All"
                        onCategoryChanged(pillar)
                    }
                )
            }
        }

        // 3. Category Hub Status, Live Technician Pro Proximity & Guarantee Banner
        CategoryStatusBanner(
            pillar = activePillar,
            capacity = activeCapacity,
            onInspectFleet = {
                showFleetInspectionModal = activeCapacity
            },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // 4. Search & Sub-category Filter Row
        if (showSearchAndFilters) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("service_search_bar"),
                    placeholder = {
                        Text(
                            "Search ${activePillar.title} services (e.g. tap, wire, fan)...",
                            fontSize = 12.sp,
                            color = BlinkitTextMuted
                        )
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = null,
                            tint = activePillar.primaryColor,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = BlinkitTextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = activePillar.primaryColor,
                        unfocusedBorderColor = BlinkitBorder,
                        focusedContainerColor = BlinkitSurface,
                        unfocusedContainerColor = BlinkitSurface
                    )
                )

                // Sub-category Filter Chips & Bestseller Toggle
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bestseller Quick Filter
                    item {
                        FilterChip(
                            selected = filterBestsellersOnly,
                            onClick = { filterBestsellersOnly = !filterBestsellersOnly },
                            label = {
                                Text(
                                    "🔥 Bestsellers",
                                    fontSize = 11.sp,
                                    fontWeight = if (filterBestsellersOnly) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BlinkitYellow,
                                selectedLabelColor = BlinkitDark,
                                containerColor = BlinkitSurfaceVariant,
                                labelColor = BlinkitTextSecondary
                            ),
                            border = BorderStroke(1.dp, if (filterBestsellersOnly) BlinkitYellowDark else BlinkitBorder),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.height(32.dp)
                        )
                    }

                    items(subCategories) { subCat ->
                        val isSelected = selectedSubCategory == subCat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedSubCategory = subCat },
                            label = {
                                Text(
                                    subCat,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = activePillar.primaryColor,
                                selectedLabelColor = Color.White,
                                containerColor = BlinkitSurfaceVariant,
                                labelColor = BlinkitTextSecondary
                            ),
                            border = BorderStroke(1.dp, if (isSelected) activePillar.primaryColor else BlinkitBorder),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.height(32.dp)
                        )
                    }
                }
            }
        }

        // 5. Offerings List Header with Count & Instant Arrival Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${activePillar.title} Offerings (${pillarServices.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitTextPrimary
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PulsingLiveDot(color = BlinkitGreen, sizeDp = 6)
                Text(
                    "⚡ Arrives in ${activeCapacity.fastestEtaMinutes} mins",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BlinkitGreenDark
                )
            }
        }

        // 6. Offerings Cards with Available Now Badges
        if (pillarServices.isEmpty()) {
            // Empty State
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                border = BorderStroke(1.dp, BlinkitBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(activePillar.emoji, fontSize = 32.sp)
                    Text(
                        "No services found matching filters",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitTextPrimary
                    )
                    Text(
                        "Try resetting the subcategory or search term.",
                        fontSize = 12.sp,
                        color = BlinkitTextSecondary
                    )
                    TextButton(onClick = {
                        searchQuery = ""
                        selectedSubCategory = "All"
                        filterBestsellersOnly = false
                    }) {
                        Text("Reset Filters", color = activePillar.primaryColor, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pillarServices.forEach { service ->
                    val quantity = repository.getServiceQuantity(service.id)
                    CategorizedOfferingCard(
                        service = service,
                        pillar = activePillar,
                        capacity = activeCapacity,
                        quantity = quantity,
                        onAdd = { repository.addToCart(service) },
                        onRemove = { repository.removeFromCart(service.id) },
                        onClick = {
                            selectedServiceForModal = service
                            onServiceSelected(service)
                        }
                    )
                }
            }
        }
    }

    // Modal dialog for detailed task inspection
    selectedServiceForModal?.let { service ->
        ServiceDetailModalDialog(
            service = service,
            pillar = activePillar,
            capacity = activeCapacity,
            quantity = repository.getServiceQuantity(service.id),
            onAdd = { repository.addToCart(service) },
            onRemove = { repository.removeFromCart(service.id) },
            onDismiss = { selectedServiceForModal = null }
        )
    }

    // Modal dialog for inspecting nearby technician capacity breakdown
    showFleetInspectionModal?.let { capacity ->
        VicinityFleetInspectionDialog(
            capacity = capacity,
            providers = nearbyProviders.filter { it.categoryId == capacity.pillar.categoryId },
            onDismiss = { showFleetInspectionModal = null }
        )
    }
}

/**
 * Animated Pulsing Dot representing live real-time capacity / availability.
 */
@Composable
fun PulsingLiveDot(
    color: Color = BlinkitGreen,
    sizeDp: Int = 6,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .size((sizeDp + 4).dp),
        contentAlignment = Alignment.Center
    ) {
        // Glowing halo
        Box(
            modifier = Modifier
                .size((sizeDp + 4).dp)
                .scale(scale)
                .background(color.copy(alpha = alpha * 0.35f), CircleShape)
        )
        // Core dot
        Box(
            modifier = Modifier
                .size(sizeDp.dp)
                .background(color, CircleShape)
        )
    }
}

/**
 * Visual Category Card for selecting between the 4 primary pillars with 'Available Now' status.
 */
@Composable
private fun VisualCategoryCard(
    pillar: ServiceCategoryPillar,
    serviceCount: Int,
    capacity: CategoryVicinityCapacity?,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val isAvail = capacity?.isAvailableNow ?: true
    val eta = capacity?.fastestEtaMinutes ?: 10
    val availCount = capacity?.availableCount ?: 2

    Card(
        modifier = modifier
            .testTag("category_card_${pillar.categoryId}")
            .clickable { onClick() }
            .then(
                if (isSelected) {
                    Modifier.shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), spotColor = pillar.primaryColor)
                } else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) pillar.lightBg else BlinkitSurface
        ),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) pillar.primaryColor else BlinkitBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Top Live 'Available Now' / ETA Tag
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (isAvail) BlinkitGreenLight else BlinkitSurfaceVariant
                    )
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    if (isAvail) {
                        PulsingLiveDot(color = BlinkitGreen, sizeDp = 5)
                        Text(
                            "Available Now",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitGreenDark,
                            maxLines = 1
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .background(BlinkitTextMuted, CircleShape)
                        )
                        Text(
                            "Busy",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitTextSecondary
                        )
                    }
                }
            }

            // Visual Icon Container with Accent Background
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSelected) {
                            Brush.linearGradient(listOf(pillar.primaryColor, pillar.secondaryColor))
                        } else {
                            Brush.linearGradient(listOf(pillar.lightBg, Color.White))
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = pillar.icon,
                    contentDescription = pillar.title,
                    tint = if (isSelected) Color.White else pillar.primaryColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Title
            Text(
                text = pillar.title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                color = if (isSelected) pillar.secondaryColor else BlinkitTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // ETA & Capacity Footnote
            Text(
                text = "⚡ ${eta}m • $availCount free",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) pillar.primaryColor else BlinkitGreenDark,
                maxLines = 1
            )
        }
    }
}

/**
 * Hub Status, Live Technician Pro Proximity, and Vicinity Capacity Banner for active category pillar.
 */
@Composable
private fun CategoryStatusBanner(
    pillar: ServiceCategoryPillar,
    capacity: CategoryVicinityCapacity,
    onInspectFleet: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = pillar.lightBg),
        border = BorderStroke(1.dp, pillar.accentColor.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Row: Category title, Live 'Available Now' status & Inspection Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(pillar.primaryColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(pillar.emoji, fontSize = 16.sp)
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "${pillar.title} Vicinity Capacity",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = pillar.secondaryColor
                            )
                            Box(
                                modifier = Modifier
                                    .background(BlinkitGreen, RoundedCornerShape(50))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(modifier = Modifier.size(5.dp).background(Color.White, CircleShape))
                                    Text(
                                        "AVAILABLE NOW",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }

                        Text(
                            pillar.guaranteeText,
                            fontSize = 10.sp,
                            color = BlinkitTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Action chip to view all available technicians
                Box(
                    modifier = Modifier
                        .clickable { onInspectFleet() }
                        .background(Color.White, RoundedCornerShape(8.dp))
                        .border(1.dp, pillar.primaryColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            "${capacity.availableCount} Pros",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = pillar.primaryColor
                        )
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "View fleet",
                            tint = pillar.primaryColor,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            // Lead Nearby Technician Dispatch Proximity Strip
            capacity.leadTechnician?.let { tech ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(tech.avatarEmoji, fontSize = 16.sp)
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    tech.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitTextPrimary
                                )
                                Text(
                                    "★ ${tech.rating}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitYellowDark
                                )
                            }
                            Text(
                                "${tech.distanceKm} km away near ${tech.currentVicinityLandmark}",
                                fontSize = 9.sp,
                                color = BlinkitTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .background(BlinkitGreenLight, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            "⚡ ${tech.etaMinutes}m ETA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitGreenDark
                        )
                    }
                }
            }
        }
    }
}

/**
 * Categorized Offering Card component with rich visuals, price strikethrough,
 * task list preview, dynamic Available Now live indicator, and quantity stepper.
 */
@Composable
fun CategorizedOfferingCard(
    service: ServiceItem,
    pillar: ServiceCategoryPillar,
    capacity: CategoryVicinityCapacity,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("offering_card_${service.id}")
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, if (quantity > 0) BlinkitGreen else BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Category Tag, Available Now Indicator, Bestseller Badge, ETA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Subcategory pill
                    Box(
                        modifier = Modifier
                            .background(pillar.lightBg, RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            service.subCategory,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = pillar.primaryColor
                        )
                    }

                    // Available Now Live Pill
                    Box(
                        modifier = Modifier
                            .background(BlinkitGreenLight, RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            PulsingLiveDot(color = BlinkitGreen, sizeDp = 5)
                            Text(
                                "Available Now",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitGreenDark
                            )
                        }
                    }

                    if (service.isBestseller) {
                        Box(
                            modifier = Modifier
                                .background(BlinkitYellow, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                "🔥 BESTSELLER",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitDark
                            )
                        }
                    }
                }

                // ETA Badge linked with fastest vicinity arrival
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        Icons.Default.Bolt,
                        contentDescription = null,
                        tint = BlinkitGreen,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        "${capacity.fastestEtaMinutes} mins",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitGreenDark
                    )
                }
            }

            // Middle Row: Service Name, Description & Visual Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = service.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitTextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = service.description,
                        fontSize = 11.sp,
                        color = BlinkitTextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Emoji & Vector Icon Visual Container
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(pillar.lightBg)
                        .border(1.dp, pillar.primaryColor.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = service.emoji,
                        fontSize = 24.sp
                    )
                }
            }

            // Key Included Tasks Preview (First 2 tasks)
            if (service.includedTasks.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlinkitSurfaceVariant, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    service.includedTasks.take(2).forEach { task ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BlinkitGreen,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                task,
                                fontSize = 10.sp,
                                color = BlinkitTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Bottom Bar: Price, Rating, Duration & ADD / Stepper Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Price + Rating Column
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "₹${service.price.toInt()}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        if (service.originalPrice > service.price) {
                            Text(
                                "₹${service.originalPrice.toInt()}",
                                fontSize = 12.sp,
                                color = BlinkitTextMuted,
                                textDecoration = TextDecoration.LineThrough
                            )
                            Box(
                                modifier = Modifier
                                    .background(BlinkitGreenLight, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    "${service.discountPercent}% OFF",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitGreenDark
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = BlinkitYellowDark,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            "${service.rating}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitTextPrimary
                        )
                        Text(
                            "(${service.ratingCount}) • ${service.duration}",
                            fontSize = 10.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }

                // ADD Button / Stepper
                if (quantity == 0) {
                    Button(
                        onClick = onAdd,
                        modifier = Modifier
                            .testTag("add_service_${service.id}")
                            .height(36.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BlinkitGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "ADD",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .height(36.dp)
                            .background(BlinkitGreen, RoundedCornerShape(10.dp))
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = onRemove,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Remove,
                                contentDescription = "Decrease",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Text(
                            "$quantity",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )

                        IconButton(
                            onClick = onAdd,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Increase",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Service Detail Modal Dialog providing deep inspection of included tasks,
 * required toolkits, vicinity capacity, and guarantee details.
 */
@Composable
private fun ServiceDetailModalDialog(
    service: ServiceItem,
    pillar: ServiceCategoryPillar,
    capacity: CategoryVicinityCapacity,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header: SLA Badge, Available Now & Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(BlinkitGreenLight, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                PulsingLiveDot(color = BlinkitGreen, sizeDp = 5)
                                Text(
                                    "AVAILABLE NOW • ${capacity.fastestEtaMinutes} MINS",
                                    color = BlinkitGreenDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                // Title and Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(pillar.lightBg, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(service.emoji, fontSize = 28.sp)
                    }
                    Column {
                        Text(
                            service.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitTextPrimary
                        )
                        Text(
                            "${pillar.title} • ${service.subCategory}",
                            fontSize = 12.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }

                Text(
                    service.description,
                    fontSize = 13.sp,
                    color = BlinkitTextSecondary,
                    lineHeight = 18.sp
                )

                // Vicinity Pro & Certified Toolkit Info
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.NearMe, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                            Text(
                                "Nearest Pro: ${capacity.leadTechnician?.name ?: "Verified Specialist"} (~${capacity.closestDistanceKm}km away)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitTextPrimary
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Handyman, contentDescription = null, tint = pillar.primaryColor, modifier = Modifier.size(16.dp))
                            Text(
                                "Kit: ${service.toolkitRequired}",
                                fontSize = 11.sp,
                                color = BlinkitTextSecondary
                            )
                        }
                    }
                }

                // Included tasks
                Text("What's Included in this service:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    service.includedTasks.forEach { task ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                            Text(task, fontSize = 12.sp, color = BlinkitTextPrimary)
                        }
                    }
                }

                Divider(color = BlinkitBorder)

                // Price & Add to Cart
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("₹${service.price.toInt()}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = BlinkitTextPrimary)
                        Text("30-Day Guarantee Included", fontSize = 11.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                    }

                    if (quantity == 0) {
                        Button(
                            onClick = onAdd,
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("ADD TO CART", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .background(BlinkitGreen, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Remove, contentDescription = "Minus", tint = Color.White)
                            }
                            Text("$quantity", color = Color.White, fontWeight = FontWeight.Bold)
                            IconButton(onClick = onAdd, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Add, contentDescription = "Plus", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Inspection Dialog displaying all active technicians in the user's vicinity for the category.
 */
@Composable
private fun VicinityFleetInspectionDialog(
    capacity: CategoryVicinityCapacity,
    providers: List<NearbyServiceProvider>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(capacity.pillar.emoji, fontSize = 22.sp)
                        Column {
                            Text(
                                "${capacity.pillar.title} Vicinity Fleet",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitTextPrimary
                            )
                            Text(
                                "${capacity.availableCount} Available Now near your location",
                                fontSize = 11.sp,
                                color = BlinkitGreenDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                Divider(color = BlinkitBorder)

                // List of Nearby Techs
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    providers.forEach { tech ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (tech.isAvailableNow) capacity.pillar.lightBg else BlinkitSurfaceVariant
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (tech.isAvailableNow) capacity.pillar.primaryColor.copy(alpha = 0.3f) else BlinkitBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color.White, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(tech.avatarEmoji, fontSize = 20.sp)
                                    }
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                tech.name,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = BlinkitTextPrimary
                                            )
                                            Text(
                                                "★ ${tech.rating}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = BlinkitYellowDark
                                            )
                                        }
                                        Text(
                                            "${tech.speciality} • ${tech.vehicleType}",
                                            fontSize = 10.sp,
                                            color = BlinkitTextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "📍 ${tech.distanceKm} km (${tech.currentVicinityLandmark})",
                                            fontSize = 10.sp,
                                            color = BlinkitTextPrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(BlinkitGreen, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        "⚡ ${tech.etaMinutes}m ETA",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = capacity.pillar.primaryColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Select a Service to Dispatch", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

