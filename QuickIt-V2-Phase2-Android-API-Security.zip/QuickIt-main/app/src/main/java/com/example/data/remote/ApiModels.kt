package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ApiEnvelope<T>(
    val success: Boolean,
    val message: String? = null,
    val data: T? = null
)

@JsonClass(generateAdapter = true)
data class LoginRequest(
    val email: String,
    val password: String
)

@JsonClass(generateAdapter = true)
data class RegisterRequest(
    val email: String,
    val password: String,
    @Json(name = "full_name") val fullName: String,
    val phone: String? = null,
    val role: String = "customer",
    val address: String? = null
)

@JsonClass(generateAdapter = true)
data class AuthUserDto(
    val id: Long,
    val email: String,
    @Json(name = "full_name") val fullName: String,
    val role: String,
    val phone: String? = null,
    val address: String? = null
)

@JsonClass(generateAdapter = true)
data class AuthDataDto(
    val token: String,
    val user: AuthUserDto
)

@JsonClass(generateAdapter = true)
data class BookingCreateRequest(
    @Json(name = "service_id") val serviceId: Long,
    @Json(name = "provider_id") val providerId: Long? = null,
    @Json(name = "scheduled_at") val scheduledAt: String? = null,
    val address: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val notes: String? = null
)

@JsonClass(generateAdapter = true)
data class PaymentInitiateRequest(@Json(name = "booking_id") val bookingId: Long)

@JsonClass(generateAdapter = true)
data class PaymentConfirmRequest(
    @Json(name = "booking_id") val bookingId: Long,
    @Json(name = "payment_id") val paymentId: String,
    @Json(name = "order_id") val orderId: String,
    val signature: String
)

@JsonClass(generateAdapter = true)
data class PaymentOrderDto(
    @Json(name = "order_id") val orderId: String,
    @Json(name = "amount_paise") val amountPaise: Long,
    val currency: String = "INR",
    @Json(name = "key_id") val keyId: String? = null
)
