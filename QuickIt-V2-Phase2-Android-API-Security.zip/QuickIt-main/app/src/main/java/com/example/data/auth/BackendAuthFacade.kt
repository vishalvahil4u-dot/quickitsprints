package com.example.data.auth

import android.content.Context
import com.example.data.remote.ApiClient
import com.example.data.remote.AuthUserDto
import com.example.data.remote.RegisterRequest
import com.example.domain.auth.AuthRepository
import com.example.domain.auth.AuthResult
import kotlinx.coroutines.flow.Flow

/** Small integration boundary for UI layers migrating away from the monolithic repository. */
class BackendAuthFacade(context: Context) {
    private val sessionStore = AuthSessionStore(context.applicationContext)
    private val repository = AuthRepository(context.applicationContext, ApiClient.initialize(context))

    val accessToken: Flow<String?> = sessionStore.token

    suspend fun login(email: String, password: String) = repository.login(email, password)

    suspend fun register(request: RegisterRequest) = repository.register(request)

    suspend fun currentUser(): AuthResult<AuthUserDto> = repository.currentUser()

    suspend fun logout() = repository.logout()
}
