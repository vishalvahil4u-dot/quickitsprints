package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BlinkitColorScheme = lightColorScheme(
    primary = BlinkitGreen,
    onPrimary = Color.White,
    primaryContainer = BlinkitGreenLight,
    onPrimaryContainer = BlinkitGreenDark,
    secondary = BlinkitYellow,
    onSecondary = BlinkitDark,
    secondaryContainer = BlinkitYellowLight,
    onSecondaryContainer = BlinkitDark,
    tertiary = BlinkitBlue,
    onTertiary = Color.White,
    background = BlinkitBackground,
    onBackground = BlinkitTextPrimary,
    surface = BlinkitSurface,
    onSurface = BlinkitTextPrimary,
    surfaceVariant = BlinkitSurfaceVariant,
    onSurfaceVariant = BlinkitTextSecondary,
    outline = BlinkitBorder,
    outlineVariant = BlinkitBorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = BlinkitColorScheme,
        typography = Typography,
        content = content
    )
}
