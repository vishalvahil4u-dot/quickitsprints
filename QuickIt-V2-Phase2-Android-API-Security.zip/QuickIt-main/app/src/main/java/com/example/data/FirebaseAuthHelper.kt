package com.example.data

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.UUID

data class UserProfile(
    val uid: String,
    val displayName: String,
    val email: String,
    val photoUrl: String? = null,
    val phone: String = "+91 98765 43210",
    val membershipLevel: String = "QuickIt Black Club Pro",
    val isVerified: Boolean = true,
    val savedAddressesCount: Int = 3
)

class FirebaseAuthHelper(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val credentialManager: CredentialManager by lazy { CredentialManager.create(context) }

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    init {
        checkCurrentAuthState()
    }

    private fun checkCurrentAuthState() {
        try {
            val user = auth.currentUser
            if (user != null) {
                _currentUser.value = UserProfile(
                    uid = user.uid,
                    displayName = user.displayName ?: "Verified Customer",
                    email = user.email ?: "customer@quickit.com",
                    photoUrl = user.photoUrl?.toString()
                )
            } else {
                _currentUser.value = null
            }
        } catch (e: Exception) {
            Log.e("FirebaseAuthHelper", "Firebase Auth initialization failed", e)
            _currentUser.value = null
            _authError.value = "Authentication is unavailable. Please try again."
        }
    }

    suspend fun signInWithGoogle(): Boolean = withContext(Dispatchers.IO) {
        _isAuthLoading.value = true
        _authError.value = null
        try {
            // Setup Google ID Option
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(com.example.BuildConfig.GOOGLE_SERVER_CLIENT_ID)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(
                request = request,
                context = context
            )

            val credential = result.credential
            if (credential is GoogleIdTokenCredential) {
                val googleIdToken = credential.idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                val authResult = auth.signInWithCredential(authCredential).await()
                val firebaseUser = authResult.user

                if (firebaseUser != null) {
                    val profile = UserProfile(
                        uid = firebaseUser.uid,
                        displayName = firebaseUser.displayName ?: "Google User",
                        email = firebaseUser.email ?: "",
                        photoUrl = firebaseUser.photoUrl?.toString()
                    )
                    _currentUser.value = profile
                    saveUserProfileToFirestore(profile)
                    _isAuthLoading.value = false
                    return@withContext true
                }
            }
            _isAuthLoading.value = false
            return@withContext false
        } catch (e: GetCredentialException) {
            Log.w("FirebaseAuthHelper", "Google Sign-in failed: ${e.message}")
            _authError.value = "Google sign-in was cancelled or unavailable."
            _isAuthLoading.value = false
            return@withContext false
        } catch (e: Exception) {
            Log.e("FirebaseAuthHelper", "Sign in error", e)
            _authError.value = e.localizedMessage ?: "Authentication failed"
            _isAuthLoading.value = false
            return@withContext false
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Boolean = withContext(Dispatchers.IO) {
        _isAuthLoading.value = true
        _authError.value = null
        try {
            val authResult = auth.signInWithEmailAndPassword(email, pass).await()
            val user = authResult.user
            if (user != null) {
                val profile = UserProfile(
                    uid = user.uid,
                    displayName = user.displayName ?: email.substringBefore("@"),
                    email = user.email ?: email
                )
                _currentUser.value = profile
                saveUserProfileToFirestore(profile)
                _isAuthLoading.value = false
                return@withContext true
            }
            _isAuthLoading.value = false
            return@withContext false
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Email login failed: ${e.message}")
            _authError.value = "Invalid email or password."
            _isAuthLoading.value = false
            return@withContext false
        }
    }

    fun signOut() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Sign out note: ${e.message}")
        }
        _currentUser.value = null
    }

    // --- FIRESTORE PERSISTENCE METHODS ---

    suspend fun toggleFavoriteProviderInFirestore(
        providerId: String,
        provider: NearbyServiceProvider?,
        isFavorite: Boolean
    ) = withContext(Dispatchers.IO) {
        try {
            val uid = _currentUser.value?.uid ?: "guest"
            val userDoc = firestore.collection("users").document(uid)
            val favDoc = userDoc.collection("favorite_providers").document(providerId)

            if (isFavorite) {
                val favMap = hashMapOf(
                    "providerId" to providerId,
                    "name" to (provider?.name ?: ""),
                    "speciality" to (provider?.speciality ?: ""),
                    "rating" to (provider?.rating ?: 4.9),
                    "avatarEmoji" to (provider?.avatarEmoji ?: "👨‍🔧"),
                    "categoryId" to (provider?.categoryId ?: "cat_plumbing"),
                    "starredAt" to System.currentTimeMillis()
                )
                favDoc.set(favMap, SetOptions.merge()).await()
                userDoc.update("favoriteProviderIds", com.google.firebase.firestore.FieldValue.arrayUnion(providerId)).await()
            } else {
                favDoc.delete().await()
                userDoc.update("favoriteProviderIds", com.google.firebase.firestore.FieldValue.arrayRemove(providerId)).await()
            }
            Log.d("FirebaseAuthHelper", "Firestore favorite synced for $providerId: isFavorite=$isFavorite")
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Firestore favorite sync note: ${e.message}")
        }
    }

    suspend fun loadFavoriteProvidersFromFirestore(): Set<String> = withContext(Dispatchers.IO) {
        try {
            val uid = _currentUser.value?.uid ?: "guest"
            val snapshot = firestore.collection("users").document(uid)
                .collection("favorite_providers")
                .get()
                .await()
            snapshot.documents.map { it.id }.toSet()
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Firestore fetch favorites note: ${e.message}")
            emptySet()
        }
    }

    suspend fun saveUserProfileToFirestore(profile: UserProfile) = withContext(Dispatchers.IO) {
        try {
            val map = mapOf(
                "uid" to profile.uid,
                "displayName" to profile.displayName,
                "email" to profile.email,
                "photoUrl" to (profile.photoUrl ?: ""),
                "membershipLevel" to profile.membershipLevel,
                "lastActive" to System.currentTimeMillis()
            )
            firestore.collection("users").document(profile.uid)
                .set(map, SetOptions.merge())
                .await()
            Log.d("FirebaseAuthHelper", "User profile synced with Firestore")
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Firestore profile sync note: ${e.message}")
        }
    }

    suspend fun saveBookingToFirestore(order: OrderItem) = withContext(Dispatchers.IO) {
        try {
            val uid = _currentUser.value?.uid ?: "guest"
            val orderMap = hashMapOf(
                "orderId" to order.id,
                "orderNumber" to order.orderNumber,
                "userId" to uid,
                "itemTotal" to order.itemTotal,
                "grandTotal" to order.grandTotal,
                "status" to order.status.name,
                "placedAt" to order.placedAtTime,
                "riderName" to order.riderName,
                "otpCode" to order.otpCode,
                "addressLine" to order.address.addressLine,
                "itemsCount" to order.items.size,
                "timestamp" to System.currentTimeMillis()
            )

            firestore.collection("bookings").document(order.id)
                .set(orderMap, SetOptions.merge())
                .await()

            firestore.collection("users").document(uid)
                .collection("user_bookings").document(order.id)
                .set(orderMap, SetOptions.merge())
                .await()

            Log.d("FirebaseAuthHelper", "Booking saved to Firestore: ${order.orderNumber}")
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Firestore booking save note: ${e.message}")
        }
    }

    suspend fun loadBookingsFromFirestore(): List<Map<String, Any>> = withContext(Dispatchers.IO) {
        try {
            val uid = _currentUser.value?.uid ?: "guest"
            val snapshot = firestore.collection("users").document(uid)
                .collection("user_bookings")
                .get()
                .await()

            snapshot.documents.mapNotNull { it.data }
        } catch (e: Exception) {
            Log.w("FirebaseAuthHelper", "Firestore bookings fetch note: ${e.message}")
            emptyList()
        }
    }
}
