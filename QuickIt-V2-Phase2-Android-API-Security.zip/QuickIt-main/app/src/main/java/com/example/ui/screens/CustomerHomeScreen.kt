package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun CustomerHomeScreen(
    repository: BlinkitRepository,
    onOpenCart: () -> Unit,
    onOpenOrderTracker: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onSwitchToAdmin: () -> Unit = {}
) {
    val categories by repository.categories.collectAsState()
    val services by repository.services.collectAsState()
    val cart by repository.cart.collectAsState()
    val activeOrder by repository.activeOrder.collectAsState()
    val pastOrders by repository.pastOrders.collectAsState()
    val allOrders by repository.allOrders.collectAsState()
    val selectedAddress by repository.selectedAddress.collectAsState()
    val currentUser by repository.currentUser.collectAsState()

    var selectedCategoryId by remember { mutableStateOf("cat_all") }
    var searchQuery by remember { mutableStateOf("") }
    var selectedServiceForDetail by remember { mutableStateOf<ServiceItem?>(null) }
    var showAuthDialog by remember { mutableStateOf(false) }
    var showWorkProofReviewModal by remember { mutableStateOf(false) }
    var showServiceDoneToast by remember { mutableStateOf(false) }
    var showCaseStudyDialog by remember { mutableStateOf(false) }
    var lastNotifiedOrderId by remember { mutableStateOf<String?>(null) }
    var technicianPromptSentOrderIds by remember { mutableStateOf(setOf<String>()) }
    var promptTechnicianMessage by remember { mutableStateOf<String?>(null) }

    // When active order becomes IN_SERVICE or DELIVERED, show toast prompt if not dismissed
    LaunchedEffect(activeOrder?.status, activeOrder?.id, activeOrder?.workProof?.status) {
        val current = activeOrder
        if (current != null && (current.status == OrderStatus.IN_SERVICE || current.status == OrderStatus.DELIVERED)) {
            if (lastNotifiedOrderId != current.id + "_" + current.status.name) {
                lastNotifiedOrderId = current.id + "_" + current.status.name
                showServiceDoneToast = true
            }
        }
    }

    val totalCartItems = cart.sumOf { it.quantity }
    val totalCartAmount = cart.sumOf { it.service.price * it.quantity }

    if (showAuthDialog) {
        AuthProfileDialog(
            repository = repository,
            onDismiss = { showAuthDialog = false }
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(BlinkitBackground)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = if (totalCartItems > 0) 100.dp else 24.dp)
        ) {
            // 1. Signature Blinkit Lemon Yellow Top Header
            item {
                BlinkitServicesTopHeader(
                    address = selectedAddress,
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    currentUser = currentUser,
                    onOpenAuth = { showAuthDialog = true },
                    onOpenAiAssistant = onOpenAiAssistant,
                    onSwitchToAdmin = onSwitchToAdmin
                )
            }

            // 1.5 Connected Dark Store Micro-Hub Live Status & SLA Widget
            item {
                BlinkitLiveDarkStoreStatusCard(
                    hubName = "QuickIt Dark Store Hub #14 - Indiranagar",
                    distanceKm = 1.4,
                    techsAvailable = 8,
                    sparesInStock = 2480,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            // 1.6 Blinkit Case Study Architecture & 10-Minute Dispatch Model Banner
            item {
                BlinkitCaseStudyArchitectureBanner(
                    onExploreCaseStudy = { showCaseStudyDialog = true },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // 1.7 Blinkit Pro Pass VIP Membership Card (Retention & Growth Engine)
            item {
                BlinkitClubMembershipCard(
                    onExploreClub = { showCaseStudyDialog = true },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }


            // 2. Active 10-Minute Service Live Banner (If a booking is active)
            activeOrder?.let { order ->
                if (order.status != OrderStatus.DELIVERED) {
                    item {
                        ActiveServicePillBanner(
                            order = order,
                            onClick = onOpenOrderTracker
                        )
                    }
                }

                // 2b. High Priority Work Proof & Technician Upload Reminder Banner
                if (order.status == OrderStatus.IN_SERVICE || order.status == OrderStatus.DELIVERED) {
                    item {
                        ServiceDoneWorkProofReminderBanner(
                            order = order,
                            onReviewProof = {
                                showWorkProofReviewModal = true
                            },
                            onRemindTechnician = {
                                technicianPromptSentOrderIds = technicianPromptSentOrderIds + order.id
                                promptTechnicianMessage = "Prompt alert dispatched to ${order.riderName}'s terminal! Reminding technician to record proof video."
                            }
                        )
                    }
                }
            }

            // 3. Gemini AI Superhub Feature Banner
            item {
                GeminiAiPromoCard(onOpenAiAssistant = onOpenAiAssistant)
            }

            // 4. Live Google Maps Grounded Vicinity Service Providers View
            item {
                NearbyProvidersMapView(
                    repository = repository,
                    onBookService = { service ->
                        selectedServiceForDetail = service
                    }
                )
            }

            // 5. Favorite Providers Quick Access Shelf (Synced via Firestore)
            item {
                FavoriteProvidersQuickAccessSection(
                    repository = repository,
                    onBookService = { service ->
                        selectedServiceForDetail = service
                    }
                )
            }

            // 6. My Bookings Visual Step-Tracker Section (Requested -> Hub Prep -> En Route -> In Service -> Completed)
            item {
                MyBookingsDashboardSection(
                    repository = repository,
                    activeOrder = activeOrder,
                    pastOrders = pastOrders,
                    onOpenOrderTracker = onOpenOrderTracker
                )
            }

            // 6. Superfast 10-Min Pro Dispatch Promo Banner
            item {
                ServiceGuaranteeBanner()
            }

            // 6.5 Blinkit Flash Deals Carousel (50% OFF Dispatched in 10 mins)
            item {
                BlinkitFlashDealsCarousel(
                    onBookService = { service ->
                        selectedServiceForDetail = service
                    },
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // 6.6 Blinkit Smart Service Combos (AOV Bundle Maximizer)
            item {
                BlinkitSmartServiceBundlesSection(
                    onBookService = { service ->
                        selectedServiceForDetail = service
                    },
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }

            // 7. Core Categorized Service Selection Component (Plumbing, Electrical, Cleaning, Appliance Care with visual icons)
            item {
                ServiceSelectionComponent(
                    repository = repository,
                    onServiceSelected = { service ->
                        selectedServiceForDetail = service
                    }
                )
            }
        }

        // Floating Sticky Booking Bar (Blinkit Signature Green Bar)
        AnimatedVisibility(
            visible = totalCartItems > 0,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenCart() },
                colors = CardDefaults.cardColors(containerColor = BlinkitGreen),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Handyman,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                "$totalCartItems SERVICES • ₹${String.format("%.0f", totalCartAmount)}",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "⚡ Pro Technician arrives in 10-15 mins",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            "Book Now",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Floating Service Done / Video Proof Notification Toast
        activeOrder?.let { order ->
            if ((order.status == OrderStatus.IN_SERVICE || order.status == OrderStatus.DELIVERED) && showServiceDoneToast) {
                AnimatedVisibility(
                    visible = showServiceDoneToast,
                    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 80.dp)
                ) {
                    ServiceDonePromptToastBar(
                        technicianName = order.riderName,
                        onReviewClick = {
                            showServiceDoneToast = false
                            showWorkProofReviewModal = true
                        },
                        onDismiss = {
                            showServiceDoneToast = false
                        }
                    )
                }
            }
        }

        // Floating Snackbar for "Prompt Tech Dispatched" feedback
        promptTechnicianMessage?.let { msg ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = if (totalCartItems > 0) 80.dp else 16.dp, start = 16.dp, end = 16.dp),
                containerColor = BlinkitDark,
                contentColor = Color.White,
                action = {
                    TextButton(onClick = { promptTechnicianMessage = null }) {
                        Text("OK", color = BlinkitYellow, fontWeight = FontWeight.Bold)
                    }
                }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BlinkitYellow, modifier = Modifier.size(18.dp))
                    Text(msg, fontSize = 12.sp)
                }
            }
        }
    }

    // Client Work Proof Review Modal Dialog
    if (showWorkProofReviewModal) {
        activeOrder?.let { order ->
            ClientWorkProofReviewDialog(
                order = order,
                onDismiss = { showWorkProofReviewModal = false },
                onApproveProof = { rating, paymentMethod ->
                    repository.approveWorkProofByClient(order.id, rating, paymentMethod)
                    showWorkProofReviewModal = false
                },
                onRequestRevision = { note ->
                    repository.requestWorkProofRevision(order.id, note)
                    showWorkProofReviewModal = false
                },
                onDownloadVideo = {
                    repository.downloadProofVideoLocally(order.id)
                },
                onUploadLocalDeviceVideo = { localPath, reason, category ->
                    repository.uploadCustomerLocalProofVideo(order.id, localPath, reason, category)
                },
                onEscalateToAdmin = { reason, category, localPath ->
                    repository.escalateToAdminReview(order.id, reason, category, localPath)
                }
            )
        }
    }

    // Service Detail Modal Dialog
    selectedServiceForDetail?.let { srv ->
        val qty = repository.getServiceQuantity(srv.id)
        Dialog(onDismissRequest = { selectedServiceForDetail = null }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(BlinkitGreenLight, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("⚡ ARRIVES IN ${srv.etaMinutes.uppercase()}", color = BlinkitGreenDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { selectedServiceForDetail = null }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = BlinkitTextSecondary)
                        }
                    }

                    // Service Hero Icon Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(BlinkitYellowLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(srv.emoji, fontSize = 38.sp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(srv.name, color = BlinkitTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("⏱️ Service Duration: ${srv.duration}", color = BlinkitTextSecondary, fontSize = 12.sp)
                            Text("🛡️ ${srv.warranty}", color = BlinkitGreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Price & Booking Action Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("₹${String.format("%.0f", srv.price)}", color = BlinkitTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            if (srv.discountPercent > 0) {
                                Text(
                                    "₹${String.format("%.0f", srv.originalPrice)}",
                                    color = BlinkitTextMuted,
                                    fontSize = 14.sp,
                                    textDecoration = TextDecoration.LineThrough
                                )
                                Box(
                                    modifier = Modifier
                                        .background(BlinkitRedLight, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("${srv.discountPercent}% OFF", color = BlinkitRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Add / Stepper
                        if (qty == 0) {
                            Button(
                                onClick = { repository.addToCart(srv) },
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
                            ) {
                                Text("BOOK", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .background(BlinkitGreen, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    "−",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { repository.removeFromCart(srv.id) }
                                )
                                Text("$qty", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    "+",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { repository.addToCart(srv) }
                                )
                            }
                        }
                    }

                    // Included Tasks Checklist
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("What's Included:", color = BlinkitTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            srv.includedTasks.forEach { task ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                                    Text(task, color = BlinkitTextSecondary, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    // Tools & Hub Info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Toolkit Dispatched:", color = BlinkitTextSecondary, fontSize = 11.sp)
                        Text(srv.toolkitRequired, color = BlinkitTextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Text(
                        srv.description,
                        color = BlinkitTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }

    // Blinkit Case Study Deep-Dive Interactive Dialog
    if (showCaseStudyDialog) {
        BlinkitCaseStudyDeepDiveDialog(
            onDismiss = { showCaseStudyDialog = false }
        )
    }
}

@Composable
fun BlinkitServicesTopHeader(
    address: DeliveryAddress,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    currentUser: UserProfile? = null,
    onOpenAuth: () -> Unit = {},
    onOpenAiAssistant: () -> Unit = {},
    onSwitchToAdmin: () -> Unit = {}
) {
    val searchHints = remember {
        listOf(
            "Search 'AC jet clean in 10 mins'...",
            "Search 'Plumber for tap leak'...",
            "Search 'Electrician for sparking switch'...",
            "Search 'CPVC pipe joint repair'...",
            "Search 'Deep bathroom clean'..."
        )
    }
    var currentHintIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            currentHintIndex = (currentHintIndex + 1) % searchHints.size
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(BlinkitYellow, BlinkitYellowDark)
                )
            )
            .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Location & ETA Pill & Profile & Admin Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Instant Pro in 10-15 mins",
                        color = BlinkitDark,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-0.5).sp
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(BlinkitGreen)
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        "${address.label} - ${address.addressLine}",
                        color = BlinkitDark.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Icon(
                        Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = BlinkitDark,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Firebase User Profile Button
                Surface(
                    color = BlinkitDark,
                    shape = CircleShape,
                    modifier = Modifier.clickable { onOpenAuth() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (currentUser != null) {
                            Text(
                                currentUser.displayName.take(1).uppercase(),
                                color = BlinkitYellow,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        } else {
                            Icon(
                                Icons.Default.AccountCircle,
                                contentDescription = "Sign In",
                                tint = BlinkitYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Admin Login Badge
                Surface(
                    color = Color(0xFF0F172A),
                    shape = RoundedCornerShape(100.dp),
                    modifier = Modifier.clickable { onSwitchToAdmin() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Login",
                            tint = BlinkitYellow,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            "Admin",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Search Bar with Clean Pill Input for Services & Mic AI trigger
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = {
                Text(
                    searchHints[currentHintIndex],
                    color = BlinkitTextSecondary,
                    fontSize = 12.sp
                )
            },
            leadingIcon = {
                Icon(
                    Icons.Default.Search,
                    contentDescription = null,
                    tint = BlinkitDark
                )
            },
            trailingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Clear, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(18.dp))
                        }
                    }
                    // Mic button that triggers AI Assistant Voice Transcribe
                    IconButton(
                        onClick = { onOpenAiAssistant() },
                        modifier = Modifier
                            .size(32.dp)
                            .background(BlinkitGreenLight, CircleShape)
                    ) {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = "AI Voice STT",
                            tint = BlinkitGreenDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = BlinkitSurface,
                unfocusedContainerColor = BlinkitSurface,
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = BlinkitTextPrimary,
                unfocusedTextColor = BlinkitTextPrimary
            ),
            singleLine = true
        )
    }
}

@Composable
fun GeminiAiPromoCard(onOpenAiAssistant: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onOpenAiAssistant() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitDark),
        border = BorderStroke(1.dp, BlinkitYellow.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    color = BlinkitYellow,
                    shape = CircleShape,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Gemini AI",
                            tint = BlinkitDark,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "QuickIt Gemini AI Assistant",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Surface(
                            color = BlinkitGreen,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                "3.5 FLASH",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        "Voice Transcribe • Live Maps & Search Grounding • Rate AI",
                        fontSize = 10.sp,
                        color = Color(0xFFCBD5E1)
                    )
                }
            }

            Surface(
                color = BlinkitGreenLight,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "Try AI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BlinkitGreenDark,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ActiveServicePillBanner(
    order: OrderItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = BlinkitDarkCard),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(BlinkitYellow),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Handyman,
                        contentDescription = null,
                        tint = BlinkitDark,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "LIVE PRO ON THE WAY",
                            color = BlinkitYellow,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(BlinkitGreen)
                        )
                    }
                    Text(
                        "${order.riderName} • ${order.status.displayName}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .background(BlinkitGreen, RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    "Track 🛵",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ServiceGuaranteeBanner() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BlinkitYellow.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    "⚡ 10-MINUTE RAPID PRO DISPATCH",
                    color = BlinkitGreenDark,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    "Certified Plumber & Cleaner Hub #14",
                    color = BlinkitTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Background verified pros • 30-day service warranty • Transparent rate card",
                    color = BlinkitTextSecondary,
                    fontSize = 11.sp
                )
            }
            Text("👨🏽‍🔧⚡", fontSize = 32.sp)
        }
    }
}

@Composable
fun CategoryPillItem(
    category: CategoryItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (isSelected) BlinkitYellow else category.bannerColor)
                .border(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) BlinkitDark else BlinkitBorder,
                    shape = RoundedCornerShape(18.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(category.iconEmoji, fontSize = 26.sp)
        }
        Text(
            category.name,
            color = if (isSelected) BlinkitDark else BlinkitTextPrimary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BlinkitServiceCard(
    service: ServiceItem,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                // Service Icon Thumbnail
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(BlinkitSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(service.emoji, fontSize = 34.sp)
                }

                // Service Details
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(BlinkitGreenLight, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "⚡ ${service.etaMinutes}",
                                color = BlinkitGreenDark,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            "★ ${service.rating} (${service.ratingCount})",
                            color = BlinkitOrange,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        service.name,
                        color = BlinkitTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "⏱️ ${service.duration}",
                            color = BlinkitTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text("•", color = BlinkitTextMuted, fontSize = 10.sp)
                        Text(
                            "🛡️ ${service.warranty}",
                            color = BlinkitGreenDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Included Preview Snippet
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlinkitSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                Text(
                    service.includedTasks.firstOrNull() ?: "Includes pro tools & safety checks",
                    color = BlinkitTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Price & Book Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "₹${String.format("%.0f", service.price)}",
                        color = BlinkitTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    if (service.discountPercent > 0) {
                        Text(
                            "₹${String.format("%.0f", service.originalPrice)}",
                            color = BlinkitTextMuted,
                            fontSize = 11.sp,
                            textDecoration = TextDecoration.LineThrough
                        )
                        Box(
                            modifier = Modifier
                                .background(BlinkitRedLight, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                "${service.discountPercent}% OFF",
                                color = BlinkitRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Add / Stepper Button (Signature Blinkit Style)
                if (quantity == 0) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BlinkitGreenLight)
                            .border(1.dp, BlinkitGreen, RoundedCornerShape(8.dp))
                            .clickable { onAdd() }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "BOOK",
                            color = BlinkitGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BlinkitGreen)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "−",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onRemove() }
                        )
                        Text(
                            "$quantity",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "+",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onAdd() }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Visual Step-Tracker Section in the User Dashboard.
 * Displays bookings with real-time status transitions (Requested -> Hub Prep -> En Route -> In Service -> Completed).
 */
@Composable
fun MyBookingsDashboardSection(
    repository: BlinkitRepository,
    activeOrder: OrderItem?,
    pastOrders: List<OrderItem>,
    onOpenOrderTracker: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ACTIVE") } // "ACTIVE", "ALL", "PAST"

    val combinedOrders = remember(activeOrder, pastOrders) {
        val list = mutableListOf<OrderItem>()
        activeOrder?.let { list.add(it) }
        list.addAll(pastOrders.filter { it.id != activeOrder?.id })
        list
    }

    val displayOrders = remember(selectedFilter, combinedOrders, activeOrder, pastOrders) {
        when (selectedFilter) {
            "ACTIVE" -> combinedOrders.filter { it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED }
            "PAST" -> combinedOrders.filter { it.status == OrderStatus.DELIVERED || it.status == OrderStatus.CANCELLED }
            else -> combinedOrders
        }
    }

    val activeCount = combinedOrders.count { it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = BlinkitYellowLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "📋",
                        fontSize = 16.sp,
                        modifier = Modifier.padding(6.dp)
                    )
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "My Bookings & Step Tracker",
                            color = BlinkitTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        if (activeCount > 0) {
                            Surface(
                                color = BlinkitGreenLight,
                                shape = RoundedCornerShape(100.dp)
                            ) {
                                Text(
                                    "$activeCount Active",
                                    color = BlinkitGreenDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        "Real-time 10-minute dispatch & progress tracker",
                        color = BlinkitTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Filter Pills Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == "ACTIVE",
                onClick = { selectedFilter = "ACTIVE" },
                label = { Text("Active (${activeCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BlinkitYellowLight,
                    selectedLabelColor = BlinkitDark,
                    containerColor = BlinkitSurface,
                    labelColor = BlinkitTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilter == "ACTIVE",
                    borderColor = if (selectedFilter == "ACTIVE") BlinkitYellowDark else BlinkitBorder
                ),
                shape = RoundedCornerShape(100.dp)
            )

            FilterChip(
                selected = selectedFilter == "ALL",
                onClick = { selectedFilter = "ALL" },
                label = { Text("All (${combinedOrders.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BlinkitDark,
                    selectedLabelColor = BlinkitYellow,
                    containerColor = BlinkitSurface,
                    labelColor = BlinkitTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilter == "ALL",
                    borderColor = if (selectedFilter == "ALL") BlinkitDark else BlinkitBorder
                ),
                shape = RoundedCornerShape(100.dp)
            )

            FilterChip(
                selected = selectedFilter == "PAST",
                onClick = { selectedFilter = "PAST" },
                label = { Text("Completed (${combinedOrders.size - activeCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BlinkitGreenLight,
                    selectedLabelColor = BlinkitGreenDark,
                    containerColor = BlinkitSurface,
                    labelColor = BlinkitTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedFilter == "PAST",
                    borderColor = if (selectedFilter == "PAST") BlinkitGreen else BlinkitBorder
                ),
                shape = RoundedCornerShape(100.dp)
            )
        }

        if (displayOrders.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = BlinkitSurface,
                border = BorderStroke(1.dp, BlinkitBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("📦", fontSize = 28.sp)
                    Text(
                        "No bookings in this filter",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitTextPrimary
                    )
                    Text(
                        "Select another tab or book a 10-minute pro service above.",
                        fontSize = 11.sp,
                        color = BlinkitTextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Render each booking with the Visual Step-Tracker component
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                displayOrders.forEach { order ->
                    BookingVisualStepTracker(
                        order = order,
                        onAdvanceStatus = { nextStatus ->
                            repository.updateOrderStatus(order.id, nextStatus)
                        },
                        onOpenTracker = onOpenOrderTracker,
                        isExpandedDefault = order.status != OrderStatus.DELIVERED
                    )
                }
            }
        }
    }
}

@Composable
fun FavoriteProvidersQuickAccessSection(
    repository: BlinkitRepository,
    onBookService: (ServiceItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val favoriteProviderIds by repository.favoriteProviderIds.collectAsState()
    val nearbyProviders by repository.nearbyProviders.collectAsState()
    val services by repository.services.collectAsState()

    val favoriteProviders = remember(favoriteProviderIds, nearbyProviders) {
        nearbyProviders.filter { favoriteProviderIds.contains(it.id) }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "⭐ Favorite Providers",
                        color = BlinkitTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Surface(
                        color = BlinkitYellowLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            "${favoriteProviders.size} STARRED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitDark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    "Starred certified pros • Synced with your account across devices",
                    color = BlinkitTextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        if (favoriteProviders.isEmpty()) {
            // Empty State
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                border = BorderStroke(1.dp, BlinkitBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BlinkitYellowLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("⭐", fontSize = 22.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "No favorite providers starred yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BlinkitTextPrimary
                        )
                        Text(
                            "Star any certified technician in the live map to pin them here for rapid 1-tap bookings.",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }
            }
        } else {
            // Horizontal Carousel of Favorite Providers
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(favoriteProviders, key = { it.id }) { prov ->
                    Card(
                        modifier = Modifier
                            .width(260.dp)
                            .animateItem(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        border = BorderStroke(1.5.dp, BlinkitYellow.copy(alpha = 0.7f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Top Row: Avatar + Name + Star toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(BlinkitYellowLight)
                                            .border(1.5.dp, BlinkitYellowDark, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(prov.avatarEmoji, fontSize = 22.sp)
                                    }
                                    Column {
                                        Text(
                                            prov.name,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp,
                                            color = BlinkitTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            prov.speciality,
                                            fontSize = 11.sp,
                                            color = BlinkitTextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                // 1-tap Unstar button
                                IconButton(
                                    onClick = { repository.toggleFavoriteProvider(prov.id) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(BlinkitYellowLight, CircleShape)
                                ) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = "Starred Provider",
                                        tint = BlinkitYellowDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            // Rating & ETA
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = BlinkitGreenLight,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Timer,
                                            contentDescription = null,
                                            tint = BlinkitGreenDark,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            "${prov.etaMinutes}m ETA",
                                            color = BlinkitGreenDark,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text("★", color = Color(0xFFF59E0B), fontSize = 12.sp)
                                    Text(
                                        "${prov.rating}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = BlinkitTextPrimary
                                    )
                                    Text(
                                        "(${prov.ratingCount})",
                                        fontSize = 10.sp,
                                        color = BlinkitTextSecondary
                                    )
                                }
                            }

                            // Location & Hub
                            Text(
                                "📍 ${prov.currentVicinityLandmark}",
                                fontSize = 10.sp,
                                color = BlinkitTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            // 1-Tap Instant Dispatch Action
                            val matchingService = services.find { it.categoryId == prov.categoryId }
                            Button(
                                onClick = {
                                    matchingService?.let { onBookService(it) }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BlinkitGreenDark
                                ),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.ElectricBolt,
                                        contentDescription = null,
                                        tint = BlinkitYellow,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        "Quick Dispatch Pro",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
