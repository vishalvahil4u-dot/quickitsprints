package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class AiHubTab(val label: String, val icon: @Composable () -> Unit) {
    CHAT("AI Chatbot", { Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp)) }),
    VOICE("Voice Transcribe", { Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp)) }),
    MAPS("Maps Grounding", { Icon(Icons.Default.PinDrop, contentDescription = null, modifier = Modifier.size(16.dp)) }),
    SEARCH("Search Grounding", { Icon(Icons.Default.TravelExplore, contentDescription = null, modifier = Modifier.size(16.dp)) })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiAiAssistantScreen(
    repository: BlinkitRepository,
    onAddToCart: (ServiceItem) -> Unit = {},
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(AiHubTab.CHAT) }
    var selectedModel by remember { mutableStateOf(GeminiModel.FLASH) }
    var selectedRole by remember {
        mutableStateOf(
            "QuickIt 10-Minute Home Services Certified Repair Specialist. Give fast, clear, step-by-step diagnostic advice with price estimates in ₹."
        )
    }

    val conversationHistory by repository.aiConversation.collectAsState()
    val isAiThinking by repository.isAiThinking.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var isRecording by remember { mutableStateOf(false) }
    var transcribedTextResult by remember { mutableStateOf<String?>(null) }
    var isTranscribing by remember { mutableStateOf(false) }

    // Maps & Search State
    var mapsLocationInput by remember { mutableStateOf("Indiranagar, Bangalore") }
    var mapsResult by remember { mutableStateOf<ChatMessage?>(null) }
    var isMapsLoading by remember { mutableStateOf(false) }

    var searchTopicInput by remember { mutableStateOf("AC gas leakage vs capacitor failure repair cost 2026") }
    var searchResult by remember { mutableStateOf<ChatMessage?>(null) }
    var isSearchLoading by remember { mutableStateOf(false) }

    val audioHelper = remember { AudioRecordHelper(context) }
    val listState = rememberLazyListState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val started = audioHelper.startRecording()
            if (started) isRecording = true
        }
    }

    LaunchedEffect(conversationHistory.size) {
        if (conversationHistory.isNotEmpty()) {
            listState.animateScrollToItem(conversationHistory.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BlinkitBackground)
    ) {
        // Top Header
        Surface(
            color = BlinkitSurface,
            tonalElevation = 4.dp,
            modifier = Modifier.border(1.dp, BlinkitBorder, RoundedCornerShape(0.dp))
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = BlinkitGreenLight,
                            shape = CircleShape,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = "Gemini AI",
                                    tint = BlinkitGreenDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    "QuickIt Gemini AI",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitTextPrimary
                                )
                                Surface(
                                    color = BlinkitYellow,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "10-MIN PRO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = BlinkitDark,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                "Multi-Turn Chat • Audio STT • Maps & Search Grounding",
                                fontSize = 11.sp,
                                color = BlinkitTextSecondary
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { repository.clearAiChat() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Clear Chat",
                                tint = BlinkitTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // AI Sub-Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = BlinkitSurface,
                    contentColor = BlinkitGreenDark,
                    edgePadding = 12.dp,
                    divider = {}
                ) {
                    AiHubTab.values().forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    tab.icon()
                                    Text(
                                        tab.label,
                                        fontSize = 12.sp,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            when (selectedTab) {
                AiHubTab.CHAT -> {
                    ChatbotView(
                        repository = repository,
                        conversation = conversationHistory,
                        isThinking = isAiThinking,
                        selectedModel = selectedModel,
                        onModelChange = { selectedModel = it },
                        selectedRole = selectedRole,
                        onRoleChange = { selectedRole = it },
                        textInput = textInput,
                        onTextInputChange = { textInput = it },
                        onSendMessage = { prompt ->
                            if (prompt.isNotBlank()) {
                                textInput = ""
                                coroutineScope.launch {
                                    repository.sendAiChatMessage(
                                        userMessage = prompt,
                                        model = selectedModel,
                                        systemInstruction = selectedRole
                                    )
                                }
                            }
                        },
                        onAddToCart = onAddToCart,
                        onTriggerVoiceRecord = {
                            selectedTab = AiHubTab.VOICE
                        }
                    )
                }

                AiHubTab.VOICE -> {
                    VoiceTranscribeView(
                        isRecording = isRecording,
                        isTranscribing = isTranscribing,
                        transcribedText = transcribedTextResult,
                        onStartRecording = {
                            val perm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            )
                            if (perm == PackageManager.PERMISSION_GRANTED) {
                                val ok = audioHelper.startRecording()
                                if (ok) isRecording = true
                            } else {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onStopRecording = {
                            isRecording = false
                            isTranscribing = true
                            val wavBytes = audioHelper.stopRecording()
                            coroutineScope.launch {
                                val result = repository.transcribeVoiceAudio(wavBytes)
                                transcribedTextResult = result
                                isTranscribing = false
                            }
                        },
                        onSendToChat = { text ->
                            selectedTab = AiHubTab.CHAT
                            textInput = text
                            coroutineScope.launch {
                                repository.sendAiChatMessage(
                                    userMessage = text,
                                    model = GeminiModel.FLASH,
                                    systemInstruction = selectedRole
                                )
                            }
                        }
                    )
                }

                AiHubTab.MAPS -> {
                    MapsGroundingView(
                        locationQuery = mapsLocationInput,
                        onLocationChange = { mapsLocationInput = it },
                        isLoading = isMapsLoading,
                        resultMessage = mapsResult,
                        onSearchMaps = { query ->
                            isMapsLoading = true
                            coroutineScope.launch {
                                val res = repository.queryMapsGrounding(query)
                                mapsResult = res
                                isMapsLoading = false
                            }
                        }
                    )
                }

                AiHubTab.SEARCH -> {
                    SearchGroundingView(
                        searchQuery = searchTopicInput,
                        onSearchQueryChange = { searchTopicInput = it },
                        isLoading = isSearchLoading,
                        resultMessage = searchResult,
                        onSearch = { query ->
                            isSearchLoading = true
                            coroutineScope.launch {
                                val res = repository.querySearchGrounding(query)
                                searchResult = res
                                isSearchLoading = false
                            }
                        }
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: MULTI-TURN CHATBOT
// -------------------------------------------------------------
@Composable
fun ChatbotView(
    repository: BlinkitRepository,
    conversation: List<ChatMessage>,
    isThinking: Boolean,
    selectedModel: GeminiModel,
    onModelChange: (GeminiModel) -> Unit,
    selectedRole: String,
    onRoleChange: (String) -> Unit,
    textInput: String,
    onTextInputChange: (String) -> Unit,
    onSendMessage: (String) -> Unit,
    onAddToCart: (ServiceItem) -> Unit,
    onTriggerVoiceRecord: () -> Unit
) {
    val listState = rememberLazyListState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Controls Row: Model Selector & Role Dropdown
        Surface(
            color = BlinkitSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, BlinkitBorder)
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Model Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Select Model:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        GeminiModel.values().forEach { model ->
                            Surface(
                                color = if (selectedModel == model) BlinkitGreen else BlinkitBackground,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (selectedModel == model) BlinkitGreen else BlinkitBorder),
                                modifier = Modifier.clickable { onModelChange(model) }
                            ) {
                                Text(
                                    text = model.tag,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedModel == model) Color.White else BlinkitTextPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // System Instruction Role Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val roles = listOf(
                        "Certified Repair Diagnostician" to "You are QuickIt's 10-Minute Home Services Certified Repair Specialist. Give fast, clear, step-by-step diagnostic advice with price estimates in ₹.",
                        "Rate Card & Warranty Concierge" to "You are QuickIt's Rate Card, Warranty, and SLA Concierge. Explain transparent rates, 30-day rework guarantees, and 10-minute dispatch promises.",
                        "Emergency Safety Guard" to "You are QuickIt's Emergency Home Safety Dispatcher. Provide urgent safety shut-off instructions for gas leaks, pipe bursts, and electrical tripping."
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(roles) { (label, instruction) ->
                            val isSelected = selectedRole == instruction
                            Surface(
                                color = if (isSelected) BlinkitYellowLight else BlinkitBackground,
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, if (isSelected) BlinkitYellow else BlinkitBorder),
                                modifier = Modifier.clickable { onRoleChange(instruction) }
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) BlinkitDark else BlinkitTextSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Suggestion Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val chips = listOf(
                "🚰 Kitchen tap leaking under sink",
                "❄️ AC not cooling & water dripping",
                "⚡ MCB tripping continuously",
                "🚿 Bathroom drain blocked",
                "🪚 Need TV wall mount drilling"
            )
            items(chips) { chip ->
                Surface(
                    color = BlinkitSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BlinkitBorder),
                    modifier = Modifier.clickable { onSendMessage(chip) }
                ) {
                    Text(
                        text = chip,
                        fontSize = 11.sp,
                        color = BlinkitTextPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Scrollable Chat Thread
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (conversation.isEmpty()) {
                item {
                    EmptyChatGreeting(onSelectPrompt = onSendMessage)
                }
            } else {
                items(conversation) { msg ->
                    ChatBubbleItem(message = msg, onAddToCart = onAddToCart, repository = repository)
                }
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = BlinkitGreen,
                            strokeWidth = 2.dp
                        )
                        Text(
                            "Gemini is analyzing repair diagnosis & rate card...",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Chat Input Bar with Mic button
        Surface(
            color = BlinkitSurface,
            tonalElevation = 8.dp,
            modifier = Modifier.border(1.dp, BlinkitBorder, RoundedCornerShape(0.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Voice Mic Quick Launcher
                IconButton(
                    onClick = onTriggerVoiceRecord,
                    modifier = Modifier
                        .size(40.dp)
                        .background(BlinkitYellowLight, CircleShape)
                        .border(1.dp, BlinkitYellow, CircleShape)
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = BlinkitDark,
                        modifier = Modifier.size(20.dp)
                    )
                }

                OutlinedTextField(
                    value = textInput,
                    onValueChange = onTextInputChange,
                    placeholder = { Text("Ask about any home repair issue...", fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = BlinkitBackground,
                        unfocusedContainerColor = BlinkitBackground,
                        focusedIndicatorColor = BlinkitGreen,
                        unfocusedIndicatorColor = BlinkitBorder
                    ),
                    maxLines = 3
                )

                IconButton(
                    onClick = { onSendMessage(textInput) },
                    enabled = textInput.isNotBlank() && !isThinking,
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (textInput.isNotBlank()) BlinkitGreen else BlinkitBorder,
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyChatGreeting(onSelectPrompt: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = BlinkitGreenLight,
                shape = CircleShape,
                modifier = Modifier.size(54.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("🤖", fontSize = 26.sp)
                }
            }

            Text(
                "QuickIt 10-Minute AI Repair Diagnostician",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitTextPrimary
            )

            Text(
                "Describe any water leak, AC breakdown, electrical tripping, or plumbing emergency. I will diagnose the fault, suggest required toolkits, and link instant 10-minute dispatch bookings!",
                fontSize = 12.sp,
                color = BlinkitTextSecondary,
                lineHeight = 16.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    color = BlinkitBackground,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BlinkitBorder),
                    modifier = Modifier.clickable { onSelectPrompt("AC making loud noise and not cooling") }
                ) {
                    Text("❄️ AC Noise & Cooling Fix", fontSize = 11.sp, color = BlinkitGreenDark, modifier = Modifier.padding(8.dp))
                }
                Surface(
                    color = BlinkitBackground,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BlinkitBorder),
                    modifier = Modifier.clickable { onSelectPrompt("Main water pipe leaking in bathroom") }
                ) {
                    Text("🚰 Water Pipe Leakage", fontSize = 11.sp, color = BlinkitGreenDark, modifier = Modifier.padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun ChatBubbleItem(
    message: ChatMessage,
    onAddToCart: (ServiceItem) -> Unit,
    repository: BlinkitRepository
) {
    val isUser = message.sender == MessageSender.USER
    val services by repository.services.collectAsState()

    // Match potential service recommendation in AI response
    val suggestedService = if (!isUser) {
        services.firstOrNull { service ->
            message.text.contains(service.name, ignoreCase = true) ||
            (service.categoryId == "cat_plumbing" && message.text.contains("Tap", ignoreCase = true)) ||
            (service.categoryId == "cat_appliance" && message.text.contains("AC", ignoreCase = true))
        }
    } else null

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Surface(
                color = BlinkitGreenLight,
                shape = CircleShape,
                modifier = Modifier
                    .size(28.dp)
                    .align(Alignment.Top)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("⚡", fontSize = 14.sp)
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 300.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Surface(
                color = if (isUser) BlinkitGreenDark else BlinkitSurface,
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                border = if (isUser) null else BorderStroke(1.dp, BlinkitBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (message.modelUsed != null && !isUser) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = message.modelUsed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitGreenDark
                            )
                            if (message.groundingType != GroundingType.NONE) {
                                Text(
                                    text = "• Grounded with ${message.groundingType.name}",
                                    fontSize = 9.sp,
                                    color = BlinkitTextSecondary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Text(
                        text = message.text,
                        fontSize = 13.sp,
                        color = if (isUser) Color.White else BlinkitTextPrimary,
                        lineHeight = 18.sp
                    )

                    // Grounding Sources if available
                    if (message.groundingSources.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = BlinkitBorder, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Sources & Landmarks:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                        message.groundingSources.take(2).forEach { source ->
                            Text(
                                text = "• ${source.title}",
                                fontSize = 10.sp,
                                color = BlinkitGreenDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Quick Service Add Card if recommended
            suggestedService?.let { srv ->
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight),
                    border = BorderStroke(1.dp, BlinkitYellow)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(srv.emoji, fontSize = 20.sp)
                            Column {
                                Text(srv.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitDark, maxLines = 1)
                                Text("₹${srv.price.toInt()} • 10-min dispatch", fontSize = 10.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                            }
                        }
                        Button(
                            onClick = { onAddToCart(srv) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Book 10m", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 2: AUDIO TRANSCRIPTION VIEW (using gemini-3.5-flash)
// -------------------------------------------------------------
@Composable
fun VoiceTranscribeView(
    isRecording: Boolean,
    isTranscribing: Boolean,
    transcribedText: String?,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onSendToChat: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            border = BorderStroke(1.dp, BlinkitBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = BlinkitYellowLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "MODEL: gemini-3.5-flash",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(
                    "Speak Your Home Problem",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BlinkitTextPrimary
                )

                Text(
                    "Tap the microphone and describe your repair problem in English, Hindi, or Hinglish. Gemini 3.5 Flash will transcribe the audio and diagnose the repair in 10 minutes.",
                    fontSize = 12.sp,
                    color = BlinkitTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Animated Microphone Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(120.dp)
        ) {
            if (isRecording) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(BlinkitRed.copy(alpha = 0.2f))
                )
            }

            Surface(
                color = if (isRecording) BlinkitRed else BlinkitGreen,
                shape = CircleShape,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .size(80.dp)
                    .clickable {
                        if (isRecording) onStopRecording() else onStartRecording()
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Mic",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        Text(
            text = if (isRecording) "🔴 Recording... Tap Stop when done" else "Tap Mic to Start Speaking",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isRecording) BlinkitRed else BlinkitTextPrimary
        )

        if (isTranscribing) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = BlinkitGreen)
                Text("Gemini 3.5 Flash is transcribing your speech...", fontSize = 12.sp, color = BlinkitTextSecondary)
            }
        }

        // Transcribed Result Card
        transcribedText?.let { text ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                border = BorderStroke(1.5.dp, BlinkitGreen)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Transcribed Speech (gemini-3.5-flash):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                        Surface(color = BlinkitGreenLight, shape = RoundedCornerShape(4.dp)) {
                            Text("100% Accurate", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark, modifier = Modifier.padding(3.dp))
                        }
                    }

                    Text(
                        text = "\"$text\"",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = BlinkitTextPrimary,
                        lineHeight = 20.sp
                    )

                    Button(
                        onClick = { onSendToChat(text) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Diagnose & Book with AI", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: MAPS GROUNDING VIEW (using gemini-3.5-flash with googleMaps tool)
// -------------------------------------------------------------
@Composable
fun MapsGroundingView(
    locationQuery: String,
    onLocationChange: (String) -> Unit,
    isLoading: Boolean,
    resultMessage: ChatMessage?,
    onSearchMaps: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            border = BorderStroke(1.dp, BlinkitBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(color = BlinkitYellow, shape = RoundedCornerShape(4.dp)) {
                        Text("googleMaps TOOL", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = BlinkitDark, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                    Text("Geospatial Fleet & Hub Grounding", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                }
                Text("Locate real QuickIt dark store hubs, technician stations, and nearby certified spare parts depots.", fontSize = 11.sp, color = BlinkitTextSecondary)
            }
        }

        // Search Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = locationQuery,
                onValueChange = onLocationChange,
                placeholder = { Text("Enter neighborhood / landmark...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            Button(
                onClick = { onSearchMaps(locationQuery) },
                enabled = locationQuery.isNotBlank() && !isLoading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                } else {
                    Text("Search", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Quick City Suggestions
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val suggestions = listOf("Indiranagar Hub #14", "Koramangala 5th Block", "HSR Layout Sector 2", "Whitefield ITPL")
            items(suggestions) { sugg ->
                Surface(
                    color = BlinkitSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BlinkitBorder),
                    modifier = Modifier.clickable {
                        onLocationChange(sugg)
                        onSearchMaps(sugg)
                    }
                ) {
                    Text("📍 $sugg", fontSize = 11.sp, color = BlinkitTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
        }

        // Results Card
        resultMessage?.let { msg ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                border = BorderStroke(1.dp, BlinkitBorder)
            ) {
                LazyColumn(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🗺️ Grounded Maps Result (gemini-3.5-flash)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                        }
                    }

                    item {
                        Text(
                            text = msg.text,
                            fontSize = 13.sp,
                            color = BlinkitTextPrimary,
                            lineHeight = 18.sp
                        )
                    }

                    if (msg.groundingSources.isNotEmpty()) {
                        item {
                            Divider(color = BlinkitBorder)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Grounded Hub Stations & Suppliers:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                        }
                        items(msg.groundingSources) { src ->
                            Surface(
                                color = BlinkitYellowLight.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, BlinkitYellow),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(src.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                    src.snippet?.let { Text(it, fontSize = 10.sp, color = BlinkitTextSecondary) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: SEARCH GROUNDING VIEW (using gemini-3.5-flash with googleSearch tool)
// -------------------------------------------------------------
@Composable
fun SearchGroundingView(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    isLoading: Boolean,
    resultMessage: ChatMessage?,
    onSearch: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            border = BorderStroke(1.dp, BlinkitBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(color = BlinkitYellow, shape = RoundedCornerShape(4.dp)) {
                        Text("googleSearch TOOL", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = BlinkitDark, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                    Text("Live 2026 Repair Bulletins & Warranties", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                }
                Text("Search real-time manufacturer recall bulletins, average spare part rates, and BIS safety compliance standards.", fontSize = 11.sp, color = BlinkitTextSecondary)
            }
        }

        // Search Query Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search warranty, spare rate, advisory...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            Button(
                onClick = { onSearch(searchQuery) },
                enabled = searchQuery.isNotBlank() && !isLoading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                } else {
                    Text("Ground", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Suggestions
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val queries = listOf(
                "Daikin AC PCB replacement cost 2026",
                "Havells geyser heating element warranty rules",
                "BIS standard wire gauge for 16A power socket",
                "Astral CPVC pipe vs UPVC pressure ratings"
            )
            items(queries) { q ->
                Surface(
                    color = BlinkitSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BlinkitBorder),
                    modifier = Modifier.clickable {
                        onSearchQueryChange(q)
                        onSearch(q)
                    }
                ) {
                    Text("🔍 $q", fontSize = 11.sp, color = BlinkitTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
        }

        // Results Card
        resultMessage?.let { msg ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                border = BorderStroke(1.dp, BlinkitBorder)
            ) {
                LazyColumn(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("🌐 Live Web Search Grounded Output (gemini-3.5-flash)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                    }

                    item {
                        Text(
                            text = msg.text,
                            fontSize = 13.sp,
                            color = BlinkitTextPrimary,
                            lineHeight = 18.sp
                        )
                    }

                    if (msg.groundingSources.isNotEmpty()) {
                        item {
                            Divider(color = BlinkitBorder)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Web Grounding References & Citations:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextSecondary)
                        }
                        items(msg.groundingSources) { src ->
                            Surface(
                                color = BlinkitBackground,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, BlinkitBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(src.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                                    src.uri?.let { Text(it, fontSize = 9.sp, color = BlinkitTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
