package com.example.data

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Firebase Cloud Messaging Service for QuickIt.
 * Receives real-time push payloads from the cloud dispatch server
 * when the assigned service technician enters the customer's vicinity (<500m / 2-3 mins ETA).
 */
class QuickItFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "QuickItFCM"
        
        // Active repository reference to deliver in-app notifications in real-time
        var activeRepository: BlinkitRepository? = null
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New Firebase Cloud Messaging Device Token generated: $token")
        
        // Save token to active repository / preferences
        activeRepository?.setFcmToken(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "Received FCM Push Message from: ${remoteMessage.from}")

        val data = remoteMessage.data
        val notification = remoteMessage.notification

        val type = data["type"] ?: "TECHNICIAN_NEARBY"
        val orderId = data["order_id"] ?: activeRepository?.activeOrder?.value?.orderNumber ?: "SRV-10M-8492"
        val techName = data["technician_name"] ?: activeRepository?.activeOrder?.value?.riderName ?: "Ramesh Sharma"
        val techPhone = data["technician_phone"] ?: activeRepository?.activeOrder?.value?.riderPhone ?: "+91 98765 43210"
        val distance = data["distance_meters"]?.toIntOrNull() ?: 420
        val etaMinutes = data["eta_minutes"]?.toIntOrNull() ?: 2
        val otpCode = data["otp_code"] ?: activeRepository?.activeOrder?.value?.otpCode ?: "4829"

        val title = notification?.title ?: data["title"] ?: "⚡ Technician is Nearby!"
        val body = notification?.body ?: data["body"] ?: "$techName is only ${distance}m away (ETA ~${etaMinutes} mins). Please keep OTP $otpCode ready."

        val alertType = when (type) {
            "ARRIVED" -> ProximityAlertType.ARRIVED
            "DISPATCHED" -> ProximityAlertType.DISPATCHED
            "STATUS_UPDATE" -> ProximityAlertType.STATUS_UPDATE
            else -> ProximityAlertType.NEARBY
        }

        val alert = FcmProximityAlert(
            title = title,
            body = body,
            orderId = orderId,
            technicianName = techName,
            technicianPhone = techPhone,
            distanceMeters = distance,
            etaMinutes = etaMinutes,
            otpCode = otpCode,
            alertType = alertType
        )

        // 1. Dispatch rich Android Heads-Up Notification (Sound + Vibrate + Action Buttons)
        QuickItNotificationHelper.showProximityNotification(applicationContext, alert)

        // 2. Deliver in-app HUD banner to UI via repository StateFlow
        CoroutineScope(Dispatchers.Main).launch {
            activeRepository?.postProximityAlert(alert)
        }
    }
}
