package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DarkStorePickerScreen(
    repository: BlinkitRepository
) {
    val activeOrder by repository.activeOrder.collectAsState()
    val checkedItems = remember { mutableStateMapOf<String, Boolean>() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Tools & Parts Dispatch Hub",
                                color = BlinkitTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(BlinkitGreen)
                            )
                        }
                        Text(
                            "Hub #14 • Indiranagar Pro Center (Fulfillment & Tooling)",
                            color = BlinkitTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(BlinkitYellowLight, RoundedCornerShape(8.dp))
                            .border(1.dp, BlinkitYellowDark, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "SLA: 2.0m",
                            color = BlinkitDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BlinkitSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BlinkitBackground),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Service Hub Metrics Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BlinkitDarkCard),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("HUB SPARE PARTS & TOOL INVENTORY", color = BlinkitYellow, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                            Text("ONLINE", color = BlinkitGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HubStatBox(
                                label = "AVG KIT PREP",
                                value = "1m 15s",
                                valueColor = BlinkitYellow,
                                modifier = Modifier.weight(1f)
                            )
                            HubStatBox(
                                label = "PARTS QC CHECK",
                                value = "100%",
                                valueColor = BlinkitGreen,
                                modifier = Modifier.weight(1f)
                            )
                            HubStatBox(
                                label = "AVAILABLE PROS",
                                value = "8 Free",
                                valueColor = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Current Service Request Toolkit Task
            if (activeOrder == null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Handyman, contentDescription = null, tint = BlinkitTextSecondary, modifier = Modifier.size(36.dp))
                            Text("No pending tool dispatch requests", color = BlinkitTextPrimary, fontWeight = FontWeight.Bold)
                            Text("Incoming plumbing, cleaning, or electrical bookings will appear instantly.", color = BlinkitTextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                val order = activeOrder!!

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Kit Prep Task: ${order.orderNumber}",
                            color = BlinkitTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    if (order.status == OrderStatus.PACKING || order.status == OrderStatus.PLACED) BlinkitYellowLight else BlinkitGreenLight,
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                order.status.displayName.uppercase(),
                                color = if (order.status == OrderStatus.PACKING || order.status == OrderStatus.PLACED) BlinkitDark else BlinkitGreenDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Tool & Parts Check List
                items(order.items) { cartItem ->
                    val isChecked = checkedItems[cartItem.service.id] ?: false

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { checkedItems[cartItem.service.id] = !isChecked },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isChecked) BlinkitGreenLight else BlinkitSurface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isChecked) BlinkitGreen else BlinkitBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Emoji / Tool Category
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isChecked) Color.White else BlinkitYellowLight)
                                    .border(1.dp, BlinkitYellowDark, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    cartItem.service.emoji,
                                    fontSize = 18.sp
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    cartItem.service.name,
                                    color = BlinkitTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Toolkit Required: ${cartItem.service.toolkitRequired}",
                                    color = BlinkitGreenDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Estimated job time: ${cartItem.service.duration}",
                                    color = BlinkitTextSecondary,
                                    fontSize = 10.sp
                                )
                            }

                            // Checkbox status
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checkedItems[cartItem.service.id] = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = BlinkitGreen,
                                    uncheckedColor = BlinkitTextSecondary
                                )
                            )
                        }
                    }
                }

                // Action Buttons for Hub Prep
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                repository.updateOrderStatus(order.id, OrderStatus.PACKING)
                            },
                            enabled = order.status == OrderStatus.PLACED,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Verify & Assemble Tool Bag", color = BlinkitDark, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                repository.updateOrderStatus(order.id, OrderStatus.OUT_FOR_DELIVERY)
                            },
                            enabled = order.status == OrderStatus.PACKING || order.status == OrderStatus.PLACED,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color.White)
                                Text("Scan Barcode & Hand Over to Tech Ramesh", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HubStatBox(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.1f))
            .padding(10.dp)
    ) {
        Column {
            Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
        }
    }
}
