package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class CategoryItem(
    val id: String,
    val name: String,
    val iconEmoji: String,
    val bannerColor: Color,
    val badgeText: String = ""
)

data class ServiceItem(
    val id: String,
    val name: String,
    val categoryId: String,
    val subCategory: String,
    val duration: String, // e.g. "30-45 mins"
    val price: Double,
    val originalPrice: Double,
    val discountPercent: Int,
    val emoji: String,
    val etaMinutes: String = "10-15 mins",
    val warranty: String = "30-Day Guarantee",
    val toolkitRequired: String = "Standard Pro Kit", // e.g. "Plumber Pipe Wrench + Seals"
    val rating: Double = 4.8,
    val ratingCount: Int = 1420,
    val description: String = "Expert certified technician with background verification and sanitized toolkits.",
    val includedTasks: List<String> = listOf("On-site diagnosis", "Professional repair", "Post-service cleanup", "30-day warranty card"),
    val isBestseller: Boolean = false,
    val isAvailable: Boolean = true
)

data class CartItem(
    val service: ServiceItem,
    val quantity: Int
)

enum class TechnicianReviewDecision(val label: String) {
    AWAITING_REVIEW("Reviewing 1-Min Video"),
    ACCEPTED("Request Accepted"),
    REJECTED("Request Declined")
}

enum class OrderStatus(val displayName: String, val stepIndex: Int, val description: String) {
    AWAITING_TECHNICIAN_REVIEW("1-Min Video Under Review", 0, "Technician Ramesh reviewing your 1-minute diagnostic video before accepting"),
    PLACED("Booking Accepted", 1, "Technician accepted request; Nearest Hub #14 dispatched"),
    PACKING("Hub Tool & Kit Prep", 2, "Pro Technician Ramesh collecting certified tools & spare parts"),
    OUT_FOR_DELIVERY("Technician En Route", 3, "Technician Ramesh is on the way (EV Scooter • ETA 8 mins)"),
    IN_SERVICE("Service In Progress", 4, "Technician currently performing service at your premises"),
    DELIVERED("Service Completed", 5, "Job finished with 30-day warranty & verified OTP"),
    CANCELLED("Booking Cancelled", -1, "Booking cancelled and refunded to source"),
    REJECTED_BY_TECHNICIAN("Request Declined by Tech", -2, "Technician reviewed 1-min video and declined (100% refund initiated)")
}

data class DeliveryAddress(
    val id: String,
    val label: String, // Home, Office, Villa
    val addressLine: String,
    val landmark: String,
    val receiverName: String,
    val phone: String
)

data class OrderItem(
    val id: String,
    val orderNumber: String,
    val items: List<CartItem>,
    val itemTotal: Double,
    val discountTotal: Double,
    val deliveryFee: Double, // Visit & Diagnostic Fee
    val handlingFee: Double, // Safety & Hygiene Gear
    val tip: Double,
    val grandTotal: Double,
    val status: OrderStatus,
    val address: DeliveryAddress,
    val instructions: List<String>,
    val placedAtTime: String,
    val etaMinutesLeft: Int,
    val riderName: String = "Ramesh Sharma",
    val riderPhone: String = "+91 98765 43210",
    val riderVehicle: String = "KA 01 EK 8821 (EV with Toolbag)",
    val riderRating: Double = 4.95,
    val technicianSpeciality: String = "Master Plumber & Electrician (8+ Yrs Exp)",
    val otpCode: String = "4829",
    val darkStoreHub: String = "QuickIt Service Hub #14 (Indiranagar)",
    val paymentMethod: String = "UPI (Google Pay)",
    val paymentStatus: String = "PAID_ONLINE",
    val transactionId: String = "TXN-98214",
    val workProof: WorkProofRecord? = null,
    val diagnosticVideo: DiagnosticVideoRecord? = null,
    val technicianReviewDecision: TechnicianReviewDecision = TechnicianReviewDecision.AWAITING_REVIEW,
    val technicianRejectionReason: String? = null,
    val technicianReviewNotes: String? = null,
    val technicianReviewedAt: String? = null
)

enum class AppModule(val displayName: String) {
    CUSTOMER("Customer App"),
    ADMIN("Admin Console")
}

enum class CustomerTab(val label: String) {
    SERVICES("Services"),
    TRACKER("Live Tracker"),
    BOOKINGS("My Bookings")
}

enum class AdminTab(val label: String) {
    OVERVIEW("Overview"),
    CATALOG("Catalog & Pricing"),
    DISPATCH("Live Bookings"),
    VERIFICATION("Proofs & Disputes"),
    TECHNICIANS("Fleet & Techs"),
    INVENTORY("Hub Inventory")
}

data class AdminUser(
    val id: String,
    val name: String,
    val email: String,
    val role: String, // e.g. "Operations Director", "Dispatch Supervisor", "Rate Card Manager"
    val hubName: String,
    val permissions: List<String>,
    val avatarEmoji: String = "👨‍💼",
    val sessionToken: String = "ADM-SEC-AES256-" + System.currentTimeMillis(),
    val securityClearanceLevel: String = "LEVEL-3 (FIPS-140 COMPLIANT)",
    val ipAddress: String = "10.14.82.100 (Hub VLAN)",
    val hardwareToken: String = "KNOX-HW-KEY-8821"
)

enum class TechnicianStatus(val label: String, val color: Color) {
    AVAILABLE("Available at Hub", Color(0xFF16A34A)),
    ON_DISPATCH("En Route to Client", Color(0xFF2563EB)),
    IN_SERVICE("In-Service Active", Color(0xFFD97706)),
    OFF_DUTY("Off Duty", Color(0xFF6B7280))
}

data class TechnicianProfile(
    val id: String,
    val name: String,
    val phone: String,
    val vehicleNumber: String,
    val vehicleType: String,
    val speciality: String,
    val rating: Double,
    val completedJobsToday: Int,
    val batteryPercent: Int,
    val status: TechnicianStatus,
    val activeBookingNumber: String? = null,
    val avatarEmoji: String = "👷‍♂️"
)

data class HubToolItem(
    val id: String,
    val name: String,
    val category: String,
    val emoji: String,
    val totalStock: Int,
    val inUseCount: Int,
    val condition: String, // "100% Calibrated", "Sterilized & Checked"
    val isCritical: Boolean = false
)

enum class AppRole(val label: String) {
    CUSTOMER("Book Services"),
    AI_ASSISTANT("Gemini AI Hub"),
    ORDER_TRACKING("Live Tech Tracker"),
    DARK_STORE("Tools & Parts Hub"),
    RIDER("Technician Pro")
}

data class NearbyServiceProvider(
    val id: String,
    val name: String,
    val speciality: String,
    val categoryId: String, // cat_plumbing, cat_electric, cat_cleaning, cat_appliance, cat_carpentry
    val rating: Double,
    val ratingCount: Int,
    val distanceKm: Double,
    val etaMinutes: Int,
    val darkStoreHub: String,
    val latitudeOffset: Float, // Normalized -1.0f to 1.0f on map canvas
    val longitudeOffset: Float, // Normalized -1.0f to 1.0f on map canvas
    val status: TechnicianStatus,
    val avatarEmoji: String,
    val phone: String,
    val vehicleNumber: String,
    val vehicleType: String,
    val completedJobsToday: Int,
    val currentVicinityLandmark: String,
    val isAvailableNow: Boolean = true,
    val primaryToolkits: List<String> = emptyList()
)

data class VicinityGroundingData(
    val locationName: String,
    val summaryText: String,
    val nearestDarkStoreHub: String,
    val averageDispatchEtaMinutes: Int,
    val liveTrafficCondition: String, // "Light Traffic", "Moderate", "Express Corridor"
    val landmarks: List<GroundingSource> = emptyList()
)

data class TechnicianPartnerSession(
    val providerId: String,
    val name: String,
    val phone: String,
    val speciality: String,
    val vehicleNumber: String,
    val vehicleType: String,
    val avatarEmoji: String,
    val hubName: String,
    val rating: Double,
    val isDutyOn: Boolean = true,
    val todayEarnings: Int = 2450,
    val todayJobs: Int = 6,
    val primaryToolkits: List<String> = emptyList(),
    val authToken: String = "TECH-JWT-" + System.currentTimeMillis(),
    val governmentIdMasked: String = "XXXX-XXXX-1092",
    val deviceBoundSimImei: String = "SIM1-8991829048-VERIFIED",
    val playIntegrityAttested: Boolean = true,
    val geofenceVerified: Boolean = true,
    val securityVerificationBadge: String = "POLICE_KYC_VERIFIED"
)

enum class WorkProofStatus {
    NOT_SUBMITTED,
    SUBMITTED,
    APPROVED_BY_CLIENT,
    REVISION_REQUESTED,
    DISPUTED_PAYMENT_ON_HOLD,
    ADMIN_APPROVED,
    ADMIN_REFUNDED
}

data class ReplacedSparePart(
    val id: String = java.util.UUID.randomUUID().toString(),
    val partName: String,
    val partNumber: String = "PRT-" + (1000..9999).random(),
    val warrantyMonths: Int = 6,
    val price: Double = 0.0,
    val emoji: String = "⚙️"
)

data class WorkProofRecord(
    val id: String = "PRF-" + (10000..99999).random(),
    val videoTitle: String = "Appliance Operational & Safety Test",
    val videoDurationSec: Int = 22,
    val videoThumbnailEmoji: String = "📹",
    val recordedGpsCoordinates: String = "12.9716° N, 77.5946° E (±2m Accuracy)",
    val recordedTimestamp: String = "Just now",
    val status: WorkProofStatus = WorkProofStatus.NOT_SUBMITTED,
    val checklistItems: List<String> = listOf(
        "Load test & power draw verified under operating conditions",
        "Zero leakage / vibration inspection passed",
        "Internal coils & components sanitized with high-pressure steam",
        "Thermostat & cooling/heating cycle verified at target temperature"
    ),
    val completedChecklist: List<String> = emptyList(),
    val replacedParts: List<ReplacedSparePart> = emptyList(),
    val technicianRemarks: String = "Full diagnostic cycle complete. All parameters within ISO-certified safety range.",
    val clientFeedbackRating: Int = 5,
    val clientRejectionReason: String? = null,
    val isSavedToPhoneStorage: Boolean = false,
    val savedLocalPhonePath: String = "/storage/emulated/0/DCIM/QuickIt_Proofs/VID_PRF_${System.currentTimeMillis()}.mp4",
    val fileSizeBytes: Long = 14_857_600L,
    val storageFolder: String = "DCIM/QuickIt_Service_Proofs",
    val videoResolution: String = "1080p FHD (60fps)",
    // Customer Video Review, Download & Upload from Device
    val customerDownloadedVideo: Boolean = false,
    val customerDownloadedPath: String? = null,
    val customerLocalVideoPath: String? = null,
    val customerUploadTimestamp: String? = null,
    val customerIssueNotes: String? = null,
    // Payment Hold & Admin Approval Workflow
    val isPaymentOnHold: Boolean = false,
    val paymentHoldReason: String? = null,
    val issueCategory: String? = null,
    val isCustomerPaidAfterProof: Boolean = false,
    val paymentSettledMethod: String? = null,
    val adminApprovalNotes: String? = null,
    val adminReviewedAt: String? = null,
    val adminReviewerName: String? = null
)

enum class ProximityAlertType {
    NEARBY,       // Within 400-500 meters (~2 mins)
    ARRIVED,      // Arrived at customer doorstep
    DISPATCHED,   // Dispatched from dark store hub
    STATUS_UPDATE // Live progress update
}

data class FcmProximityAlert(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val orderId: String,
    val technicianName: String,
    val technicianPhone: String,
    val distanceMeters: Int,
    val etaMinutes: Int,
    val otpCode: String,
    val alertType: ProximityAlertType = ProximityAlertType.NEARBY,
    val timestamp: Long = System.currentTimeMillis()
)

enum class DiagnosticUploadStatus(val label: String) {
    RECORDED_LOCALLY("Saved to Device Storage"),
    UPLOADING_FIREBASE("Uploading to Firebase Storage..."),
    UPLOADED_FIREBASE("Synced to Firebase Storage"),
    FAILED("Upload Failed (Cached Locally)")
}

data class DiagnosticVideoRecord(
    val id: String = "DIAG-" + (10000..99999).random(),
    val localFilePath: String,
    val fileSizeBytes: Long = 18_388_608L, // ~18 MB for 1-minute 1080p clip
    val durationSeconds: Int = 60, // 1-minute video showing the problem
    val recordedTimestamp: String = "Just now",
    val serviceCategory: String = "General Diagnostic",
    val issueDescription: String = "1-minute video showing fault symptom & noise/leakage area",
    val firebaseStorageRef: String = "gs://quickit-services.appspot.com/diagnostic_videos/${System.currentTimeMillis()}.mp4",
    val firebaseDownloadUrl: String? = "https://firebasestorage.googleapis.com/v0/b/quickit-services.appspot.com/o/diagnostic_videos%2Fsample.mp4?alt=media",
    val uploadProgress: Float = 1.0f,
    val uploadStatus: DiagnosticUploadStatus = DiagnosticUploadStatus.RECORDED_LOCALLY,
    val isSavedToLocalStorage: Boolean = true,
    val aiDiagnosticSummary: String = "Identified potential joint leakage & pressure irregularity",
    val recommendedSpareParts: List<String> = listOf("CPVC Seal Tape", "O-Ring Gasket", "Pressure Valve Adapter"),
    val technicianPreparationNotes: String = "Technician will carry specialized plumbing wrench and sealing kit."
)





