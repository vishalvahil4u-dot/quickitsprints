package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.ServiceItem
import com.example.ui.theme.*

/**
 * Blinkit Case Study Showcase Components.
 * Embodies the core principles of Blinkit's 10-Minute Dark Store & AI Logistics Network
 * as studied in the Young Urban Project Quick-Commerce Case Study:
 * 1. Distributed Dark Store Micro-Hubs (1,800+ stores in 2-3km urban demand clusters)
 * 2. AI Algorithmic Dispatch & Demand Forecasting
 * 3. In-Store Spare Parts & Professional Tooling Kits (90-sec pack SLA)
 * 4. Density-Driven Unit Economics & Fast Doorstep Turnaround
 */

@Composable
fun BlinkitCaseStudyArchitectureBanner(
    onExploreCaseStudy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onExploreCaseStudy() }
            .testTag("blinkit_case_study_banner"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF0C831F), // Blinkit Forest Green
                            Color(0xFF075E14),
                            Color(0xFF04380B)
                        )
                    )
                )
                .border(1.dp, Color(0xFF22C55E).copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Top Tag & Case Study Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BlinkitYellow
                        ) {
                            Text(
                                text = "CASE STUDY",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "Blinkit Dark Store & AI Logistics",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = Color.White.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF4ADE80), CircleShape)
                            )
                            Text(
                                text = "1,800+ Hubs",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                // Title & Value Prop
                Text(
                    text = "How QuickIt delivers Certified Services & Spares in 10-15 Minutes",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    lineHeight = 20.sp
                )

                // 3 Core Pillars Visual Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BlinkitMiniPillar(
                        icon = Icons.Default.Storefront,
                        title = "2-3 km Radius",
                        subtitle = "Micro-Hubs"
                    )
                    BlinkitMiniPillar(
                        icon = Icons.Default.ElectricBolt,
                        title = "90-Sec Pack",
                        subtitle = "Dark Store SLA"
                    )
                    BlinkitMiniPillar(
                        icon = Icons.Default.Psychology,
                        title = "AI Dispatch",
                        subtitle = "Route Engine"
                    )
                    BlinkitMiniPillar(
                        icon = Icons.Default.Verified,
                        title = "OEM Spares",
                        subtitle = "In-Store Staged"
                    )
                }

                // Tap CTA
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📖 Learn the 10-Minute Dark Store Business Model",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = BlinkitYellow,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BlinkitMiniPillar(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BlinkitYellow,
                modifier = Modifier.size(16.dp)
            )
        }
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = subtitle,
            fontSize = 9.sp,
            color = Color.White.copy(alpha = 0.75f)
        )
    }
}

/**
 * Live Dark Store Proximity & Tooling Status Widget
 */
@Composable
fun BlinkitLiveDarkStoreStatusCard(
    hubName: String = "QuickIt Hub #14 - Indiranagar Pro Center",
    distanceKm: Double = 1.4,
    techsAvailable: Int = 8,
    sparesInStock: Int = 2480,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF16A34A), CircleShape)
                    )
                    Text(
                        text = "CONNECTED DARK STORE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF16A34A),
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = BlinkitYellowLight,
                    border = BorderStroke(1.dp, BlinkitYellowDark)
                ) {
                    Text(
                        text = "⚡ $distanceKm km away • 10-15 Min ETA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitDark,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = hubName,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitDark
            )

            // Metrics row: Staged Techs, In-Store Spares, Average Dispatch SLA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DarkStoreMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Staged Pros",
                    value = "$techsAvailable Ready",
                    emoji = "🛵",
                    bg = Color(0xFFF0FDF4)
                )
                DarkStoreMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Hub Spares",
                    value = "$sparesInStock SKUs",
                    emoji = "📦",
                    bg = Color(0xFFEFF6FF)
                )
                DarkStoreMetricBox(
                    modifier = Modifier.weight(1f),
                    label = "Dispatch SLA",
                    value = "90 Sec",
                    emoji = "⏱️",
                    bg = Color(0xFFFFFBEB)
                )
            }
        }
    }
}

@Composable
private fun DarkStoreMetricBox(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    emoji: String,
    bg: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(emoji, fontSize = 11.sp)
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Gray
                )
            }
            Text(
                text = value,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = BlinkitDark
            )
        }
    }
}

/**
 * Blinkit Signature Flash Deals & Quick Spotlight Carousel
 */
@Composable
fun BlinkitFlashDealsCarousel(
    onBookService: (ServiceItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val deals = listOf(
        FlashDeal(
            id = "deal_1",
            title = "Tap & Pipe Leak Emergency Fix",
            subtitle = "CPVC Teflon Seal + Brass Washer Kit Included",
            price = 199.0,
            originalPrice = 399.0,
            discount = "50% OFF",
            emoji = "🚰",
            tag = "⚡ 10 MINS DISPATCH",
            badgeColor = BlinkitGreen,
            service = ServiceItem(
                id = "deal_1",
                categoryId = "cat_plumbing",
                name = "Tap & Pipe Leak Emergency Fix",
                subCategory = "Emergency Leakage",
                description = "Rapid 10-min repair for dripping faucets, kitchen sinks & bathroom CPVC pipe joints with replacement seal included.",
                price = 199.0,
                originalPrice = 399.0,
                discountPercent = 50,
                emoji = "🚰",
                duration = "20 mins",
                warranty = "30 Days Zero-Leak Guarantee",
                toolkitRequired = "CPVC Pipe Wrench, Teflon Tape, Brass Spindle #2",
                etaMinutes = "10 mins"
            )
        ),
        FlashDeal(
            id = "deal_2",
            title = "AC Jet Foam Clean & Gas Pressure Check",
            subtitle = "Kills 99.9% Mold & Clears Clogged Drain Tray",
            price = 499.0,
            originalPrice = 999.0,
            discount = "50% OFF",
            emoji = "❄️",
            tag = "🔥 BESTSELLER",
            badgeColor = Color(0xFFEA580C),
            service = ServiceItem(
                id = "deal_2",
                categoryId = "cat_appliance",
                name = "AC Jet Foam Clean & Inspection",
                subCategory = "AC Deep Foam Wash",
                description = "High-pressure jet wash with Diversey antimicrobial foam, filter sanitization & digital gas pressure test.",
                price = 499.0,
                originalPrice = 999.0,
                discountPercent = 50,
                emoji = "❄️",
                duration = "45 mins",
                warranty = "60-Day Cooling Guarantee",
                toolkitRequired = "High-Pressure Jet Gun, Diversey Foam, Manifold Gauge",
                etaMinutes = "12 mins"
            )
        ),
        FlashDeal(
            id = "deal_3",
            title = "Switchboard Spark & MCB Tripping Fix",
            subtitle = "1000V Insulated Safety Check + Havells 16A Switch",
            price = 149.0,
            originalPrice = 299.0,
            discount = "50% OFF",
            emoji = "⚡",
            tag = "🦺 1000V SAFETY",
            badgeColor = Color(0xFF0284C7),
            service = ServiceItem(
                id = "deal_3",
                categoryId = "cat_electric",
                name = "Switchboard Spark & MCB Fix",
                subCategory = "Safety & Sparking",
                description = "Immediate diagnostics and replacement of loose burnt neutral wiring, tripping breakers, or sparking socket plates.",
                price = 149.0,
                originalPrice = 299.0,
                discountPercent = 50,
                emoji = "⚡",
                duration = "25 mins",
                warranty = "30-Day Fireproof Guarantee",
                toolkitRequired = "Digital Multimeter, Havells 16A Switch, Fire-Sleeve Wire",
                etaMinutes = "10 mins"
            )
        )
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "⚡ Blinkit Flash Deals",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BlinkitDark
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFFFEE2E2)
                ) {
                    Text(
                        text = "50% OFF",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        color = BlinkitRed,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = "Dispatched in 10 mins",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitGreenDark
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(deals) { deal ->
                FlashDealCard(deal = deal, onBook = { onBookService(deal.service) })
            }
        }
    }
}

private data class FlashDeal(
    val id: String,
    val title: String,
    val subtitle: String,
    val price: Double,
    val originalPrice: Double,
    val discount: String,
    val emoji: String,
    val tag: String,
    val badgeColor: Color,
    val service: ServiceItem
)

@Composable
private fun FlashDealCard(
    deal: FlashDeal,
    onBook: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier
            .width(260.dp)
            .clickable { onBook() },
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = deal.badgeColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = deal.tag,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = deal.badgeColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = BlinkitRedLight
                ) {
                    Text(
                        text = deal.discount,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitRed,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BlinkitYellowLight),
                    contentAlignment = Alignment.Center
                ) {
                    Text(deal.emoji, fontSize = 24.sp)
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = deal.title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitDark,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = deal.subtitle,
                        fontSize = 10.sp,
                        color = Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Price & Book Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "₹${deal.price.toInt()}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = BlinkitDark
                    )
                    Text(
                        text = "₹${deal.originalPrice.toInt()}",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textDecoration = TextDecoration.LineThrough
                    )
                }

                Button(
                    onClick = onBook,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BlinkitGreen,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text("ADD", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

/**
 * Blinkit Case Study Deep-Dive Interactive Dialog.
 * Explains the 4 operational pillars and the comprehensive Marketing Strategy (7Ps, STP, Moment Marketing, Unit Economics)
 * from the Young Urban Project & SlideShare Marketing Case Studies.
 */
@Composable
fun BlinkitCaseStudyDeepDiveDialog(
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🎯 Marketing Mix (7Ps)", "🏬 Micro-Hubs", "🤖 AI Logistics", "📦 Spare Parts", "📈 Economics & STP")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(BlinkitYellow, BlinkitYellowDark)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "blinkit",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BlinkitDark,
                                    letterSpacing = (-0.5).sp
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = BlinkitGreen
                                ) {
                                    Text(
                                        text = "MARKETING CASE STUDY",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Marketing Strategy, 7Ps Mix & Hyperlocal Scale",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark.copy(alpha = 0.85f)
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.Black.copy(alpha = 0.1f), CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitDark)
                        }
                    }
                }

                // Tab Switcher
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF8FAFC),
                    contentColor = BlinkitGreenDark,
                    edgePadding = 12.dp
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedTab == index) BlinkitGreenDark else Color(0xFF64748B)
                                )
                            }
                        )
                    }
                }

                // Tab Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (selectedTab) {
                        0 -> CaseStudyTabMarketingMix7Ps()
                        1 -> CaseStudyTabMicroHubs()
                        2 -> CaseStudyTabAiLogistics()
                        3 -> CaseStudyTabSpareParts()
                        4 -> CaseStudyTabEconomicsAndSTP()
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Got It • Experience 10-Min Service",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CaseStudyTabMarketingMix7Ps() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("🎯 The 7Ps of Blinkit Quick Commerce & On-Demand Services")

        Text(
            text = "Strategic Marketing Mix Analysis (Product, Price, Place, Promotion, People, Process, Physical Evidence)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        CaseStudyBulletPoint(
            "1. 📦 Product (Curated Instant Essentials & Services)",
            "Hyper-focused on high-intent urgent needs (plumbing leaks, sparking switches, AC breakdowns). Solves high-stress household problems in 10-15 mins with verified spares included."
        )
        CaseStudyBulletPoint(
            "2. 🏷️ Price (Value-Driven & Dynamic Bundles)",
            "Zero hidden charges, transparent pricing (starting ₹99), dynamic 50% flash discounts, bundled service packs to maximize Average Order Value (AOV)."
        )
        CaseStudyBulletPoint(
            "3. 🏬 Place (Hyperlocal Dark Store Distribution)",
            "1,800+ micro-fulfillment centers embedded in 2-3km urban radii across 28+ Indian cities, cutting transit time to under 8 minutes."
        )
        CaseStudyBulletPoint(
            "4. 📣 Promotion (Contextual Triggers & Value Discounts)",
            "Contextual in-app triggers (seasonal leak and AC servicing alerts, high-intent emergency notifications), digital performance marketing, and Pro Pass membership rewards."
        )
        CaseStudyBulletPoint(
            "5. 🧑‍🔧 People (Certified Pro Fleet)",
            "Police-verified, background-checked technicians equipped with standardized training, uniform, and digital ID authentication."
        )
        CaseStudyBulletPoint(
            "6. ⏱️ Process (90-Sec Dark Store SLA & Real-Time Tracking)",
            "Algorithmic dispatch assigns nearest technician in 90 seconds. Live GPS map telemetry gives customer real-time arrival countdown."
        )
        CaseStudyBulletPoint(
            "7. 🛡️ Physical Evidence (Tamper-Proof Kits & Digital Proof)",
            "Sealed OEM spare parts, branded yellow toolkits, photo/video work proof reviews, and digital warranty certificates."
        )
    }
}

@Composable
private fun CaseStudyTabEconomicsAndSTP() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("📈 STP Strategy, Unit Economics & Dark Store Density")

        Text(
            text = "Segmentation, Targeting, Positioning (STP) & Profitability Formula",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        CaseStudyBulletPoint(
            "🎯 Market Segmentation",
            "Demographic: Urban millennials, working couples, gated community residents. Behavioral: High willingness to pay for instant emergency resolution."
        )
        CaseStudyBulletPoint(
            "📍 Target Audience",
            "Time-poor, convenience-first urban dwellers who dread waiting 2-4 hours for traditional local handymen."
        )
        CaseStudyBulletPoint(
            "🏆 Positioning",
            "'The 10-Minute Dark Store for Everything' — Fastest, most reliable doorstep solution with 100% genuine parts."
        )
        CaseStudyBulletPoint(
            "📊 Density-Driven Economics",
            "High order density within a 2km radius unlocks 6-8 daily jobs per pro (vs 2-3 historically), achieving positive contribution margins & EBITDA turnaround in FY26."
        )
    }
}

@Composable
private fun CaseStudyTabMicroHubs() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("🏬 Pillar 1: Dense Dark Store Network")

        Text(
            text = "Why Traditional 45-Min Services Fail vs. The 2km Micro-Hub",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        Text(
            text = "Instead of relying on distant central warehouses, Blinkit places 1,800+ micro-fulfillment centers directly within urban demand clusters. Each dark store serves a tightly defined 2-3 km radius.",
            fontSize = 12.sp,
            lineHeight = 18.sp,
            color = Color(0xFF334155)
        )

        CaseStudyBulletPoint(
            "⚡ 2-3 km Hyperlocal Radius",
            "Cuts travel time from 35 mins down to 6-8 mins of road transit."
        )
        CaseStudyBulletPoint(
            "🏬 Micro-Hub Proximity",
            "Technicians and inventory are co-located in the neighborhood pro center."
        )
        CaseStudyBulletPoint(
            "⏱️ 90-Second Dark Store SLA",
            "Order picking and toolkit assembly happens in under 2 minutes."
        )
    }
}

@Composable
private fun CaseStudyTabAiLogistics() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("🤖 Pillar 2: AI Logistics & Algorithmic Dispatch")

        Text(
            text = "Predictive Demand Heatmaps & Instant Dispatch Routing",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        Text(
            text = "Blinkit leverages machine learning models to forecast demand surges by neighborhood, weather (e.g. monsoon pipe leaks, heatwave AC servicing), and time-of-day traffic.",
            fontSize = 12.sp,
            lineHeight = 18.sp,
            color = Color(0xFF334155)
        )

        CaseStudyBulletPoint(
            "📊 Pre-Positioning Pros & Tools",
            "AI stages plumbers and electricians at the dark store before peak booking hours."
        )
        CaseStudyBulletPoint(
            "🗺️ Dynamic Route Optimization",
            "Calculates the fastest route avoiding city bottlenecks in real time."
        )
        CaseStudyBulletPoint(
            "📹 Visual AI Diagnostic Triage",
            "Matches customer video recordings to exact toolkits and spare parts."
        )
    }
}

@Composable
private fun CaseStudyTabSpareParts() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("📦 Pillar 3: In-Store Spare Parts & Certified Tooling")

        Text(
            text = "Zero-Repeat Visits: Everything Pre-Loaded in the Hub",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        Text(
            text = "In traditional home services, technicians waste 60-90 minutes running to local hardware stores to buy parts. QuickIt solves this by storing 2,400+ genuine OEM replacement SKUs inside the dark store.",
            fontSize = 12.sp,
            lineHeight = 18.sp,
            color = Color(0xFF334155)
        )

        CaseStudyBulletPoint(
            "🛡️ 100% Genuine Certified Parts",
            "Astral CPVC, Havells 16A switches, LG/Samsung AC spares, Diversey chemicals."
        )
        CaseStudyBulletPoint(
            "🦺 1000V Insulated Toolkits",
            "Technicians depart with calibrated professional tools and safety gear."
        )
        CaseStudyBulletPoint(
            "📄 30-Day Zero-Leak Warranty",
            "All hub-dispatched spare parts carry a standardized 30-day replacement guarantee."
        )
    }
}

@Composable
private fun CaseStudyTabEconomics() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CaseStudyHeaderBadge("📈 Pillar 4: Unit Economics & Quick Commerce Profitability")

        Text(
            text = "Density-Driven Contribution & Positive EBITDA",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = BlinkitDark
        )

        Text(
            text = "As highlighted in the case study, Blinkit achieved Adjusted EBITDA profitability in FY26 through sheer dark store density and high order volume per square kilometer.",
            fontSize = 12.sp,
            lineHeight = 18.sp,
            color = Color(0xFF334155)
        )

        CaseStudyBulletPoint(
            "🚀 High Asset Utilization",
            "Technicians complete 6-8 proximate jobs daily vs 2-3 in traditional models."
        )
        CaseStudyBulletPoint(
            "🤝 Zomato Logistics Synergies",
            "Leveraging shared urban micro-hub infrastructure and rapid fleet density."
        )
        CaseStudyBulletPoint(
            "💰 Positive Unit Contribution",
            "Low delivery radius reduces transit fuel and maximizes customer retention."
        )
    }
}

@Composable
private fun CaseStudyHeaderBadge(text: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = BlinkitGreenLight,
        border = BorderStroke(1.dp, BlinkitGreen.copy(alpha = 0.3f))
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = BlinkitGreenDark,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun CaseStudyBulletPoint(title: String, desc: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitDark
            )
            Text(
                text = desc,
                fontSize = 11.sp,
                color = Color(0xFF475569),
                lineHeight = 15.sp
            )
        }
    }
}

/**
 * Blinkit Club / Instant Pro Pass Membership Card (Retention Engine)
 */
@Composable
fun BlinkitClubMembershipCard(
    onExploreClub: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onExploreClub() },
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.horizontalGradient(
                        listOf(
                            Color(0xFF1E293B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFFFFDF00), Color(0xFFD4AF37))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = Color(0xFF0F172A),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Blinkit Pro Pass",
                                color = Color(0xFFFFDF00),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFFFDF00).copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "FREE VIP",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFFFDF00),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "₹0 Inspection Fee • Priority 10-Min Dispatch • 10% Cashback",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Button(
                    onClick = onExploreClub,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFDF00),
                        contentColor = Color(0xFF0F172A)
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("ACTIVE", fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

/**
 * Blinkit Smart Service Combos (AOV Maximizer from Case Study)
 */
@Composable
fun BlinkitSmartServiceBundlesSection(
    onBookService: (ServiceItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val bundleServices = listOf(
        ServiceItem(
            id = "bundle_monsoon_leak",
            categoryId = "cat_plumbing",
            name = "Monsoon Leak Rescue Pack (2 Taps + Drain Clean)",
            subCategory = "Emergency Leakage",
            description = "Complete home plumbing check: CPVC Teflon re-sealing for 2 faucets + kitchen drain blockage clear with anti-clog chemicals.",
            price = 349.0,
            originalPrice = 699.0,
            discountPercent = 50,
            emoji = "🚰",
            duration = "35 mins",
            warranty = "60-Day Complete Leak Guarantee",
            toolkitRequired = "CPVC Multi-Wrench, Drain Gun, Teflon Pro Roll",
            etaMinutes = "10 mins"
        ),
        ServiceItem(
            id = "bundle_summer_cool",
            categoryId = "cat_appliance",
            name = "Complete AC Jet Clean + Outdoor Unit Blast",
            subCategory = "AC Deep Foam Wash",
            description = "Indoor evaporator antimicrobial jet wash + outdoor condenser coil dirt flush for maximum energy saving and cooling.",
            price = 799.0,
            originalPrice = 1499.0,
            discountPercent = 47,
            emoji = "❄️",
            duration = "55 mins",
            warranty = "90-Day Peak Chilling Warranty",
            toolkitRequired = "Dual Jet Pressure Gun, Diversey Foam, Fin Comb",
            etaMinutes = "12 mins"
        )
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "📦 Smart Service Combos",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BlinkitDark
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = BlinkitGreenLight
                ) {
                    Text(
                        text = "SAVE ₹300+",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        color = BlinkitGreenDark,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                text = "Bundled SLA",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = BlinkitGreenDark
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(bundleServices) { bundle ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .width(280.dp)
                        .clickable { onBookService(bundle) },
                    shadowElevation = 1.dp
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = BlinkitGreenLight
                            ) {
                                Text(
                                    text = "COMBO SAVER",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitGreenDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "⏱️ ${bundle.duration}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(BlinkitYellowLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(bundle.emoji, fontSize = 22.sp)
                            }
                            Text(
                                text = bundle.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text(
                            text = bundle.description,
                            fontSize = 10.sp,
                            color = Color(0xFF64748B),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "₹${bundle.price.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BlinkitDark
                                )
                                Text(
                                    text = "₹${bundle.originalPrice.toInt()}",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    textDecoration = TextDecoration.LineThrough
                                )
                            }

                            Button(
                                onClick = { onBookService(bundle) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BlinkitGreen,
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("ADD COMBO", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
