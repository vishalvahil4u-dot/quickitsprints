package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun CustomerBookingsScreen(
    repository: BlinkitRepository,
    onTrackActiveOrder: () -> Unit,
    onExploreServices: () -> Unit
) {
    val activeOrder by repository.activeOrder.collectAsState()
    val pastOrders by repository.pastOrders.collectAsState()

    var selectedOrderForProof by remember { mutableStateOf<OrderItem?>(null) }
    var selectedOrderForDownload by remember { mutableStateOf<OrderItem?>(null) }
    var selectedOrderForUpload by remember { mutableStateOf<OrderItem?>(null) }

    val allUserOrders = remember(activeOrder, pastOrders) {
        val list = mutableListOf<OrderItem>()
        activeOrder?.let { list.add(it) }
        list.addAll(pastOrders.filter { it.id != activeOrder?.id })
        list
    }

    Scaffold(
        topBar = {
            Surface(
                color = BlinkitSurface,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "My Service Bookings",
                        color = BlinkitTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = BlinkitGreenLight,
                        shape = RoundedCornerShape(100.dp)
                    ) {
                        Text(
                            "⚡ 10-Min Fast Dispatch",
                            color = BlinkitGreenDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        },
        containerColor = BlinkitBackground
    ) { innerPadding ->
        if (allUserOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(BlinkitYellowLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🧰", fontSize = 36.sp)
                    }
                    Text(
                        "No Service Bookings Yet",
                        color = BlinkitTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Book expert plumbers, cleaners, electricians and appliance techs delivered in 10-15 minutes.",
                        color = BlinkitTextSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Button(
                        onClick = onExploreServices,
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen, contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Explore Instant Services", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(allUserOrders, key = { it.id }) { order ->
                    val isActive = order.status != OrderStatus.DELIVERED && order.status != OrderStatus.CANCELLED

                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        border = BorderStroke(
                            1.dp,
                            if (isActive) BlinkitYellowDark.copy(alpha = 0.5f) else BlinkitBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Booking Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        order.orderNumber,
                                        color = BlinkitTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        order.placedAtTime,
                                        color = BlinkitTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }

                                Surface(
                                    color = if (isActive) BlinkitYellowLight else BlinkitGreenLight,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        order.status.displayName,
                                        color = if (isActive) BlinkitDark else BlinkitGreenDark,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            // Visual Step Tracker Component (Requested -> Hub Prep -> En Route -> In Service -> Completed)
                            BookingVisualStepTracker(
                                order = order,
                                onAdvanceStatus = { nextStatus ->
                                    repository.updateOrderStatus(order.id, nextStatus)
                                },
                                onOpenTracker = if (isActive) onTrackActiveOrder else null,
                                isExpandedDefault = isActive
                            )

                            HorizontalDivider(color = BlinkitBorder)

                            // Items
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                order.items.forEach { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            "${item.service.emoji} ${item.quantity}x ${item.service.name}",
                                            color = BlinkitTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            "₹" + String.format("%.0f", item.service.price * item.quantity),
                                            color = BlinkitTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Total & OTP
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isActive) {
                                    Surface(
                                        color = BlinkitDark,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            "Start OTP: ${order.otpCode}",
                                            color = BlinkitYellow,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                } else {
                                    Text(
                                        "🛡️ 30-Day Guarantee Active",
                                        color = BlinkitGreenDark,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    "Total: ₹" + String.format("%.0f", order.grandTotal),
                                    color = BlinkitTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            // Technician details
                            Surface(
                                color = BlinkitSurfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("👷‍♂️", fontSize = 16.sp)
                                    Column {
                                        Text(
                                            "Technician: ${order.riderName} (${order.technicianSpeciality})",
                                            color = BlinkitTextPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "Hub: ${order.darkStoreHub}",
                                            color = BlinkitTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }

                            // Action CTA for active/past orders (Download, Upload Rebuttal, Review Proof, Live Tracker)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { selectedOrderForDownload = order },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                        border = BorderStroke(1.dp, BlinkitDark)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, tint = BlinkitDark, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            if (order.workProof?.customerDownloadedVideo == true) "Downloaded" else "Download",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BlinkitDark
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { selectedOrderForUpload = order },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                        border = BorderStroke(1.dp, Color(0xFFEA580C))
                                    ) {
                                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            if (order.workProof?.customerLocalVideoPath != null) "Rebuttal ✓" else "Upload Video",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFEA580C)
                                        )
                                    }

                                    Button(
                                        onClick = { selectedOrderForProof = order },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1.1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (order.workProof?.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD) Color(0xFFEA580C) else BlinkitGreen
                                        )
                                    ) {
                                        Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            if (order.workProof?.status == WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD) "Hold Status" else "Review Proof",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }

                                if (isActive) {
                                    Button(
                                        onClick = onTrackActiveOrder,
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark, contentColor = Color.White),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.NearMe, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Open Live Technician Tracker", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Customer Work Proof Review & Warranty Dialog
            selectedOrderForProof?.let { targetOrder ->
                ClientWorkProofReviewDialog(
                    order = targetOrder,
                    onApproveProof = { rating, paymentMethod ->
                        repository.approveWorkProofByClient(targetOrder.id, rating, paymentMethod)
                    },
                    onRequestRevision = { reason ->
                        repository.requestWorkProofRevision(targetOrder.id, reason)
                    },
                    onDownloadVideo = {
                        repository.downloadProofVideoLocally(targetOrder.id)
                    },
                    onUploadLocalDeviceVideo = { localPath, reason, category ->
                        repository.uploadCustomerLocalProofVideo(targetOrder.id, localPath, reason, category)
                    },
                    onEscalateToAdmin = { reason, category, localPath ->
                        repository.escalateToAdminReview(targetOrder.id, reason, category, localPath)
                    },
                    onDismiss = { selectedOrderForProof = null }
                )
            }

            // Customer Direct Video Download Dialog
            selectedOrderForDownload?.let { targetOrder ->
                CustomerVideoDownloadDialog(
                    order = targetOrder,
                    onDownloadConfirmed = {
                        repository.downloadProofVideoLocally(targetOrder.id)
                    },
                    onDismiss = { selectedOrderForDownload = null }
                )
            }

            // Customer Direct Video Upload Dialog
            selectedOrderForUpload?.let { targetOrder ->
                CustomerVideoUploadDialog(
                    order = targetOrder,
                    onUploadConfirmed = { localPath, reason, category ->
                        repository.uploadCustomerLocalProofVideo(targetOrder.id, localPath, reason, category)
                    },
                    onDismiss = { selectedOrderForUpload = null }
                )
            }
        }
    }
}
