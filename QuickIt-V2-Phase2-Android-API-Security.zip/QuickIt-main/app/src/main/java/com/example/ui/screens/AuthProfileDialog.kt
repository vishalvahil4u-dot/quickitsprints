package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.BlinkitRepository
import com.example.data.UserProfile
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AuthProfileDialog(
    repository: BlinkitRepository,
    onDismiss: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val isAuthLoading by repository.isAuthLoading.collectAsState()
    val authError by repository.authError.collectAsState()
    val pastOrders by repository.pastOrders.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var showEmailLogin by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("") }
    var passInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = BlinkitYellowLight,
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AccountCircle,
                                    contentDescription = "Auth",
                                    tint = BlinkitGreenDark,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                "Firebase Auth & Sync",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitTextPrimary
                            )
                            Text(
                                "Cloud Data Persistence",
                                fontSize = 11.sp,
                                color = BlinkitTextSecondary
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (currentUser != null) {
                    // Logged in User Card
                    val user = currentUser!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = BlinkitYellowLight.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.dp, BlinkitYellow)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(BlinkitGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = user.displayName.take(1).uppercase(),
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = user.displayName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitTextPrimary
                            )

                            Text(
                                text = user.email,
                                fontSize = 13.sp,
                                color = BlinkitTextSecondary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Surface(
                                color = BlinkitGreenLight,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Verified,
                                        contentDescription = "Verified",
                                        tint = BlinkitGreenDark,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = user.membershipLevel,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BlinkitGreenDark
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Firestore Synced Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = BlinkitBackground,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BlinkitBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Firestore Sync", fontSize = 10.sp, color = BlinkitTextSecondary)
                                Text("Active ☁️", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            color = BlinkitBackground,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BlinkitBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Cloud Bookings", fontSize = 10.sp, color = BlinkitTextSecondary)
                                Text("${pastOrders.size} Synced", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sign Out Button
                    OutlinedButton(
                        onClick = {
                            repository.signOutFirebase()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = BlinkitRed
                        ),
                        border = BorderStroke(1.dp, BlinkitRed.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign Out", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sign Out", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                } else {
                    // Not Logged In - Sign In Options
                    Text(
                        "Sign in to synchronize your 10-minute bookings, warranty certificates, and saved addresses via Firebase Firestore.",
                        fontSize = 12.sp,
                        color = BlinkitTextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Google Sign-In Button with Credential Manager
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                repository.signInWithGoogle()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BlinkitDark,
                            contentColor = Color.White
                        ),
                        enabled = !isAuthLoading
                    ) {
                        if (isAuthLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = BlinkitYellow,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = Color.White,
                                    shape = CircleShape,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("G", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = BlinkitDark)
                                    }
                                }
                                Text("Continue with Google Sign-In", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Email Login Toggle
                    if (!showEmailLogin) {
                        TextButton(
                            onClick = { showEmailLogin = true }
                        ) {
                            Text("Or sign in with Email / Password", fontSize = 12.sp, color = BlinkitGreenDark)
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text("Email Address", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = passInput,
                                onValueChange = { passInput = it },
                                label = { Text("Password", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            Button(
                                onClick = {
                                    if (emailInput.isNotBlank() && passInput.isNotBlank()) {
                                        coroutineScope.launch {
                                            repository.signInWithEmail(emailInput, passInput)
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen)
                            ) {
                                Text("Sign In with Email", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                authError?.let { err ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = err,
                        color = BlinkitRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
