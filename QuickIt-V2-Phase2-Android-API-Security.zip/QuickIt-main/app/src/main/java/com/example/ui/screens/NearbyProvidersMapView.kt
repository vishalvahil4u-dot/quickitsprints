package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun NearbyProvidersMapView(
    repository: BlinkitRepository,
    onBookService: (ServiceItem) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val nearbyProviders by repository.nearbyProviders.collectAsState()
    val favoriteProviderIds by repository.favoriteProviderIds.collectAsState()
    val vicinityGrounding by repository.vicinityGrounding.collectAsState()
    val isGroundingLoading by repository.isGroundingLoading.collectAsState()
    val selectedAddress by repository.selectedAddress.collectAsState()
    val services by repository.services.collectAsState()

    var selectedProviderId by remember { mutableStateOf<String?>("prov_1") }
    var selectedCategoryFilter by remember { mutableStateOf("all") }
    var selectedNeighborhood by remember { mutableStateOf("Indiranagar 100ft Rd") }
    var showGroundingIntelDialog by remember { mutableStateOf(false) }

    val uriHandler = LocalUriHandler.current

    // Pulsing animation for active GPS radar beacons
    val infiniteTransition = rememberInfiniteTransition(label = "RadarPulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 18f,
        targetValue = 65f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseAlpha"
    )

    // Filter providers
    val filteredProviders = remember(nearbyProviders, selectedCategoryFilter, favoriteProviderIds) {
        when (selectedCategoryFilter) {
            "all" -> nearbyProviders
            "favorites" -> nearbyProviders.filter { favoriteProviderIds.contains(it.id) }
            else -> nearbyProviders.filter { it.categoryId == selectedCategoryFilter }
        }
    }

    val selectedProvider = remember(nearbyProviders, selectedProviderId) {
        nearbyProviders.find { it.id == selectedProviderId } ?: nearbyProviders.firstOrNull()
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.5.dp, BlinkitGreen.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Live Google Maps Vicinity & Model Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = Color(0xFF1E293B),
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Map,
                                contentDescription = "Live Maps",
                                tint = BlinkitYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Live Vicinity Service Pros",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitTextPrimary
                            )
                            Surface(
                                color = BlinkitGreenLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "LIVE GPS",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitGreenDark,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            "Grounded by Google Maps & Dark Store Hub",
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }

                // Refresh / Grounding Trigger Button
                Surface(
                    color = if (isGroundingLoading) BlinkitYellowLight else BlinkitDark,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.clickable(enabled = !isGroundingLoading) {
                        coroutineScope.launch {
                            repository.refreshVicinityWithGrounding(selectedNeighborhood)
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isGroundingLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                color = BlinkitDark,
                                strokeWidth = 2.dp
                            )
                            Text(
                                "Grounding...",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark
                            )
                        } else {
                            Icon(
                                Icons.Default.GpsFixed,
                                contentDescription = "Ground Location",
                                tint = BlinkitYellow,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                "Ground Maps",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Neighborhood selector chips
            val neighborhoods = listOf(
                "Indiranagar 100ft Rd",
                "Koramangala 5th Blk",
                "HSR Layout Sec 2",
                "Whitefield ITPL"
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(neighborhoods) { hood ->
                    val isSelected = selectedNeighborhood == hood
                    Surface(
                        color = if (isSelected) BlinkitGreenDark else Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(8.dp),
                        border = if (isSelected) null else BorderStroke(1.dp, BlinkitBorder),
                        modifier = Modifier.clickable {
                            selectedNeighborhood = hood
                            coroutineScope.launch {
                                repository.refreshVicinityWithGrounding(hood)
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                "📍",
                                fontSize = 10.sp
                            )
                            Text(
                                hood,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else BlinkitTextPrimary
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // GOOGLE MAPS INTERACTIVE RADAR / GPS CANVAS
            // =========================================================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFE8ECEF))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
            ) {
                // 1. Google Maps Styled Canvas Rendering
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(filteredProviders) {
                            detectTapGestures { tapOffset ->
                                val centerX = size.width / 2f
                                val centerY = size.height / 2f
                                val scaleX = size.width * 0.40f
                                val scaleY = size.height * 0.40f

                                // Check which provider marker is tapped
                                val clicked = filteredProviders.find { prov ->
                                    val provX = centerX + prov.longitudeOffset * scaleX
                                    val provY = centerY + prov.latitudeOffset * scaleY
                                    val dist = Math.hypot(
                                        (tapOffset.x - provX).toDouble(),
                                        (tapOffset.y - provY).toDouble()
                                    )
                                    dist < 48.0 // tap radius in px
                                }
                                if (clicked != null) {
                                    selectedProviderId = clicked.id
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height
                    val centerX = w / 2f
                    val centerY = h / 2f

                    // 1a. Draw Google Maps style terrain / water / parks
                    drawRect(
                        color = Color(0xFFE5E9EC),
                        size = size
                    )

                    // Draw green park area in top right
                    drawCircle(
                        color = Color(0xFFD4E7D5),
                        radius = w * 0.28f,
                        center = Offset(w * 0.85f, h * 0.2f)
                    )

                    // Draw water lake accent in bottom left
                    drawCircle(
                        color = Color(0xFFCCE4F7),
                        radius = w * 0.20f,
                        center = Offset(w * 0.12f, h * 0.88f)
                    )

                    // 1b. Draw Street Grid Lines (Google Maps Arterials)
                    val roadColor = Color(0xFFFFFFFF)
                    val highwayColor = Color(0xFFFDE68A)

                    // Secondary streets
                    drawLine(roadColor, Offset(0f, h * 0.25f), Offset(w, h * 0.35f), strokeWidth = 8f)
                    drawLine(roadColor, Offset(0f, h * 0.70f), Offset(w, h * 0.65f), strokeWidth = 8f)
                    drawLine(roadColor, Offset(w * 0.28f, 0f), Offset(w * 0.35f, h), strokeWidth = 8f)
                    drawLine(roadColor, Offset(w * 0.72f, 0f), Offset(w * 0.68f, h), strokeWidth = 8f)

                    // Main Express Corridor (100ft Rd)
                    drawLine(highwayColor, Offset(0f, centerY), Offset(w, centerY - 15f), strokeWidth = 14f)
                    drawLine(roadColor, Offset(centerX, 0f), Offset(centerX, h), strokeWidth = 12f)

                    // 1c. Draw Radar Range Rings (1km, 2km coverage)
                    drawCircle(
                        color = Color(0xFF0F172A).copy(alpha = 0.05f),
                        radius = w * 0.22f,
                        center = Offset(centerX, centerY),
                        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                    )
                    drawCircle(
                        color = Color(0xFF0F172A).copy(alpha = 0.03f),
                        radius = w * 0.40f,
                        center = Offset(centerX, centerY),
                        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f))
                    )

                    // 1d. Draw Central Dark Store Hub #14 Radar Pulse
                    drawCircle(
                        color = Color(0xFF0C831F).copy(alpha = pulseAlpha),
                        radius = pulseRadius * 1.5f,
                        center = Offset(centerX, centerY)
                    )
                    drawCircle(
                        color = Color(0xFF0C831F),
                        radius = 9f,
                        center = Offset(centerX, centerY)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = Offset(centerX, centerY)
                    )

                    // 1e. Draw route paths to selected provider
                    selectedProvider?.let { prov ->
                        val scaleX = w * 0.40f
                        val scaleY = h * 0.40f
                        val provX = centerX + prov.longitudeOffset * scaleX
                        val provY = centerY + prov.latitudeOffset * scaleY

                        // Dashed routing line from selected provider to user hub
                        drawLine(
                            color = Color(0xFF0C831F),
                            start = Offset(centerX, centerY),
                            end = Offset(provX, provY),
                            strokeWidth = 3.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                        )
                    }
                }

                // 2. Overlay Provider Markers on Top of Canvas
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val w = maxWidth
                    val h = maxHeight
                    val centerX = w / 2
                    val centerY = h / 2
                    val scaleX = w * 0.40f
                    val scaleY = h * 0.40f

                    // Dark Store Hub Center Marker Pill
                    Box(
                        modifier = Modifier
                            .offset(x = centerX - 42.dp, y = centerY - 32.dp)
                            .shadow(4.dp, RoundedCornerShape(12.dp))
                            .background(BlinkitDark, RoundedCornerShape(12.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text("⚡", fontSize = 9.sp)
                            Text(
                                "Hub #14 (You)",
                                color = BlinkitYellow,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Interactive Markers for each nearby provider
                    filteredProviders.forEach { prov ->
                        val posX = centerX + (scaleX * prov.longitudeOffset) - 20.dp
                        val posY = centerY + (scaleY * prov.latitudeOffset) - 20.dp
                        val isSelected = prov.id == selectedProviderId

                        Box(
                            modifier = Modifier
                                .offset(x = posX, y = posY)
                                .clickable { selectedProviderId = prov.id }
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(1.dp)
                            ) {
                                // Pro ETA Pill
                                Surface(
                                    color = if (isSelected) BlinkitGreenDark else Color(0xFF0F172A),
                                    shape = RoundedCornerShape(8.dp),
                                    shadowElevation = 4.dp
                                ) {
                                    Text(
                                        "${prov.etaMinutes}m",
                                        color = if (isSelected) BlinkitYellow else Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }

                                // Marker Circle with Avatar
                                Box(
                                    modifier = Modifier
                                        .size(if (isSelected) 36.dp else 28.dp)
                                        .shadow(6.dp, CircleShape)
                                        .background(
                                            if (isSelected) BlinkitYellow else Color.White,
                                            CircleShape
                                        )
                                        .border(
                                            if (isSelected) 2.5.dp else 1.5.dp,
                                            if (isSelected) BlinkitGreenDark else Color(0xFF64748B),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        prov.avatarEmoji,
                                        fontSize = if (isSelected) 16.sp else 13.sp
                                    )
                                    if (favoriteProviderIds.contains(prov.id)) {
                                        Text(
                                            "⭐",
                                            fontSize = 9.sp,
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .offset(x = 3.dp, y = (-3).dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Map Corner Controls Overlay
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .align(Alignment.BottomEnd),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color.White.copy(alpha = 0.90f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, BlinkitBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(BlinkitGreen, CircleShape)
                            )
                            Text(
                                "${filteredProviders.size} Active Pros Online",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark
                            )
                        }
                    }

                    Surface(
                        color = BlinkitDark.copy(alpha = 0.90f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { showGroundingIntelDialog = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text("🛰️", fontSize = 9.sp)
                            Text(
                                "Maps Intel",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitYellow
                            )
                        }
                    }
                }
            }

            // Category Filter Bar for Nearby Pros
            val categoryFilters = listOf(
                "all" to "All Nearby (${nearbyProviders.size})",
                "favorites" to "⭐ Starred Pros (${favoriteProviderIds.size})",
                "cat_plumbing" to "🔧 Plumbers (2)",
                "cat_electric" to "⚡ Electricians (1)",
                "cat_appliance" to "❄️ AC & Appliance (1)",
                "cat_cleaning" to "🧼 Cleaners (1)",
                "cat_carpentry" to "🪚 Carpenters (1)"
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(categoryFilters) { (catId, label) ->
                    val isSelected = selectedCategoryFilter == catId
                    val isFavChip = catId == "favorites"
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategoryFilter = catId },
                        label = {
                            Text(
                                label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (isFavChip) BlinkitYellowLight else BlinkitGreenLight,
                            selectedLabelColor = if (isFavChip) BlinkitDark else BlinkitGreenDark,
                            containerColor = Color.Transparent,
                            labelColor = BlinkitTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) {
                                if (isFavChip) BlinkitYellowDark else BlinkitGreen
                            } else BlinkitBorder
                        )
                    )
                }
            }

            // =========================================================================
            // SELECTED PROVIDER DETAIL HERO CARD
            // =========================================================================
            selectedProvider?.let { prov ->
                val isFavorite = favoriteProviderIds.contains(prov.id)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isFavorite) BlinkitYellowLight.copy(alpha = 0.35f) else Color(0xFFF8FAFC)
                    ),
                    border = BorderStroke(
                        if (isFavorite) 1.5.dp else 1.dp,
                        if (isFavorite) BlinkitYellowDark else BlinkitGreen.copy(alpha = 0.4f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(BlinkitYellowLight, CircleShape)
                                        .border(1.dp, BlinkitYellow, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(prov.avatarEmoji, fontSize = 22.sp)
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            prov.name,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = BlinkitTextPrimary
                                        )
                                        Icon(
                                            Icons.Default.Verified,
                                            contentDescription = "Verified",
                                            tint = Color(0xFF2563EB),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Text(
                                        prov.speciality,
                                        fontSize = 11.sp,
                                        color = BlinkitTextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("★", color = Color(0xFFF59E0B), fontSize = 11.sp)
                                        Text(
                                            "${prov.rating} (${prov.ratingCount} jobs)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BlinkitTextPrimary
                                        )
                                        Text("•", fontSize = 10.sp, color = BlinkitTextSecondary)
                                        Text(
                                            prov.vehicleType,
                                            fontSize = 10.sp,
                                            color = BlinkitTextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            // Star Favorite Button & ETA Badge
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.End,
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Surface(
                                        color = BlinkitGreenLight,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            "${prov.etaMinutes} MIN ETA",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = BlinkitGreenDark,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                    Text(
                                        "${prov.distanceKm} km away",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BlinkitTextSecondary
                                    )
                                }

                                // Star Favorite Toggle
                                IconButton(
                                    onClick = { repository.toggleFavoriteProvider(prov.id) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            if (isFavorite) BlinkitYellowLight else BlinkitSurfaceVariant,
                                            CircleShape
                                        )
                                        .border(
                                            1.dp,
                                            if (isFavorite) BlinkitYellowDark else BlinkitBorder,
                                            CircleShape
                                        )
                                ) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = if (isFavorite) "Starred Provider (Firestore Synced)" else "Star Provider",
                                        tint = if (isFavorite) BlinkitYellowDark else BlinkitTextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        // Starred Provider Synced Banner
                        if (isFavorite) {
                            Surface(
                                color = BlinkitYellowLight.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("⭐", fontSize = 10.sp)
                                    Text(
                                        "Starred Provider • Synced across all your devices via Firestore",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BlinkitDark
                                    )
                                }
                            }
                        }

                        // Pro on-board toolkits
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                "🧰 On-board:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitDark
                            )
                            prov.primaryToolkits.forEach { tool ->
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(0.5.dp, BlinkitBorder)
                                ) {
                                    Text(
                                        tool,
                                        fontSize = 9.sp,
                                        color = BlinkitTextSecondary,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // Action: Book service matching this provider's category
                        val matchingService = services.find { it.categoryId == prov.categoryId }
                        if (matchingService != null) {
                            Button(
                                onClick = { onBookService(matchingService) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = BlinkitYellow,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        "Instant Book ${matchingService.name} (₹${matchingService.price.toInt()})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Google Maps Grounding Summary Footer
            vicinityGrounding?.let { grounding ->
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(0.5.dp, BlinkitBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showGroundingIntelDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("📍", fontSize = 16.sp)
                            Column {
                                Text(
                                    "${grounding.nearestDarkStoreHub} • ${grounding.liveTrafficCondition}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitDark
                                )
                                Text(
                                    grounding.summaryText,
                                    fontSize = 10.sp,
                                    color = BlinkitTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "View Grounding",
                            tint = BlinkitTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    // Google Maps Grounding Details Dialog
    if (showGroundingIntelDialog) {
        AlertDialog(
            onDismissRequest = { showGroundingIntelDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = BlinkitYellow,
                        shape = CircleShape,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Public,
                                contentDescription = null,
                                tint = BlinkitDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            "Google Maps Grounding Intel",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "gemini-3.5-flash with googleMaps tool",
                            fontSize = 10.sp,
                            color = BlinkitGreenDark
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    vicinityGrounding?.let { grounding ->
                        Surface(
                            color = BlinkitGreenLight,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    "Location: ${grounding.locationName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitGreenDark
                                )
                                Text(
                                    grounding.summaryText,
                                    fontSize = 11.sp,
                                    color = BlinkitDark,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Text(
                            "Verified Local Hubs & Spare Depots:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitTextPrimary
                        )

                        grounding.landmarks.forEach { lm ->
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.5.dp, BlinkitBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        lm.uri?.let { uri ->
                                            try {
                                                uriHandler.openUri(uri)
                                            } catch (e: Exception) {
                                                // ignore
                                            }
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("📍", fontSize = 14.sp)
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            lm.title,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BlinkitDark
                                        )
                                        lm.snippet?.let {
                                            Text(it, fontSize = 10.sp, color = BlinkitTextSecondary)
                                        }
                                    }
                                    if (lm.uri != null) {
                                        Icon(
                                            Icons.Default.OpenInNew,
                                            contentDescription = "Open Maps",
                                            tint = Color(0xFF2563EB),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showGroundingIntelDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitDark)
                ) {
                    Text("Close")
                }
            }
        )
    }
}
