package com.example.domain.auth

import android.content.Context
import com.example.data.auth.AuthSessionStore
import com.example.data.remote.AuthDataDto
import com.example.data.remote.LoginRequest
import com.example.data.remote.QuickItApi
import com.example.data.remote.RegisterRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

sealed interface AuthResult<out T> {
    data class Success<T>(val value: T) : AuthResult<T>
    data class Failure(val message: String, val code: Int? = null) : AuthResult<Nothing>
}

class AuthRepository(
    context: Context,
    private val api: QuickItApi
) {
    private val session = AuthSessionStore(context.applicationContext)

    suspend fun login(email: String, password: String): AuthResult<AuthDataDto> =
        execute(api.login(LoginRequest(email.trim(), password)))
            .also { result -> if (result is AuthResult.Success) persist(result.value) }

    suspend fun register(request: RegisterRequest): AuthResult<AuthDataDto> =
        execute(api.register(request))
            .also { result -> if (result is AuthResult.Success) persist(result.value) }

    suspend fun currentUser() = withContext(Dispatchers.IO) {
        try {
            val response = api.me()
            if (response.isSuccessful && response.body()?.data != null) {
                AuthResult.Success(response.body()!!.data!!)
            } else {
                AuthResult.Failure(response.body()?.message ?: "Authentication session is invalid", response.code())
            }
        } catch (e: Exception) {
            AuthResult.Failure("Unable to reach QuickIt server")
        }
    }

    suspend fun logout() = session.clear()

    private suspend fun persist(data: AuthDataDto) {
        session.save(data.token, data.user.id.toString(), data.user.role)
    }

    private suspend fun <T> execute(response: Response<com.example.data.remote.ApiEnvelope<T>>): AuthResult<T> =
        withContext(Dispatchers.IO) {
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                AuthResult.Success(response.body()!!.data!!)
            } else {
                AuthResult.Failure(response.body()?.message ?: "Request failed", response.code())
            }
        }
}
