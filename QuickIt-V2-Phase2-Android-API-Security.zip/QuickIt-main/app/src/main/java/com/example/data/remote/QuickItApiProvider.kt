package com.example.data.remote

import android.content.Context

object QuickItApiProvider {
    @Volatile private var api: QuickItApi? = null

    fun get(context: Context): QuickItApi =
        api ?: synchronized(this) {
            api ?: ApiClient.initialize(context).also { api = it }
        }
}
