package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartCheckoutSheet(
    repository: BlinkitRepository,
    onBack: () -> Unit,
    onOrderPlaced: () -> Unit
) {
    val cart by repository.cart.collectAsState()
    val selectedAddress by repository.selectedAddress.collectAsState()
    val walletBalance by repository.walletBalance.collectAsState()
    val pendingDiagnosticVideo by repository.pendingDiagnosticVideo.collectAsState()

    var selectedTip by remember { mutableStateOf(30.0) }
    val selectedInstructions = remember { mutableStateListOf("Wear shoe covers 👟", "Bring pipe wrench 🔧", "Mask required 😷") }
    var selectedPaymentMethod by remember { mutableStateOf("UPI (Google Pay / PhonePe)") }
    var isPlacingOrder by remember { mutableStateOf(false) }

    val itemTotal = cart.sumOf { it.service.price * it.quantity }
    val mrpTotal = cart.sumOf { it.service.originalPrice * it.quantity }
    val totalSavings = mrpTotal - itemTotal
    val visitFee = if (itemTotal >= 299.0) 0.0 else 49.0
    val safetyFee = 29.0
    val grandTotal = itemTotal + visitFee + safetyFee + selectedTip

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Review Service Booking",
                            color = BlinkitTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "Hub #14 • Indiranagar Pro Center",
                            color = BlinkitGreenDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, tint = BlinkitTextPrimary)
                    }
                },
                actions = {
                    if (cart.isNotEmpty()) {
                        TextButton(onClick = { repository.clearCart() }) {
                            Text("Clear", color = BlinkitRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BlinkitSurface)
            )
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                // Bottom Checkout Bar
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Address Row Preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                                Column {
                                    Text(
                                        "Service at ${selectedAddress.label}",
                                        color = BlinkitTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        selectedAddress.addressLine,
                                        color = BlinkitTextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Pay & Book Button
                        Button(
                            onClick = {
                                isPlacingOrder = true
                                repository.placeOrder(
                                    tipAmount = selectedTip,
                                    instructions = selectedInstructions.toList(),
                                    paymentMethod = selectedPaymentMethod
                                )
                                isPlacingOrder = false
                                onOrderPlaced()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        "₹${String.format("%.0f", grandTotal)}",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        "TOTAL TO PAY",
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        "Dispatch Pro in 10 Mins",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (cart.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(BlinkitYellowLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔧", fontSize = 42.sp)
                    }
                    Text("No services selected", color = BlinkitTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Book expert plumbers, deep cleaning crews, electricians, or carpenters with 10-15 minute arrival.", color = BlinkitTextSecondary, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Explore Services", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 10-Min ETA Promise Header
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BlinkitYellow)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("⚡", fontSize = 24.sp)
                            Column {
                                Text(
                                    "Pro Technician arrives in 10 to 15 mins",
                                    color = BlinkitDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    "${cart.size} services booked • Background verified & equipped with full toolkit",
                                    color = BlinkitTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Selected Services List
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                "Selected Services (${cart.sumOf { it.quantity }})",
                                color = BlinkitTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            cart.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(BlinkitSurfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(item.service.emoji, fontSize = 24.sp)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            item.service.name,
                                            color = BlinkitTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                        Text(
                                            "⏱️ ${item.service.duration} • 🛡️ ${item.service.warranty}",
                                            color = BlinkitTextSecondary,
                                            fontSize = 11.sp
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                "₹${String.format("%.0f", item.service.price)}",
                                                color = BlinkitTextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            if (item.service.discountPercent > 0) {
                                                Text(
                                                    "₹${String.format("%.0f", item.service.originalPrice)}",
                                                    color = BlinkitTextMuted,
                                                    fontSize = 10.sp,
                                                    textDecoration = TextDecoration.LineThrough
                                                )
                                            }
                                        }
                                    }

                                    // Stepper
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(BlinkitGreen)
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            "−",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { repository.removeFromCart(item.service.id) }
                                        )
                                        Text(
                                            "${item.quantity}",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "+",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { repository.addToCart(item.service) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Diagnostic Video Attachment (CameraX + Local Storage + Firebase Storage)
                item {
                    DiagnosticVideoBookingCard(
                        currentVideo = pendingDiagnosticVideo,
                        serviceCategory = cart.firstOrNull()?.service?.categoryId?.replace("cat_", "")?.replaceFirstChar { it.uppercase() } ?: "Plumbing",
                        onVideoRecorded = { record ->
                            repository.setPendingDiagnosticVideo(record)
                        },
                        onRemoveVideo = {
                            repository.clearPendingDiagnosticVideo()
                        }
                    )
                }

                // Safety & Preparation Instructions
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "Technician Safety & Equipment Request",
                                color = BlinkitTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            val instructionsList = listOf(
                                "Wear shoe covers 👟",
                                "Bring pipe wrench 🔧",
                                "Bring ladder 🪜",
                                "Mask required 😷"
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                instructionsList.take(2).forEach { instruction ->
                                    val isSelected = selectedInstructions.contains(instruction)
                                    InstructionPill(
                                        text = instruction,
                                        isSelected = isSelected,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            if (isSelected) selectedInstructions.remove(instruction)
                                            else selectedInstructions.add(instruction)
                                        }
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                instructionsList.drop(2).forEach { instruction ->
                                    val isSelected = selectedInstructions.contains(instruction)
                                    InstructionPill(
                                        text = instruction,
                                        isSelected = isSelected,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            if (isSelected) selectedInstructions.remove(instruction)
                                            else selectedInstructions.add(instruction)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Technician Tip
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Tip your service technician", color = BlinkitTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("100% goes to pro", color = BlinkitGreenDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("Reward Ramesh for prompt 10-min arrival and quality craftsmanship.", color = BlinkitTextSecondary, fontSize = 11.sp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(0.0, 20.0, 30.0, 50.0, 100.0).forEach { tipVal ->
                                    val isSelected = selectedTip == tipVal
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                                            .border(
                                                1.dp,
                                                if (isSelected) BlinkitGreen else BlinkitBorder,
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable { selectedTip = tipVal }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            if (tipVal == 0.0) "No Tip" else "₹${tipVal.toInt()}",
                                            color = if (isSelected) BlinkitGreenDark else BlinkitTextPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 100% Video Proof Guarantee & Escrow Payment Protection
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(BlinkitGreenLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = BlinkitGreenDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "Payment Hold & Video Proof Protection",
                                        color = BlinkitGreenDark,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        "Zero-Risk Service Delivery Policy",
                                        color = BlinkitTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Text(
                                "• Technician must submit a 15-30s recorded video proof of operational test.\n• Review, download, or upload device proof if any issue arises.\n• Payment is released only after your approval or Admin review.",
                                color = Color(0xFF166534),
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Bill Details Breakdown Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Bill Details", color = BlinkitTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Services Total (Rate Card)", color = BlinkitTextSecondary, fontSize = 12.sp)
                                Text("₹${String.format("%.0f", mrpTotal)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }

                            if (totalSavings > 0) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Instant App Discount", color = BlinkitGreenDark, fontSize = 12.sp)
                                    Text("-₹${String.format("%.0f", totalSavings)}", color = BlinkitGreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("10-Min Visit & Diagnosis Fee", color = BlinkitTextSecondary, fontSize = 12.sp)
                                    if (visitFee == 0.0) {
                                        Text("(FREE on orders > ₹299)", color = BlinkitGreenDark, fontSize = 10.sp)
                                    }
                                }
                                Text(
                                    if (visitFee == 0.0) "FREE" else "₹${String.format("%.0f", visitFee)}",
                                    color = if (visitFee == 0.0) BlinkitGreenDark else BlinkitTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Safety Gear & 30-Day Warranty Cover", color = BlinkitTextSecondary, fontSize = 12.sp)
                                Text("₹${String.format("%.0f", safetyFee)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }

                            if (selectedTip > 0) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Technician Tip", color = BlinkitTextSecondary, fontSize = 12.sp)
                                    Text("₹${String.format("%.0f", selectedTip)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Divider(color = BlinkitBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Grand Total", color = BlinkitTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                                Text(
                                    "₹${String.format("%.0f", grandTotal)}",
                                    color = BlinkitTextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstructionPill(
    text: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) BlinkitYellowLight else BlinkitSurfaceVariant)
            .border(
                1.dp,
                if (isSelected) BlinkitYellowDark else BlinkitBorder,
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (isSelected) BlinkitDark else BlinkitTextPrimary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
