package com.example.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

/**
 * System notification helper for QuickIt Instant Services.
 * Configures high-priority notification channels and dispatches rich heads-up
 * notifications for real-time Firebase Cloud Messaging proximity alerts.
 */
object QuickItNotificationHelper {

    const val CHANNEL_PROXIMITY_ID = "quickit_technician_proximity"
    const val CHANNEL_STATUS_ID = "quickit_service_status"
    const val NOTIFICATION_ID_PROXIMITY = 8492
    const val NOTIFICATION_ID_STATUS = 8493

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            // 1. Proximity & Arrival Channel (High Priority Heads-Up)
            val proximityChannel = NotificationChannel(
                CHANNEL_PROXIMITY_ID,
                "⚡ Technician Proximity & Arrival",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent alerts when your technician is within 500m or arriving at your doorstep"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 150, 350)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                setShowBadge(true)
            }

            // 2. Service Status Channel
            val statusChannel = NotificationChannel(
                CHANNEL_STATUS_ID,
                "Service Status Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Updates on booking confirmation, dispatch, and completion"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(proximityChannel)
            notificationManager.createNotificationChannel(statusChannel)
        }
    }

    fun showProximityNotification(context: Context, alert: FcmProximityAlert) {
        createNotificationChannels(context)

        // Main Tap Intent -> Opens App Tracker
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_ORDER_ID", alert.orderId)
            putExtra("EXTRA_OPEN_TAB", "TRACKER")
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            alert.id.hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Call Technician Action
        val callIntent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${alert.technicianPhone}")
        }
        val callPendingIntent = PendingIntent.getActivity(
            context,
            (alert.id + "_call").hashCode(),
            callIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bigText = buildString {
            append("${alert.technicianName} is ${alert.distanceMeters}m away (ETA ~${alert.etaMinutes} mins).\n")
            append("🔑 Verification OTP: ${alert.otpCode}\n")
            append("Please keep the entrance clear and OTP ready.")
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_PROXIMITY_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🛵 ${alert.title}")
            .setContentText(alert.body)
            .setSubText("⚡ QuickIt 10-Min Service Proximity")
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_compass, "📍 Live Tracker", openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_call, "📞 Call ${alert.technicianName.split(" ").firstOrNull() ?: "Pro"}", callPendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(NOTIFICATION_ID_PROXIMITY, builder.build())
        } catch (e: SecurityException) {
            android.util.Log.w("QuickItNotification", "Notification permission missing: ${e.message}")
        } catch (e: Exception) {
            android.util.Log.e("QuickItNotification", "Failed to dispatch notification: ${e.message}")
        }
    }

    fun showServiceStatusNotification(context: Context, title: String, message: String, orderId: String? = null) {
        createNotificationChannels(context)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (orderId != null) putExtra("EXTRA_ORDER_ID", orderId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            (title + message).hashCode(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_STATUS_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(NOTIFICATION_ID_STATUS, builder.build())
        } catch (e: Exception) {
            android.util.Log.w("QuickItNotification", "Status notification: ${e.message}")
        }
    }
}
