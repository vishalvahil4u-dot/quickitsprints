package com.example.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PATCH
import retrofit2.http.Path

interface QuickItApi {
    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<ApiEnvelope<AuthDataDto>>

    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<ApiEnvelope<AuthDataDto>>

    @GET("api/auth/me")
    suspend fun me(): Response<ApiEnvelope<AuthUserDto>>

    @POST("api/bookings")
    suspend fun createBooking(@Body request: BookingCreateRequest): Response<ApiEnvelope<Any>>

    @GET("api/bookings/mine")
    suspend fun myBookings(): Response<ApiEnvelope<List<Any>>>

    @GET("api/bookings/{id}")
    suspend fun booking(@Path("id") id: Long): Response<ApiEnvelope<Any>>

    @PATCH("api/bookings/{id}/status")
    suspend fun updateBookingStatus(@Path("id") id: Long, @Body body: Map<String, String>): Response<ApiEnvelope<Any>>

    @POST("api/payments/initiate")
    suspend fun initiatePayment(@Body request: PaymentInitiateRequest): Response<ApiEnvelope<PaymentOrderDto>>

    @POST("api/payments/confirm")
    suspend fun confirmPayment(@Body request: PaymentConfirmRequest): Response<ApiEnvelope<Any>>
}
