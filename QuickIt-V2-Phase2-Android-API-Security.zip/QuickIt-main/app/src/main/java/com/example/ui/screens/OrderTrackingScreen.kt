package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    repository: BlinkitRepository,
    onBack: () -> Unit
) {
    val activeOrder by repository.activeOrder.collectAsState()
    val favoriteProviderIds by repository.favoriteProviderIds.collectAsState()
    val fcmToken by repository.fcmToken.collectAsState()
    val latestProximityAlert by repository.latestProximityAlert.collectAsState()
    val proximityAlertHistory by repository.proximityAlertHistory.collectAsState()

    var showWorkProofReviewDialog by remember { mutableStateOf(false) }
    var showCustomerDownloadDialog by remember { mutableStateOf(false) }
    var showCustomerUploadDialog by remember { mutableStateOf(false) }
    var showDiagnosticPreview by remember { mutableStateOf(false) }

    // Countdown simulation state (starts at 8m 12s)
    var secondsRemaining by remember { mutableStateOf(492) }

    LaunchedEffect(activeOrder?.status) {
        while (secondsRemaining > 0 && activeOrder?.status != OrderStatus.DELIVERED) {
            delay(1000L)
            secondsRemaining--
        }
    }

    val minutes = secondsRemaining / 60
    val seconds = secondsRemaining % 60
    val formattedTime = String.format("%02d:%02d", minutes, seconds)

    // Animated scooter position (0f to 1f)
    val infiniteTransition = rememberInfiniteTransition(label = "scooter")
    val animatedProgress by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scooterProgress"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Live Technician Tracker",
                            color = BlinkitTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            activeOrder?.orderNumber ?: "SRV-10M-8492",
                            color = BlinkitTextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, tint = BlinkitTextPrimary)
                    }
                },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(BlinkitGreenLight, RoundedCornerShape(50))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "⚡ 10-15M ARRIVAL",
                            color = BlinkitGreenDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BlinkitSurface)
            )
        }
    ) { innerPadding ->
        if (activeOrder == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentAlignment = Alignment.Center
            ) {
                Text("No active service booking found", color = BlinkitTextSecondary)
            }
        } else {
            val order = activeOrder!!

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Hero 10-Minute Countdown Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitDarkCard),
                        shape = RoundedCornerShape(22.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(BlinkitGreen)
                                    )
                                    Text(
                                        "LIVE PRO ARRIVAL",
                                        color = BlinkitYellow,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.sp
                                    )
                                }

                                // OTP Badge
                                Box(
                                    modifier = Modifier
                                        .background(BlinkitYellow, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        "START OTP: ${order.otpCode}",
                                        color = BlinkitDark,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            Column {
                                if (order.status == OrderStatus.DELIVERED) {
                                    Text(
                                        "Service Completed! 🎉",
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        "30-day warranty card activated on your account.",
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 13.sp
                                    )
                                } else if (order.status == OrderStatus.IN_SERVICE) {
                                    Text(
                                        "Service in Progress 🔧",
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        "Technician Ramesh is working on-site with safety gear.",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 13.sp
                                    )
                                } else {
                                    Text(
                                        "Arriving in $formattedTime mins",
                                        color = Color.White,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        order.status.description,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            // Interactive Timeline Progress Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                (0..4).forEach { step ->
                                    val isPassed = step <= order.status.stepIndex
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(5.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(if (isPassed) BlinkitYellow else Color.White.copy(alpha = 0.2f))
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Animated Live Map / Route View (Technician riding with toolbag from Hub to Home)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Live GPS Route (0.8 km)",
                                    color = BlinkitTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "EV Bike + Pro Toolbag",
                                    color = BlinkitGreenDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Canvas Map Visualizer
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(BlinkitSurfaceVariant)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val start = Offset(x = 60f, y = size.height * 0.7f)
                                    val mid = Offset(x = size.width * 0.45f, y = size.height * 0.25f)
                                    val end = Offset(x = size.width - 60f, y = size.height * 0.5f)

                                    // Road path
                                    drawLine(
                                        color = Color(0xFFD1D5DB),
                                        start = start,
                                        end = mid,
                                        strokeWidth = 8f,
                                        cap = StrokeCap.Round
                                    )
                                    drawLine(
                                        color = Color(0xFFD1D5DB),
                                        start = mid,
                                        end = end,
                                        strokeWidth = 8f,
                                        cap = StrokeCap.Round
                                    )

                                    // Dashed guideline
                                    drawLine(
                                        color = Color(0xFF9CA3AF),
                                        start = start,
                                        end = mid,
                                        strokeWidth = 2f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                    )
                                    drawLine(
                                        color = Color(0xFF9CA3AF),
                                        start = mid,
                                        end = end,
                                        strokeWidth = 2f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                    )

                                    // Hub Node
                                    drawCircle(color = Color(0xFF0C831F), radius = 16f, center = start)
                                    drawCircle(color = Color.White, radius = 6f, center = start)

                                    // Customer Home Node
                                    drawCircle(color = Color(0xFFE23744), radius = 16f, center = end)
                                    drawCircle(color = Color.White, radius = 6f, center = end)

                                    // Current Technician Position
                                    val techPos = if (animatedProgress < 0.5f) {
                                        val subProg = animatedProgress / 0.5f
                                        Offset(
                                            x = start.x + (mid.x - start.x) * subProg,
                                            y = start.y + (mid.y - start.y) * subProg
                                        )
                                    } else {
                                        val subProg = (animatedProgress - 0.5f) / 0.5f
                                        Offset(
                                            x = mid.x + (end.x - mid.x) * subProg,
                                            y = mid.y + (end.y - mid.y) * subProg
                                        )
                                    }

                                    drawCircle(color = Color(0xFFF8CB46), radius = 18f, center = techPos)
                                    drawCircle(color = Color(0xFF1C1C1C), radius = 8f, center = techPos)
                                }

                                // Overlay labels
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp)
                                        .align(Alignment.BottomCenter),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("🏭 Service Hub #14", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                    Text("🛵 Pro En Route", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                    Text("🏠 Customer Home", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                }
                            }
                        }
                    }
                }

                // 2.5 Live Google Maps Grounding Route & Dark Store Intel
                item {
                    LiveMapsGroundingTrackingCard(
                        order = order,
                        repository = repository
                    )
                }

                // 2.8 Mandatory On-Site Work Video Proof & Verification Card
                item {
                    WorkProofInlineCard(
                        order = order,
                        isTechnicianView = false,
                        onOpenProofAction = { showWorkProofReviewDialog = true },
                        onDownloadVideo = { showCustomerDownloadDialog = true },
                        onUploadDeviceVideo = { showCustomerUploadDialog = true }
                    )
                }

                // 3. Certified Technician Profile Card
                item {
                    val matchedProvider = repository.getProviderForRiderName(order.riderName)
                    val isFavorite = matchedProvider?.let { favoriteProviderIds.contains(it.id) } ?: false

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isFavorite) BlinkitYellowLight.copy(alpha = 0.25f) else BlinkitSurface
                        ),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(
                            if (isFavorite) 1.5.dp else 1.dp,
                            if (isFavorite) BlinkitYellowDark else BlinkitBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .background(BlinkitYellowLight)
                                        .border(2.dp, BlinkitYellowDark, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("👨🏽‍🔧", fontSize = 30.sp)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            order.riderName,
                                            color = BlinkitTextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isFavorite) {
                                            Text("⭐", fontSize = 12.sp)
                                        }
                                    }
                                    Text(
                                        order.technicianSpeciality,
                                        color = BlinkitTextSecondary,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        "★ ${order.riderRating} • ${order.riderVehicle}",
                                        color = BlinkitGreenDark,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Star, Call & Chat Buttons
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    matchedProvider?.let { prov ->
                                        IconButton(
                                            onClick = { repository.toggleFavoriteProvider(prov.id) },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(if (isFavorite) BlinkitYellowLight else BlinkitSurfaceVariant)
                                                .border(1.dp, if (isFavorite) BlinkitYellowDark else BlinkitBorder, CircleShape)
                                        ) {
                                            Icon(
                                                imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                                contentDescription = if (isFavorite) "Starred Favorite (Firestore Synced)" else "Star Favorite",
                                                tint = if (isFavorite) BlinkitYellowDark else BlinkitTextSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { /* Call */ },
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(BlinkitGreenLight)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = { /* Chat */ },
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(BlinkitSurfaceVariant)
                                    ) {
                                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = BlinkitTextPrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }

                            if (isFavorite) {
                                Surface(
                                    color = BlinkitYellowLight.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("⭐", fontSize = 10.sp)
                                        Text(
                                            "Favorite Provider • Saved to your account & synced across devices",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BlinkitDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. Quick Status Advance Controls (For demo/testing ease)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitYellowSoft),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, BlinkitYellow.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "⚡ Simulate On-Demand Service Stages",
                                color = BlinkitDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.PACKING) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitDark),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                                ) {
                                    Text("Prep Kit", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.OUT_FOR_DELIVERY) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                                ) {
                                    Text("En Route", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.IN_SERVICE) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitOrange),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                                ) {
                                    Text("In Service", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { repository.updateOrderStatus(order.id, OrderStatus.DELIVERED) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreenDark),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                                ) {
                                    Text("Completed", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // 4.5 Diagnostic Video for Assigned Technician (if recorded)
                if (order.diagnosticVideo != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, BlinkitGreen.copy(alpha = 0.6f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.Videocam, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(18.dp))
                                        Text(
                                            "Attached Diagnostic Video",
                                            color = BlinkitTextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = BlinkitGreenLight
                                    ) {
                                        Text(
                                            "SYNCED TO PRO",
                                            color = BlinkitGreenDark,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "Technician reviewed diagnostic video & pre-loaded spares from Hub #14 Indiranagar.",
                                    color = BlinkitTextSecondary,
                                    fontSize = 12.sp
                                )

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Text(
                                            text = "📁 Local: ${order.diagnosticVideo?.localFilePath?.substringAfterLast("/")}",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF475569)
                                        )
                                        Text(
                                            text = "☁️ Firebase: ${order.diagnosticVideo?.firebaseStorageRef}",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF0284C7)
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = { showDiagnosticPreview = true },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    border = BorderStroke(1.dp, BlinkitGreen)
                                ) {
                                    Icon(Icons.Default.PlayCircleOutline, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Watch Diagnostic Video", color = BlinkitGreenDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // 5. Booked Services Summary
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Booked Services & Rate Card", color = BlinkitTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                            order.items.forEach { cartItem ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(cartItem.service.emoji, fontSize = 18.sp)
                                        Text(
                                            "${cartItem.service.name} × ${cartItem.quantity}",
                                            color = BlinkitTextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Text(
                                        "₹${String.format("%.0f", cartItem.service.price * cartItem.quantity)}",
                                        color = BlinkitTextPrimary,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Divider(color = BlinkitBorder, modifier = Modifier.padding(vertical = 4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Paid", color = BlinkitTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    "₹${String.format("%.0f", order.grandTotal)}",
                                    color = BlinkitTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Client Work Proof Review & Approval Dialog
            if (showWorkProofReviewDialog) {
                ClientWorkProofReviewDialog(
                    order = order,
                    onApproveProof = { rating, _ ->
                        repository.approveWorkProofByClient(order.id, rating)
                    },
                    onRequestRevision = { reason ->
                        repository.requestWorkProofRevision(order.id, reason)
                    },
                    onDownloadVideo = {
                        repository.downloadProofVideoLocally(order.id)
                    },
                    onUploadLocalDeviceVideo = { path, reason, _ ->
                        repository.uploadCustomerLocalProofVideo(order.id, path, reason)
                    },
                    onEscalateToAdmin = { reason, cat, path ->
                        repository.escalateToAdminReview(order.id, reason, cat, path)
                    },
                    onDismiss = { showWorkProofReviewDialog = false }
                )
            }

            // Customer Direct Video Download Dialog
            if (showCustomerDownloadDialog) {
                CustomerVideoDownloadDialog(
                    order = order,
                    onDownloadConfirmed = {
                        repository.downloadProofVideoLocally(order.id)
                    },
                    onDismiss = { showCustomerDownloadDialog = false }
                )
            }

            // Customer Direct Video Upload Dialog
            if (showCustomerUploadDialog) {
                CustomerVideoUploadDialog(
                    order = order,
                    onUploadConfirmed = { path, reason, cat ->
                        repository.uploadCustomerLocalProofVideo(order.id, path, reason, cat)
                    },
                    onDismiss = { showCustomerUploadDialog = false }
                )
            }

            // Customer Diagnostic Video Preview Dialog
            if (showDiagnosticPreview && order.diagnosticVideo != null) {
                DiagnosticVideoPlayerDialog(
                    video = order.diagnosticVideo!!,
                    onDismiss = { showDiagnosticPreview = false }
                )
            }
        }
    }
}

@Composable
fun LiveMapsGroundingTrackingCard(
    order: OrderItem,
    repository: BlinkitRepository
) {
    val coroutineScope = rememberCoroutineScope()
    var isMapsQuerying by remember { mutableStateOf(false) }
    var mapsGroundingResult by remember { mutableStateOf<ChatMessage?>(null) }
    var isExpanded by remember { mutableStateOf(true) }

    // Fetch initial Maps Grounding for the current order address
    LaunchedEffect(order.id) {
        if (mapsGroundingResult == null) {
            isMapsQuerying = true
            val queryLocation = "${order.address.label}, ${order.address.addressLine}"
            val res = repository.queryMapsGrounding(queryLocation)
            mapsGroundingResult = res
            isMapsQuerying = false
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.5.dp, BlinkitGreen.copy(alpha = 0.8f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = BlinkitGreenLight,
                        shape = CircleShape,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.PinDrop,
                                contentDescription = "Maps Grounding",
                                tint = BlinkitGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Google Maps Grounding",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlinkitTextPrimary
                            )
                            Surface(
                                color = BlinkitYellow,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "gemini-3.5-flash",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitDark,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            "Live dark store hubs, tech depots & traffic data",
                            fontSize = 10.sp,
                            color = BlinkitTextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            isMapsQuerying = true
                            val queryLocation = "${order.address.label}, ${order.address.addressLine}"
                            val res = repository.queryMapsGrounding(queryLocation)
                            mapsGroundingResult = res
                            isMapsQuerying = false
                        }
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh Maps",
                        tint = BlinkitGreenDark,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Firestore Live Sync Badge
            Surface(
                color = BlinkitGreenLight.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(0.5.dp, BlinkitGreen.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.CloudDone,
                        contentDescription = "Firestore",
                        tint = BlinkitGreenDark,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        "Persisted to Firebase Firestore (ID: ${order.orderNumber})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitGreenDark
                    )
                }
            }

            if (isMapsQuerying) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = BlinkitGreen,
                        strokeWidth = 2.dp
                    )
                    Text(
                        "Connecting to Google Maps with gemini-3.5-flash...",
                        fontSize = 11.sp,
                        color = BlinkitTextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else mapsGroundingResult?.let { msg ->
                Text(
                    text = msg.text,
                    fontSize = 12.sp,
                    color = BlinkitTextPrimary,
                    lineHeight = 17.sp
                )

                if (msg.groundingSources.isNotEmpty()) {
                    Divider(color = BlinkitBorder, thickness = 0.5.dp)
                    Text(
                        "Verified Hubs & Spare Parts Depots via Google Maps:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlinkitTextSecondary
                    )
                    msg.groundingSources.forEach { source ->
                        Surface(
                            color = BlinkitYellowLight.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(0.5.dp, BlinkitYellow),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("📍", fontSize = 14.sp)
                                Column {
                                    Text(
                                        source.title,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BlinkitDark
                                    )
                                    source.snippet?.let {
                                        Text(it, fontSize = 10.sp, color = BlinkitTextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
