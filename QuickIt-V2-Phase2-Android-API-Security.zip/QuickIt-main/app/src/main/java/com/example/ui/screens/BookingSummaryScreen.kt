package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Dedicated Booking Summary & Pre-Dispatch Review Screen.
 * Allows users to thoroughly review selected services, assigned vicinity technician details,
 * real-time estimated arrival times, safety instructions, and payment breakdown before final confirmation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingSummaryScreen(
    repository: BlinkitRepository,
    onBack: () -> Unit,
    onOrderConfirmed: () -> Unit,
    onAddMoreServices: () -> Unit = onBack
) {
    val cart by repository.cart.collectAsState()
    val selectedAddress by repository.selectedAddress.collectAsState()
    val nearbyProviders by repository.nearbyProviders.collectAsState()
    val walletBalance by repository.walletBalance.collectAsState()
    val pendingDiagnosticVideo by repository.pendingDiagnosticVideo.collectAsState()

    val primaryCategory = remember(cart) {
        cart.firstOrNull()?.service?.categoryId ?: "cat_plumbing"
    }

    // Filter available nearby technicians for the relevant category
    val matchingProviders = remember(nearbyProviders, primaryCategory) {
        nearbyProviders.filter { it.categoryId == primaryCategory }
    }

    var selectedTechnician by remember(matchingProviders) {
        mutableStateOf(
            matchingProviders.firstOrNull { it.status == TechnicianStatus.AVAILABLE && it.isAvailableNow }
                ?: matchingProviders.firstOrNull()
                ?: nearbyProviders.firstOrNull { it.status == TechnicianStatus.AVAILABLE }
                ?: nearbyProviders.firstOrNull()
        )
    }

    var showTechSelectorDialog by remember { mutableStateOf(false) }
    var showPaymentGatewayDialog by remember { mutableStateOf(false) }
    var showPayAfterServiceDialog by remember { mutableStateOf(false) }
    var selectedTip by remember { mutableStateOf(30.0) }
    val selectedInstructions = remember {
        mutableStateListOf("Wear shoe covers 👟", "Bring pipe wrench 🔧", "Mask required 😷")
    }
    var customNotes by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("UPI (Google Pay)") }
    var selectedSlotType by remember { mutableStateOf("INSTANT") } // "INSTANT" vs "SCHEDULED"
    var isConfirmingBooking by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    // Financial calculations
    val itemTotal = cart.sumOf { it.service.price * it.quantity }
    val mrpTotal = cart.sumOf { it.service.originalPrice * it.quantity }
    val totalSavings = mrpTotal - itemTotal
    val visitFee = if (itemTotal >= 299.0) 0.0 else 49.0
    val safetyFee = 29.0
    val grandTotal = itemTotal + visitFee + safetyFee + selectedTip

    val fastestEta = selectedTechnician?.etaMinutes ?: 10

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Review Booking Summary",
                                color = BlinkitTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Box(
                                modifier = Modifier
                                    .background(BlinkitGreenLight, RoundedCornerShape(50))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "FINAL STEP",
                                    color = BlinkitGreenDark,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                        Text(
                            "QuickIt Hub #14 • Indiranagar Pro Center",
                            color = BlinkitTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("summary_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BlinkitTextPrimary)
                    }
                },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(BlinkitSurfaceVariant, RoundedCornerShape(50))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(12.dp))
                            Text("100% Guaranteed", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BlinkitSurface)
            )
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Trust Assurance row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                                Text("Free cancellation before pro arrives", color = BlinkitTextSecondary, fontSize = 11.sp)
                            }
                            Text(
                                "30-Day Free Rework",
                                color = BlinkitGreenDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Grand Total & Pay/Confirm Button triggering mock payment processing flow
                        Button(
                            onClick = {
                                if (!isConfirmingBooking) {
                                    if (selectedPaymentMethod.contains("After", ignoreCase = true)) {
                                        showPayAfterServiceDialog = true
                                    } else {
                                        showPaymentGatewayDialog = true
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("confirm_and_dispatch_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(vertical = 14.dp),
                            enabled = !isConfirmingBooking
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        "₹${String.format("%.0f", grandTotal)}",
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        if (selectedPaymentMethod.contains("After", ignoreCase = true))
                                            "${cart.sumOf { it.quantity }} ITEMS • PAY AFTER WORK"
                                        else
                                            "${cart.sumOf { it.quantity }} ITEMS • PAY VIA ${selectedPaymentMethod.take(14)}...",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (isConfirmingBooking) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Text(
                                            if (selectedPaymentMethod.contains("After", ignoreCase = true))
                                                "Confirm & Dispatch (⚡ ${fastestEta}m)"
                                            else
                                                "Pay ₹${String.format("%.0f", grandTotal)} (⚡ ${fastestEta}m)",
                                            color = Color.White,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                        Icon(
                                            Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (cart.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(BlinkitYellowLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🔧", fontSize = 38.sp)
                    }
                    Text(
                        "No services in review list",
                        color = BlinkitTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Please select plumber, electrician, cleaning, or appliance care services to review your booking summary.",
                        color = BlinkitTextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Browse Services", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(BlinkitBackground),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Estimated Arrival & SLA Dispatch Guarantee Hero Card
                item {
                    EstimatedArrivalSummaryCard(
                        etaMinutes = fastestEta,
                        selectedTechnician = selectedTechnician,
                        selectedAddress = selectedAddress
                    )
                }

                // 2. Assigned / Selected Technician Details Card
                item {
                    TechnicianSummaryCard(
                        technician = selectedTechnician,
                        onOpenSelector = { showTechSelectorDialog = true }
                    )
                }

                // 3. Selected Services Review Section
                item {
                    SelectedServicesSummaryCard(
                        cart = cart,
                        onAdd = { service -> repository.addToCart(service) },
                        onRemove = { serviceId -> repository.removeFromCart(serviceId) },
                        onAddMore = onAddMoreServices
                    )
                }

                // 3.5 Diagnostic Video for Assigned Pro (CameraX + Local Phone Storage + Firebase Storage)
                item {
                    DiagnosticVideoBookingCard(
                        currentVideo = pendingDiagnosticVideo,
                        serviceCategory = cart.firstOrNull()?.service?.categoryId?.replace("cat_", "")?.replaceFirstChar { it.uppercase() } ?: "Plumbing",
                        onVideoRecorded = { record ->
                            repository.setPendingDiagnosticVideo(record)
                        },
                        onRemoveVideo = {
                            repository.clearPendingDiagnosticVideo()
                        }
                    )
                }

                // 4. Service Address & Arrival Preference Card
                item {
                    DeliveryAddressSummaryCard(
                        address = selectedAddress,
                        selectedSlotType = selectedSlotType,
                        onSlotTypeChange = { selectedSlotType = it }
                    )
                }

                // 5. Special Instructions & Safety Checklist
                item {
                    InstructionsSummaryCard(
                        selectedInstructions = selectedInstructions,
                        customNotes = customNotes,
                        onNotesChange = { customNotes = it },
                        onInstructionToggle = { instruction ->
                            if (selectedInstructions.contains(instruction)) {
                                selectedInstructions.remove(instruction)
                            } else {
                                selectedInstructions.add(instruction)
                            }
                        }
                    )
                }

                // 6. Payment Method Selection Card
                item {
                    PaymentMethodSummaryCard(
                        selectedPaymentMethod = selectedPaymentMethod,
                        walletBalance = walletBalance,
                        onSelectMethod = { selectedPaymentMethod = it }
                    )
                }

                // 7. Transparent Bill & Price Breakdown Card
                item {
                    BillDetailsSummaryCard(
                        mrpTotal = mrpTotal,
                        itemTotal = itemTotal,
                        totalSavings = totalSavings,
                        visitFee = visitFee,
                        safetyFee = safetyFee,
                        selectedTip = selectedTip,
                        grandTotal = grandTotal,
                        onTipChange = { selectedTip = it }
                    )
                }

                // 8. Service Guarantee & Cancellation Policy Footer Card
                item {
                    GuaranteesFooterCard()
                }

                // Extra breathing space at bottom
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Modal dialog to swap/select available technicians in the vicinity
    if (showTechSelectorDialog) {
        TechnicianSelectionDialog(
            currentSelected = selectedTechnician,
            availableProviders = nearbyProviders,
            onSelect = {
                selectedTechnician = it
                showTechSelectorDialog = false
            },
            onDismiss = { showTechSelectorDialog = false }
        )
    }

    // Modal dialog for Secure Mock Payment Gateway Flow
    if (showPaymentGatewayDialog) {
        MockPaymentGatewayDialog(
            grandTotal = grandTotal,
            selectedPaymentMethod = selectedPaymentMethod,
            selectedTechnician = selectedTechnician,
            walletBalance = walletBalance,
            onPaymentSuccess = { finalPaymentMethod, txnId ->
                showPaymentGatewayDialog = false
                isConfirmingBooking = true
                val finalInstructions = selectedInstructions.toMutableList()
                if (customNotes.isNotBlank()) {
                    finalInstructions.add("Note: $customNotes")
                }
                repository.placeOrder(
                    tipAmount = selectedTip,
                    instructions = finalInstructions,
                    paymentMethod = finalPaymentMethod,
                    assignedTechnician = selectedTechnician,
                    etaMinutes = fastestEta,
                    paymentStatus = "PAID_ONLINE",
                    transactionId = txnId
                )
                isConfirmingBooking = false
                onOrderConfirmed()
            },
            onDismiss = { showPaymentGatewayDialog = false }
        )
    }

    // Modal dialog for Pay After Service Confirmation
    if (showPayAfterServiceDialog) {
        PayAfterServiceConfirmDialog(
            grandTotal = grandTotal,
            selectedTechnician = selectedTechnician,
            etaMinutes = fastestEta,
            onConfirm = {
                showPayAfterServiceDialog = false
                isConfirmingBooking = true
                val finalInstructions = selectedInstructions.toMutableList()
                if (customNotes.isNotBlank()) {
                    finalInstructions.add("Note: $customNotes")
                }
                repository.placeOrder(
                    tipAmount = selectedTip,
                    instructions = finalInstructions,
                    paymentMethod = "Pay After Service (Cash / UPI)",
                    assignedTechnician = selectedTechnician,
                    etaMinutes = fastestEta,
                    paymentStatus = "PAY_AFTER_SERVICE",
                    transactionId = "PAS-" + (100000..999999).random()
                )
                isConfirmingBooking = false
                onOrderConfirmed()
            },
            onDismiss = { showPayAfterServiceDialog = false }
        )
    }
}

/**
 * 1. Estimated Arrival Time & Route Dispatch SLA Hero Card.
 */
@Composable
private fun EstimatedArrivalSummaryCard(
    etaMinutes: Int,
    selectedTechnician: NearbyServiceProvider?,
    selectedAddress: DeliveryAddress
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_arrival_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.5.dp, BlinkitGreen.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Arrival ETA & Pulsing live badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(BlinkitGreenLight, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("⚡", fontSize = 20.sp)
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Arriving in $etaMinutes Mins",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitTextPrimary
                            )
                            PulsingLiveDot(color = BlinkitGreen, sizeDp = 6)
                        }
                        Text(
                            "Express Pro Dispatch SLA Guarantee",
                            fontSize = 11.sp,
                            color = BlinkitGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(BlinkitYellowLight, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        "10-Min Promise",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitDark
                    )
                }
            }

            Divider(color = BlinkitBorder)

            // Step route visualization
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlinkitSurfaceVariant, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Hub
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏢", fontSize = 18.sp)
                    Text("Hub #14", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                    Text("0.3 km", fontSize = 9.sp, color = BlinkitTextSecondary)
                }

                // Arrow 1
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(20.dp, 2.dp).background(BlinkitGreen))
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                }

                // Technician
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(selectedTechnician?.avatarEmoji ?: "🛵", fontSize = 18.sp)
                    Text(selectedTechnician?.name?.split(" ")?.firstOrNull() ?: "Technician", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                    Text("Ready", fontSize = 9.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                }

                // Arrow 2
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(20.dp, 2.dp).background(BlinkitGreen))
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                }

                // Destination
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏠", fontSize = 18.sp)
                    Text(selectedAddress.label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                    Text("Doorstep", fontSize = 9.sp, color = BlinkitTextSecondary)
                }
            }

            // OTP Handshake Note
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                Text(
                    "Secure 4-digit Handshake OTP will be generated upon confirmation for zero-fraud assurance.",
                    fontSize = 10.sp,
                    color = BlinkitTextSecondary
                )
            }
        }
    }
}

/**
 * 2. Assigned Technician Details Card.
 */
@Composable
private fun TechnicianSummaryCard(
    technician: NearbyServiceProvider?,
    onOpenSelector: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_technician_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title & Swap Pro CTA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Engineering, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                    Text(
                        "Assigned Stationed Pro",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BlinkitGreenLight)
                        .clickable { onOpenSelector() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            "Change Pro",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BlinkitGreenDark
                        )
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = BlinkitGreenDark, modifier = Modifier.size(12.dp))
                    }
                }
            }

            if (technician != null) {
                // Technician Profile Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(BlinkitSurfaceVariant)
                            .border(2.dp, BlinkitGreen, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(technician.avatarEmoji, fontSize = 28.sp)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                technician.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitTextPrimary
                            )
                            Box(
                                modifier = Modifier
                                    .background(BlinkitYellow, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    "★ ${technician.rating}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlinkitDark
                                )
                            }
                        }

                        Text(
                            technician.speciality,
                            fontSize = 11.sp,
                            color = BlinkitTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                "🛵 ${technician.vehicleNumber} (${technician.vehicleType})",
                                fontSize = 10.sp,
                                color = BlinkitTextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Stationed Landmark & Proximity Strip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlinkitSurfaceVariant, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(14.dp))
                            Text(
                                "${technician.distanceKm} km away • Near ${technician.currentVicinityLandmark}",
                                fontSize = 10.sp,
                                color = BlinkitTextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Text(
                            "⚡ ${technician.etaMinutes}m ETA",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitGreenDark
                        )
                    }
                }

                // Trust Badges: Background Verified & Sanitized Toolkits
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("✓ Police Background Verified", "✓ Sanitized Toolbag", "✓ 500+ Jobs").forEach { badge ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White, RoundedCornerShape(6.dp))
                                .border(1.dp, BlinkitBorder, RoundedCornerShape(6.dp))
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                badge,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitGreenDark,
                                maxLines = 1
                            )
                        }
                    }
                }
            } else {
                Text(
                    "Automatic allocation: The closest certified pro will be dispatched immediately from Hub #14.",
                    fontSize = 11.sp,
                    color = BlinkitTextSecondary
                )
            }
        }
    }
}

/**
 * 3. Selected Services Summary Review Card.
 */
@Composable
private fun SelectedServicesSummaryCard(
    cart: List<CartItem>,
    onAdd: (ServiceItem) -> Unit,
    onRemove: (String) -> Unit,
    onAddMore: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_services_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Handyman, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                    Text(
                        "Selected Offerings (${cart.sumOf { it.quantity }})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )
                }

                TextButton(
                    onClick = onAddMore,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("+ Add More", color = BlinkitGreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Services list with quantity steppers and task breakdown preview
            cart.forEachIndexed { index, item ->
                var isChecklistExpanded by remember { mutableStateOf(false) }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Emoji Container
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(BlinkitSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(item.service.emoji, fontSize = 24.sp)
                        }

                        // Details
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                item.service.name,
                                color = BlinkitTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    "⏱️ ${item.service.duration}",
                                    color = BlinkitTextSecondary,
                                    fontSize = 10.sp
                                )
                                Text("•", color = BlinkitTextMuted, fontSize = 10.sp)
                                Text(
                                    "🛡️ ${item.service.warranty}",
                                    color = BlinkitGreenDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    "₹${String.format("%.0f", item.service.price)}",
                                    color = BlinkitTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace
                                )
                                if (item.service.discountPercent > 0) {
                                    Text(
                                        "₹${String.format("%.0f", item.service.originalPrice)}",
                                        color = BlinkitTextMuted,
                                        fontSize = 10.sp,
                                        textDecoration = TextDecoration.LineThrough
                                    )
                                    Text(
                                        "${item.service.discountPercent}% OFF",
                                        color = BlinkitGreenDark,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Stepper (- 1 +)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BlinkitGreen)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "−",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onRemove(item.service.id) }
                                    .padding(horizontal = 2.dp)
                            )
                            Text(
                                "${item.quantity}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "+",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onAdd(item.service) }
                                    .padding(horizontal = 2.dp)
                            )
                        }
                    }

                    // Included Tasks Accordion Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isChecklistExpanded = !isChecklistExpanded }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "View ${item.service.includedTasks.size} Included Tasks & Toolkit",
                            fontSize = 10.sp,
                            color = BlinkitGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            if (isChecklistExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = BlinkitGreenDark,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    if (isChecklistExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BlinkitSurfaceVariant, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                "🧰 Required Equipment: ${item.service.toolkitRequired}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlinkitTextPrimary
                            )
                            item.service.includedTasks.forEach { task ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(12.dp))
                                    Text(task, fontSize = 10.sp, color = BlinkitTextSecondary)
                                }
                            }
                        }
                    }

                    if (index < cart.size - 1) {
                        Divider(color = BlinkitBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }
    }
}

/**
 * 4. Delivery Address & Time Slot Summary Card.
 */
@Composable
private fun DeliveryAddressSummaryCard(
    address: DeliveryAddress,
    selectedSlotType: String,
    onSlotTypeChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_address_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                    Text(
                        "Service Destination",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .background(BlinkitGreenLight, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        address.label.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitGreenDark
                    )
                }
            }

            // Address Details Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlinkitSurfaceVariant, RoundedCornerShape(10.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    address.addressLine,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BlinkitTextPrimary
                )
                Text(
                    "Landmark: ${address.landmark}",
                    fontSize = 11.sp,
                    color = BlinkitTextSecondary
                )
                Text(
                    "Contact: ${address.receiverName} (${address.phone})",
                    fontSize = 10.sp,
                    color = BlinkitTextSecondary
                )
            }

            // Slot Dispatch Choice
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Instant
                val isInstant = selectedSlotType == "INSTANT"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isInstant) BlinkitGreenLight else BlinkitSurfaceVariant)
                        .border(
                            1.dp,
                            if (isInstant) BlinkitGreen else BlinkitBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSlotTypeChange("INSTANT") }
                        .padding(8.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            PulsingLiveDot(color = BlinkitGreen, sizeDp = 5)
                            Text(
                                "⚡ Instant 10-Mins",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isInstant) BlinkitGreenDark else BlinkitTextPrimary
                            )
                        }
                        Text("Dispatches right away", fontSize = 9.sp, color = BlinkitTextSecondary)
                    }
                }

                // Scheduled
                val isScheduled = selectedSlotType == "SCHEDULED"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isScheduled) BlinkitGreenLight else BlinkitSurfaceVariant)
                        .border(
                            1.dp,
                            if (isScheduled) BlinkitGreen else BlinkitBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSlotTypeChange("SCHEDULED") }
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            "📅 Schedule Today",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isScheduled) BlinkitGreenDark else BlinkitTextPrimary
                        )
                        Text("Pick a slot later", fontSize = 9.sp, color = BlinkitTextSecondary)
                    }
                }
            }
        }
    }
}

/**
 * 5. Special Instructions & Safety Checklist Card.
 */
@Composable
private fun InstructionsSummaryCard(
    selectedInstructions: List<String>,
    customNotes: String,
    onNotesChange: (String) -> Unit,
    onInstructionToggle: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val instructionsList = listOf(
        "Wear shoe covers 👟",
        "Bring pipe wrench 🔧",
        "Mask required 😷",
        "Bring ladder 🪜",
        "Sanitize work area 🧼"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_instructions_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                Text(
                    "Technician Instructions & Safety Request",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BlinkitTextPrimary
                )
            }

            // Instructions Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                instructionsList.take(3).forEach { instruction ->
                    val isSelected = selectedInstructions.contains(instruction)
                    InstructionPill(
                        text = instruction,
                        isSelected = isSelected,
                        modifier = Modifier.weight(1f),
                        onClick = { onInstructionToggle(instruction) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                instructionsList.drop(3).forEach { instruction ->
                    val isSelected = selectedInstructions.contains(instruction)
                    InstructionPill(
                        text = instruction,
                        isSelected = isSelected,
                        modifier = Modifier.weight(1f),
                        onClick = { onInstructionToggle(instruction) }
                    )
                }
            }

            // Custom note input
            OutlinedTextField(
                value = customNotes,
                onValueChange = onNotesChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("technician_custom_notes_field"),
                placeholder = {
                    Text("Add specific instructions (e.g. gate code, pet info, power socket)", fontSize = 11.sp, color = BlinkitTextMuted)
                },
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, color = BlinkitTextPrimary),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = BlinkitBorder,
                    focusedBorderColor = BlinkitGreen,
                    unfocusedContainerColor = BlinkitSurfaceVariant,
                    focusedContainerColor = Color.White
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )
        }
    }
}

/**
 * 6. Payment Method Summary Selection Card.
 */
@Composable
private fun PaymentMethodSummaryCard(
    selectedPaymentMethod: String,
    walletBalance: Double,
    onSelectMethod: (String) -> Unit
) {
    val methods = listOf(
        Triple("UPI (Google Pay / PhonePe)", "⚡ Instant 1-tap UPI payment", "Google Pay, PhonePe, Paytm, BHIM"),
        Triple("Pay After Service (Cash / UPI)", "🛡️ Pay only after 100% satisfaction", "Zero advance required • Pay post inspection"),
        Triple("QuickIt Pro Wallet (₹${String.format("%.0f", walletBalance)})", "💼 Instant 10% cashback eligible", "Available balance: ₹${String.format("%.0f", walletBalance)}"),
        Triple("Credit / Debit Card / NetBanking", "💳 All major banks & cards supported", "Visa, Mastercard, RuPay, HDFC, ICICI, SBI")
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_payment_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(18.dp))
                    Text(
                        "Payment Mode",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitTextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .background(BlinkitGreenLight, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        "256-BIT SSL ENCRYPTED",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlinkitGreenDark
                    )
                }
            }

            methods.forEach { (method, subtitle, subdetail) ->
                val isSelected = selectedPaymentMethod.startsWith(method.take(10)) || selectedPaymentMethod == method
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                        .border(
                            1.dp,
                            if (isSelected) BlinkitGreen else BlinkitBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelectMethod(method) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                method,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                color = if (isSelected) BlinkitGreenDark else BlinkitTextPrimary
                            )
                            if (method.contains("Wallet")) {
                                Box(
                                    modifier = Modifier
                                        .background(BlinkitYellowLight, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("+10% Cashback", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = BlinkitDark)
                                }
                            }
                        }
                        Text(
                            subtitle,
                            fontSize = 10.sp,
                            color = BlinkitTextSecondary
                        )
                        Text(
                            subdetail,
                            fontSize = 9.sp,
                            color = BlinkitTextMuted
                        )
                    }

                    RadioButton(
                        selected = isSelected,
                        onClick = { onSelectMethod(method) },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = BlinkitGreen,
                            unselectedColor = BlinkitTextSecondary
                        )
                    )
                }
            }

            // Trust note
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlinkitSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(12.dp))
                Text(
                    "Payments processed securely via simulated RBI-tokenized banking switch with zero-fraud protection.",
                    fontSize = 9.sp,
                    color = BlinkitTextSecondary
                )
            }
        }
    }
}

/**
 * 7. Transparent Bill & Price Breakdown Card.
 */
@Composable
private fun BillDetailsSummaryCard(
    mrpTotal: Double,
    itemTotal: Double,
    totalSavings: Double,
    visitFee: Double,
    safetyFee: Double,
    selectedTip: Double,
    grandTotal: Double,
    onTipChange: (Double) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("summary_bill_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
        border = BorderStroke(1.dp, BlinkitBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Bill & Savings Breakdown",
                color = BlinkitTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold
            )

            // Rate Card Total
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Services Rate Card Total", color = BlinkitTextSecondary, fontSize = 12.sp)
                Text("₹${String.format("%.0f", mrpTotal)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }

            // Savings
            if (totalSavings > 0) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Instant Pro Discount", color = BlinkitGreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("-₹${String.format("%.0f", totalSavings)}", color = BlinkitGreenDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            // 10-Min Visit & Diagnosis Fee
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("10-Min Pro Dispatch & Diagnosis", color = BlinkitTextSecondary, fontSize = 12.sp)
                    if (visitFee == 0.0) {
                        Text("(FREE on orders > ₹299)", color = BlinkitGreenDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    if (visitFee == 0.0) "FREE" else "₹${String.format("%.0f", visitFee)}",
                    color = if (visitFee == 0.0) BlinkitGreenDark else BlinkitTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Safety Gear & Warranty
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Sanitized Gear & 30-Day Warranty Cover", color = BlinkitTextSecondary, fontSize = 12.sp)
                Text("₹${String.format("%.0f", safetyFee)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }

            // Tip Selector Row
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Technician Tip (100% to Pro)", color = BlinkitTextSecondary, fontSize = 12.sp)
                    if (selectedTip > 0) {
                        Text("₹${String.format("%.0f", selectedTip)}", color = BlinkitTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0.0, 20.0, 30.0, 50.0, 100.0).forEach { tipVal ->
                        val isSelected = selectedTip == tipVal
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                                .border(
                                    1.dp,
                                    if (isSelected) BlinkitGreen else BlinkitBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { onTipChange(tipVal) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (tipVal == 0.0) "No Tip" else "₹${tipVal.toInt()}",
                                color = if (isSelected) BlinkitGreenDark else BlinkitTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Divider(color = BlinkitBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

            // Grand Total
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Grand Total to Pay", color = BlinkitTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text("Inclusive of all taxes & warranty", color = BlinkitTextSecondary, fontSize = 10.sp)
                }
                Text(
                    "₹${String.format("%.0f", grandTotal)}",
                    color = BlinkitTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/**
 * 8. Guarantees & Cancellation Policy Footer Card.
 */
@Composable
private fun GuaranteesFooterCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant.copy(alpha = 0.6f)),
        border = BorderStroke(1.dp, BlinkitBorder.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                Text("QuickIt 10-Minute Service Guarantees", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
            }
            Text("• Free cancellation: Cancel with 1 tap anytime before pro reaches your building.", fontSize = 10.sp, color = BlinkitTextSecondary)
            Text("• 30-Day Free Rework: If any repaired component fails within 30 days, we fix it at zero extra charge.", fontSize = 10.sp, color = BlinkitTextSecondary)
            Text("• Standard transparent rate card with no on-spot surprise charges.", fontSize = 10.sp, color = BlinkitTextSecondary)
        }
    }
}

/**
 * Modal dialog allowing the customer to inspect and select other technicians available in their vicinity.
 */
@Composable
private fun TechnicianSelectionDialog(
    currentSelected: NearbyServiceProvider?,
    availableProviders: List<NearbyServiceProvider>,
    onSelect: (NearbyServiceProvider) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Select Stationed Pro",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BlinkitTextPrimary
                        )
                        Text(
                            "${availableProviders.size} Pros in Indiranagar Vicinity",
                            fontSize = 11.sp,
                            color = BlinkitGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                Divider(color = BlinkitBorder)

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(availableProviders) { tech ->
                        val isSelected = currentSelected?.id == tech.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(tech) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) BlinkitGreenLight else BlinkitSurfaceVariant
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) BlinkitGreen else BlinkitBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color.White, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(tech.avatarEmoji, fontSize = 20.sp)
                                    }
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                tech.name,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = BlinkitTextPrimary
                                            )
                                            Text(
                                                "★ ${tech.rating}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = BlinkitYellowDark
                                            )
                                        }
                                        Text(
                                            "${tech.speciality} • ${tech.vehicleType}",
                                            fontSize = 10.sp,
                                            color = BlinkitTextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "📍 ${tech.distanceKm} km (${tech.currentVicinityLandmark})",
                                            fontSize = 10.sp,
                                            color = BlinkitTextPrimary
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        "⚡ ${tech.etaMinutes}m ETA",
                                        color = BlinkitGreenDark,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    if (isSelected) {
                                        Text(
                                            "SELECTED",
                                            color = BlinkitGreen,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Stages for the Mock Payment Processing Gateway State Machine.
 */
private enum class MockPaymentStage {
    INPUT,
    PROCESSING,
    SUCCESS,
    FAILED
}

/**
 * Secure Mock Payment Processing Gateway Dialog.
 * Provides a realistic, bank-grade simulated checkout flow supporting
 * UPI 1-tap/PIN, Saved Cards with 3D-Secure SMS OTP, QuickIt Pro Wallet, and NetBanking.
 */
@Composable
private fun MockPaymentGatewayDialog(
    grandTotal: Double,
    selectedPaymentMethod: String,
    selectedTechnician: NearbyServiceProvider?,
    walletBalance: Double,
    onPaymentSuccess: (paymentMethod: String, transactionId: String) -> Unit,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    // Determine initial payment mode from parent selection
    var currentMode by remember {
        mutableStateOf(
            when {
                selectedPaymentMethod.contains("Wallet", ignoreCase = true) -> "WALLET"
                selectedPaymentMethod.contains("Card", ignoreCase = true) -> "CARDS"
                selectedPaymentMethod.contains("NetBanking", ignoreCase = true) -> "NETBANKING"
                else -> "UPI"
            }
        )
    }

    var paymentStage by remember { mutableStateOf(MockPaymentStage.INPUT) }
    var processingStepIndex by remember { mutableStateOf(0) }
    var simulateFailure by remember { mutableStateOf(false) }

    // UPI state
    var selectedUpiApp by remember { mutableStateOf("Google Pay") }
    var customUpiId by remember { mutableStateOf("vishal@okaxis") }
    var upiPin by remember { mutableStateOf("") }

    // Card state
    var selectedCardType by remember { mutableStateOf("HDFC Bank Regalia •••• 4242") }
    var cardCvv by remember { mutableStateOf("821") }
    var cardOtp by remember { mutableStateOf("") }
    var showOtpStep by remember { mutableStateOf(false) }

    // NetBanking state
    var selectedBank by remember { mutableStateOf("HDFC Bank") }

    // Transaction metadata
    val txnId = remember { "TXN-QKT-" + (100000..999999).random() }
    val bankRrn = remember { "RRN-" + (1000000000L..9999999999L).random() }

    val processingSteps = listOf(
        "Connecting to 256-Bit Bank Gateway...",
        "NPCI / Card Network Handshake...",
        "Zero-Fraud Risk Check Passed (100%)...",
        "Authorizing ₹${String.format("%.0f", grandTotal)} to QuickIt Services..."
    )

    fun startPaymentExecution(chosenMethodName: String) {
        paymentStage = MockPaymentStage.PROCESSING
        processingStepIndex = 0

        coroutineScope.launch {
            for (step in 0 until processingSteps.size) {
                processingStepIndex = step
                delay(400)
            }
            delay(300)

            if (simulateFailure) {
                paymentStage = MockPaymentStage.FAILED
            } else {
                paymentStage = MockPaymentStage.SUCCESS
                // Auto-confirm after celebratory feedback
                delay(1400)
                onPaymentSuccess(chosenMethodName, txnId)
            }
        }
    }

    Dialog(
        onDismissRequest = {
            if (paymentStage != MockPaymentStage.PROCESSING) {
                onDismiss()
            }
        },
        properties = DialogProperties(dismissOnBackPress = paymentStage != MockPaymentStage.PROCESSING, dismissOnClickOutside = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("mock_payment_gateway_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header: 256-Bit Bank Encryption Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(BlinkitGreenLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = BlinkitGreenDark,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Column {
                            Text(
                                "QuickIt Secure Pay",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitTextPrimary
                            )
                            Text(
                                "256-Bit SSL • RBI Tokenized",
                                fontSize = 10.sp,
                                color = BlinkitGreenDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (paymentStage != MockPaymentStage.PROCESSING) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                        }
                    }
                }

                // Amount & Beneficiary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Amount to Authorize", fontSize = 10.sp, color = BlinkitTextSecondary)
                            Text(
                                "₹${String.format("%.0f", grandTotal)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitGreenDark,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Merchant", fontSize = 10.sp, color = BlinkitTextSecondary)
                            Text("QuickIt Services Pvt Ltd", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                        }
                    }
                }

                Divider(color = BlinkitBorder)

                // Body content based on stage
                when (paymentStage) {
                    MockPaymentStage.INPUT -> {
                        // Mode selection tabs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BlinkitSurfaceVariant, RoundedCornerShape(10.dp))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            listOf(
                                "UPI" to "⚡ UPI",
                                "CARDS" to "💳 Card",
                                "WALLET" to "💼 Wallet",
                                "NETBANKING" to "🏛️ NetBank"
                            ).forEach { (modeKey, label) ->
                                val isTabSelected = currentMode == modeKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isTabSelected) Color.White else Color.Transparent)
                                        .clickable {
                                            currentMode = modeKey
                                            showOtpStep = false
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isTabSelected) FontWeight.Black else FontWeight.Medium,
                                        color = if (isTabSelected) BlinkitTextPrimary else BlinkitTextSecondary
                                    )
                                }
                            }
                        }

                        // Tab specific content
                        when (currentMode) {
                            "UPI" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Select UPI App", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("Google Pay" to "🟢 GPay", "PhonePe" to "🟣 PhonePe", "Paytm" to "🔵 Paytm", "BHIM" to "🟠 BHIM").forEach { (app, label) ->
                                            val isAppSelected = selectedUpiApp == app
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isAppSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                                                    .border(1.dp, if (isAppSelected) BlinkitGreen else BlinkitBorder, RoundedCornerShape(8.dp))
                                                    .clickable { selectedUpiApp = app }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    label,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (isAppSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isAppSelected) BlinkitGreenDark else BlinkitTextPrimary
                                                )
                                            }
                                        }
                                    }

                                    // UPI ID field
                                    OutlinedTextField(
                                        value = customUpiId,
                                        onValueChange = { customUpiId = it },
                                        label = { Text("UPI ID / VPA", fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        trailingIcon = {
                                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                                        }
                                    )

                                    // UPI PIN Simulation
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        OutlinedTextField(
                                            value = upiPin,
                                            onValueChange = { if (it.length <= 4) upiPin = it },
                                            label = { Text("4-Digit UPI PIN", fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true,
                                            visualTransformation = PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                                        )

                                        Spacer(modifier = Modifier.width(8.dp))

                                        OutlinedButton(
                                            onClick = { upiPin = "1234" },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                        ) {
                                            Text("⚡ Auto PIN (1234)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            "CARDS" -> {
                                if (!showOtpStep) {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Saved Cards", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)

                                        listOf(
                                            "HDFC Bank Regalia •••• 4242" to "Visa • Expires 08/29",
                                            "ICICI Bank Coral •••• 8819" to "Mastercard • Expires 11/27"
                                        ).forEach { (cardName, subtitle) ->
                                            val isCardSelected = selectedCardType == cardName
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isCardSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                                                    .border(1.dp, if (isCardSelected) BlinkitGreen else BlinkitBorder, RoundedCornerShape(8.dp))
                                                .clickable { selectedCardType = cardName }
                                                .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column {
                                                    Text(cardName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)
                                                    Text(subtitle, fontSize = 10.sp, color = BlinkitTextSecondary)
                                                }
                                                RadioButton(
                                                    selected = isCardSelected,
                                                    onClick = { selectedCardType = cardName },
                                                    colors = RadioButtonDefaults.colors(selectedColor = BlinkitGreen)
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            OutlinedTextField(
                                                value = cardCvv,
                                                onValueChange = { if (it.length <= 3) cardCvv = it },
                                                label = { Text("CVV", fontSize = 11.sp) },
                                                modifier = Modifier.width(100.dp),
                                                singleLine = true,
                                                visualTransformation = PasswordVisualTransformation(),
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                                            )
                                            Text(
                                                "🔒 3D-Secure 2.0 Auth Ready",
                                                fontSize = 10.sp,
                                                color = BlinkitGreenDark,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                } else {
                                    // 3D-Secure SMS OTP Simulation Screen
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Bank 3D-Secure SMS OTP", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = BlinkitTextPrimary)
                                        Text("OTP sent to mobile linked with ${selectedCardType.take(15)}...", fontSize = 10.sp, color = BlinkitTextSecondary)

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            OutlinedTextField(
                                                value = cardOtp,
                                                onValueChange = { if (it.length <= 6) cardOtp = it },
                                                label = { Text("6-Digit OTP", fontSize = 11.sp) },
                                                modifier = Modifier.weight(1f),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            OutlinedButton(
                                                onClick = { cardOtp = "629140" },
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                            ) {
                                                Text("⚡ Auto OTP (629140)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            "WALLET" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = BlinkitYellowLight)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text("💼", fontSize = 24.sp)
                                            Column {
                                                Text("QuickIt Pro Wallet Balance", fontSize = 11.sp, color = BlinkitDark, fontWeight = FontWeight.Bold)
                                                Text("₹${String.format("%.0f", walletBalance)} Available", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = BlinkitDark)
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.Celebration, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                                        Text("You will earn ₹${String.format("%.0f", grandTotal * 0.10)} Cashback on this booking!", fontSize = 10.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            "NETBANKING" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Popular NetBanking Banks", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BlinkitTextPrimary)

                                    listOf("HDFC Bank", "State Bank of India", "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank").forEach { bank ->
                                        val isBankSelected = selectedBank == bank
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isBankSelected) BlinkitGreenLight else BlinkitSurfaceVariant)
                                                .border(1.dp, if (isBankSelected) BlinkitGreen else BlinkitBorder, RoundedCornerShape(8.dp))
                                                .clickable { selectedBank = bank }
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(bank, fontSize = 12.sp, fontWeight = if (isBankSelected) FontWeight.Bold else FontWeight.Medium, color = BlinkitTextPrimary)
                                            RadioButton(
                                                selected = isBankSelected,
                                                onClick = { selectedBank = bank },
                                                colors = RadioButtonDefaults.colors(selectedColor = BlinkitGreen)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Simulation failure toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(BlinkitSurfaceVariant)
                                .clickable { simulateFailure = !simulateFailure }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("🧪 Test Mode: Simulate Bank Timeout / Decline", fontSize = 10.sp, color = BlinkitTextSecondary)
                            Switch(
                                checked = simulateFailure,
                                onCheckedChange = { simulateFailure = it },
                                modifier = Modifier.scale(0.7f)
                            )
                        }

                        // Primary Pay CTA Button
                        Button(
                            onClick = {
                                if (currentMode == "CARDS" && !showOtpStep) {
                                    showOtpStep = true
                                } else {
                                    val finalMethodName = when (currentMode) {
                                        "UPI" -> "UPI ($selectedUpiApp)"
                                        "CARDS" -> "Card ($selectedCardType)"
                                        "WALLET" -> "QuickIt Wallet"
                                        "NETBANKING" -> "NetBanking ($selectedBank)"
                                        else -> "Online Payment"
                                    }
                                    startPaymentExecution(finalMethodName)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("authorize_payment_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text(
                                    if (currentMode == "CARDS" && !showOtpStep) "Continue to 3D-Secure OTP"
                                    else "Authorize & Pay ₹${String.format("%.0f", grandTotal)}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    MockPaymentStage.PROCESSING -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(54.dp),
                                color = BlinkitGreen,
                                strokeWidth = 4.dp
                            )

                            Text(
                                "Securing Payment...",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitTextPrimary
                            )

                            Text(
                                processingSteps.getOrElse(processingStepIndex) { processingSteps.last() },
                                fontSize = 12.sp,
                                color = BlinkitGreenDark,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                "Please do not press back or close the app",
                                fontSize = 10.sp,
                                color = BlinkitTextMuted
                            )
                        }
                    }

                    MockPaymentStage.SUCCESS -> {
                        val scale = remember { Animatable(0.5f) }
                        LaunchedEffect(Unit) {
                            scale.animateTo(
                                targetValue = 1f,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .scale(scale.value)
                                    .background(BlinkitGreen, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Success",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            Text(
                                "Payment Authorized Successfully!",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitGreenDark
                            )

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BlinkitGreenLight)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("Txn Ref: $txnId", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                                    Text("Bank RRN: $bankRrn", fontSize = 10.sp, color = BlinkitTextPrimary)
                                    Text("Paid: ₹${String.format("%.0f", grandTotal)} • 100% Guaranteed", fontSize = 10.sp, color = BlinkitTextPrimary)
                                }
                            }

                            if (selectedTechnician != null) {
                                Text(
                                    "⚡ Dispatching ${selectedTechnician.name} (${selectedTechnician.etaMinutes}m ETA)...",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitTextPrimary
                                )
                            }

                            Button(
                                onClick = {
                                    val finalMethodName = when (currentMode) {
                                        "UPI" -> "UPI ($selectedUpiApp)"
                                        "CARDS" -> "Card ($selectedCardType)"
                                        "WALLET" -> "QuickIt Wallet"
                                        "NETBANKING" -> "NetBanking ($selectedBank)"
                                        else -> "Online Payment"
                                    }
                                    onPaymentSuccess(finalMethodName, txnId)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Proceed to Live Tracking", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    MockPaymentStage.FAILED -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(BlinkitRed.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline,
                                    contentDescription = "Failed",
                                    tint = BlinkitRed,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Text(
                                "Payment Declined by Bank Switch",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = BlinkitRed
                            )

                            Text(
                                "Bank server connection timed out or simulated transaction limit reached. No money was deducted.",
                                fontSize = 11.sp,
                                color = BlinkitTextSecondary,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        simulateFailure = false
                                        paymentStage = MockPaymentStage.INPUT
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Change Mode", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        simulateFailure = false
                                        val finalMethodName = when (currentMode) {
                                            "UPI" -> "UPI ($selectedUpiApp)"
                                            "CARDS" -> "Card ($selectedCardType)"
                                            "WALLET" -> "QuickIt Wallet"
                                            "NETBANKING" -> "NetBanking ($selectedBank)"
                                            else -> "Online Payment"
                                        }
                                        startPaymentExecution(finalMethodName)
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Retry 1-Tap", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Confirmation dialog for the "Pay After Service (Cash / UPI)" option.
 * Reassures customers of zero advance payment and transparent on-site inspection.
 */
@Composable
private fun PayAfterServiceConfirmDialog(
    grandTotal: Double,
    selectedTechnician: NearbyServiceProvider?,
    etaMinutes: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("pay_after_service_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🛡️", fontSize = 24.sp)
                        Column {
                            Text("Pay After Service", fontSize = 16.sp, fontWeight = FontWeight.Black, color = BlinkitTextPrimary)
                            Text("100% Risk-Free Guarantee", fontSize = 10.sp, color = BlinkitGreenDark, fontWeight = FontWeight.Bold)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = BlinkitTextSecondary)
                    }
                }

                Divider(color = BlinkitBorder)

                // Assurance list
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                        Text("Zero Advance Payment: Pay ₹0 right now.", fontSize = 11.sp, color = BlinkitTextPrimary, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                        Text("Inspect & Test: Pay Cash, UPI, or Card machine only after full satisfaction.", fontSize = 11.sp, color = BlinkitTextPrimary)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(16.dp))
                        Text("30-Day Free Rework Guarantee issued on-site.", fontSize = 11.sp, color = BlinkitTextPrimary)
                    }
                }

                // Amount breakdown
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Payable Post-Service", fontSize = 10.sp, color = BlinkitTextSecondary)
                            Text("₹${String.format("%.0f", grandTotal)}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = BlinkitTextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        if (selectedTechnician != null) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Pro Assigned", fontSize = 10.sp, color = BlinkitTextSecondary)
                                Text("${selectedTechnician.name} (⚡ ${etaMinutes}m)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BlinkitGreenDark)
                            }
                        }
                    }
                }

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onConfirm,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("confirm_pay_after_service_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Confirm & Dispatch (⚡ ${etaMinutes}m)", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                }
            }
        }
    }
}

