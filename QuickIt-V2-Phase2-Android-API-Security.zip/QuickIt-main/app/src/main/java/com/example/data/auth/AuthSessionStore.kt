package com.example.data.auth

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.authDataStore by preferencesDataStore(name = "quickit_auth")

/** Stores only short-lived auth state. Never store passwords or payment secrets. */
class AuthSessionStore(private val context: Context) {
    private object Keys {
        val token = stringPreferencesKey("access_token")
        val userId = stringPreferencesKey("user_id")
        val role = stringPreferencesKey("role")
    }

    val token: Flow<String?> = context.authDataStore.data.map { it[Keys.token] }
    val userId: Flow<String?> = context.authDataStore.data.map { it[Keys.userId] }
    val role: Flow<String?> = context.authDataStore.data.map { it[Keys.role] }

    suspend fun save(token: String, userId: String?, role: String?) {
        context.authDataStore.edit { prefs ->
            prefs[Keys.token] = token
            if (userId == null) prefs.remove(Keys.userId) else prefs[Keys.userId] = userId
            if (role == null) prefs.remove(Keys.role) else prefs[Keys.role] = role
        }
    }

    suspend fun clear() {
        context.authDataStore.edit { it.clear() }
    }
}
