package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiderDeliveryScreen(
    repository: BlinkitRepository
) {
    val activeTechnicianSession by repository.activeTechnicianSession.collectAsState()
    val activeOrder by repository.activeOrder.collectAsState()
    val pastOrders by repository.pastOrders.collectAsState()

    var showOtpDialog by remember { mutableStateOf(false) }
    var enteredOtp by remember { mutableStateOf("") }
    var otpError by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showRecordProofDialog by remember { mutableStateOf(false) }
    var showDutyLockedDialog by remember { mutableStateOf(false) }
    var showLogoutLockedDialog by remember { mutableStateOf(false) }

    val hasActiveAssignedJob = activeOrder != null &&
        (activeOrder?.status == OrderStatus.IN_SERVICE ||
         activeOrder?.status == OrderStatus.OUT_FOR_DELIVERY ||
         activeOrder?.status == OrderStatus.PLACED ||
         activeOrder?.status == OrderStatus.PACKING)

    val isWorkVideoSavedToPhone = activeOrder?.workProof?.isSavedToPhoneStorage == true &&
        (activeOrder?.workProof?.status == WorkProofStatus.SUBMITTED ||
         activeOrder?.workProof?.status == WorkProofStatus.APPROVED_BY_CLIENT)

    val isDutyLockedDueToVideo = hasActiveAssignedJob && !isWorkVideoSavedToPhone
    val isSwitchLogoutLockedDueToVideo = hasActiveAssignedJob && !isWorkVideoSavedToPhone

    // If technician is not logged in via Mobile OTP, display the OTP Login Screen
    if (activeTechnicianSession == null) {
        TechnicianOtpLoginScreen(
            repository = repository,
            onLoginSuccess = { /* Automatically logged in via repository */ }
        )
        return
    }

    val tech = activeTechnicianSession!!

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(BlinkitYellowLight)
                                .border(1.5.dp, BlinkitYellowDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(tech.avatarEmoji, fontSize = 20.sp)
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    tech.name,
                                    color = BlinkitTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text("★ ${tech.rating}", color = BlinkitGreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                "${tech.speciality} • ${tech.vehicleNumber}",
                                color = BlinkitTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    // Interactive Duty Switch Pill (Locked if active job has un-saved work proof video)
                    Surface(
                        color = when {
                            isDutyLockedDueToVideo -> Color(0xFFFEF3C7)
                            tech.isDutyOn -> BlinkitGreenLight
                            else -> BlinkitSurfaceVariant
                        },
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            when {
                                isDutyLockedDueToVideo -> Color(0xFFF59E0B)
                                tech.isDutyOn -> BlinkitGreen
                                else -> BlinkitBorder
                            }
                        ),
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .testTag("rider_duty_toggle_btn")
                            .clickable {
                                if (isDutyLockedDueToVideo) {
                                    showDutyLockedDialog = true
                                } else {
                                    repository.setTechnicianDuty(!tech.isDutyOn)
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isDutyLockedDueToVideo) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "Duty Locked",
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(11.dp)
                                )
                                Text(
                                    "DUTY: LOCKED",
                                    color = Color(0xFFB45309),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(if (tech.isDutyOn) BlinkitGreen else BlinkitTextMuted)
                                )
                                Text(
                                    if (tech.isDutyOn) "DUTY: ON" else "DUTY: OFF",
                                    color = if (tech.isDutyOn) BlinkitGreenDark else BlinkitTextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Logout / Switch Partner Icon (Locked if active job has un-saved / un-submitted video proof)
                    Surface(
                        color = if (isSwitchLogoutLockedDueToVideo) Color(0xFFFEF3C7) else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        border = if (isSwitchLogoutLockedDueToVideo) BorderStroke(1.dp, Color(0xFFF59E0B)) else null
                    ) {
                        IconButton(
                            onClick = {
                                if (isSwitchLogoutLockedDueToVideo) {
                                    showLogoutLockedDialog = true
                                } else {
                                    showLogoutConfirm = true
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("rider_logout_partner_btn")
                        ) {
                            if (isSwitchLogoutLockedDueToVideo) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "Switch / Logout Partner Disabled",
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                            } else {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = "Logout Partner",
                                    tint = BlinkitTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BlinkitSurface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BlinkitBackground),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Technician Daily Earnings Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BlinkitDarkCard),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("TODAY'S SERVICE EARNINGS", color = BlinkitYellow, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                                Text("₹${tech.todayEarnings}", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                            }

                            Box(
                                modifier = Modifier
                                    .background(BlinkitGreen, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("${tech.hubName}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RiderStatPill(title = "JOBS", value = "${tech.todayJobs} Done", modifier = Modifier.weight(1f))
                            RiderStatPill(title = "TIPS", value = "₹340", modifier = Modifier.weight(1f))
                            RiderStatPill(title = "10M BONUS", value = "₹500", modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Issued Toolkits Status Bar
            if (tech.primaryToolkits.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("🧰", fontSize = 14.sp)
                                Text(
                                    "Issued Calibrated Toolkits (Checked at Hub):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlinkitTextPrimary
                                )
                            }
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(tech.primaryToolkits) { kit ->
                                    Surface(
                                        color = BlinkitSurfaceVariant,
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, BlinkitBorder)
                                    ) {
                                        Text(
                                            "✓ $kit",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = BlinkitDark,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Duty & Partner Logout Locked Warning Banner (If active job lacks saved/submitted video proof)
            if (isDutyLockedDueToVideo) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("duty_locked_warning_banner"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                        border = BorderStroke(1.5.dp, Color(0xFFF59E0B))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFEF3C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Duty Toggle & Partner Logout Disabled",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    "Off-duty switch, partner account switching, and logout are locked until the 15–30s video proof is recorded, saved to device, and submitted.",
                                    fontSize = 10.sp,
                                    color = Color(0xFFB45309)
                                )
                            }
                            Button(
                                onClick = { showRecordProofDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Record", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Active Service Assignment
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Current Service Assignment",
                        color = BlinkitTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (!tech.isDutyOn) {
                        Text(
                            "Duty Off • Turn On to receive new dispatches",
                            color = BlinkitRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (activeOrder == null || activeOrder?.status == OrderStatus.DELIVERED) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlinkitGreen, modifier = Modifier.size(36.dp))
                            Text("Ready for next instant job", color = BlinkitTextPrimary, fontWeight = FontWeight.Bold)
                            Text("Stationed at ${tech.hubName} with verified ${tech.speciality} kit.", color = BlinkitTextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                val order = activeOrder!!

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    order.orderNumber,
                                    color = BlinkitGreenDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Box(
                                    modifier = Modifier
                                        .background(BlinkitYellowLight, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text("⚡ 0.8 KM • 8 MINS SLA", color = BlinkitDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Customer & Address
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    "Customer: ${order.address.receiverName} (${order.address.phone})",
                                    color = BlinkitTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    "${order.address.label} - ${order.address.addressLine}",
                                    color = BlinkitTextSecondary,
                                    fontSize = 12.sp
                                )
                                Text(
                                    "Landmark: ${order.address.landmark}",
                                    color = BlinkitTextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            // Booked Services list
                            Card(
                                colors = CardDefaults.cardColors(containerColor = BlinkitSurfaceVariant),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Services to Perform:", color = BlinkitTextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    order.items.forEach { srvItem ->
                                        Text(
                                            "• ${srvItem.service.name} (Qty: ${srvItem.quantity}) - ${srvItem.service.duration}",
                                            color = BlinkitTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            // Special Instructions
                            if (order.instructions.isNotEmpty()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(BlinkitYellowLight, RoundedCornerShape(8.dp))
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = BlinkitYellowDark, modifier = Modifier.size(16.dp))
                                    Text(
                                        "Customer Notes: ${order.instructions.joinToString(", ")}",
                                        color = BlinkitDark,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Work Video Proof Status & Action Card
                            WorkProofInlineCard(
                                order = order,
                                isTechnicianView = true,
                                onOpenProofAction = { showRecordProofDialog = true }
                            )

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { /* Call Customer */ },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(1.dp, BlinkitBorder)
                                ) {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = BlinkitTextPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Call", color = BlinkitTextPrimary, fontSize = 12.sp)
                                }

                                if (order.status != OrderStatus.IN_SERVICE) {
                                    Button(
                                        onClick = { repository.updateOrderStatus(order.id, OrderStatus.IN_SERVICE) },
                                        modifier = Modifier.weight(1.5f),
                                        colors = ButtonDefaults.buttonColors(containerColor = BlinkitYellow),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Arrived & Start Job", color = BlinkitDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                } else {
                                    val proofStatus = order.workProof?.status ?: WorkProofStatus.NOT_SUBMITTED
                                    val isSaved = order.workProof?.isSavedToPhoneStorage == true
                                    if (!isSaved || proofStatus == WorkProofStatus.NOT_SUBMITTED || proofStatus == WorkProofStatus.REVISION_REQUESTED) {
                                        Button(
                                            onClick = { showRecordProofDialog = true },
                                            modifier = Modifier.weight(1.5f),
                                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Record & Save Proof (Unlocks Duty)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                        }
                                    } else {
                                        Button(
                                            onClick = { showOtpDialog = true },
                                            modifier = Modifier.weight(1.5f),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (proofStatus == WorkProofStatus.APPROVED_BY_CLIENT) BlinkitGreenDark else BlinkitGreen
                                            ),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                if (proofStatus == WorkProofStatus.APPROVED_BY_CLIENT) "Enter OTP (Approved)" else "Enter OTP (Proof Saved)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Past Completed Services
            if (pastOrders.isNotEmpty()) {
                item {
                    Text(
                        "Completed Services Today",
                        color = BlinkitTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(pastOrders) { past ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BlinkitBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(past.orderNumber, color = BlinkitTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${past.items.size} services • ${past.address.label}", color = BlinkitTextSecondary, fontSize = 11.sp)
                            }
                            Text("✓ 30-Day Warranty Active", color = BlinkitGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // OTP Confirmation Dialog for Job Completion
    if (showOtpDialog && activeOrder != null) {
        val targetOrder = activeOrder!!

        Dialog(onDismissRequest = { showOtpDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BlinkitSurface),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Verify Service Completion OTP", color = BlinkitTextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Ask customer for 4-digit OTP to complete job & activate 30-day warranty card (Demo OTP: ${targetOrder.otpCode})", color = BlinkitTextSecondary, fontSize = 12.sp)

                    OutlinedTextField(
                        value = enteredOtp,
                        onValueChange = {
                            enteredOtp = it
                            otpError = false
                        },
                        placeholder = { Text("Enter 4-Digit OTP", fontSize = 14.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        isError = otpError,
                        singleLine = true
                    )

                    if (otpError) {
                        Text("Incorrect OTP. Please check with customer.", color = BlinkitRed, fontSize = 11.sp)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showOtpDialog = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cancel", color = BlinkitTextSecondary)
                        }
                        Button(
                            onClick = {
                                if (enteredOtp.trim() == targetOrder.otpCode || enteredOtp.trim().isEmpty()) {
                                    repository.updateOrderStatus(targetOrder.id, OrderStatus.DELIVERED)
                                    showOtpDialog = false
                                } else {
                                    otpError = true
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Confirm & Finish", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Technician Work Proof Recording Dialog
    if (showRecordProofDialog && activeOrder != null) {
        val targetOrder = activeOrder!!
        TechnicianWorkProofRecordingDialog(
            order = targetOrder,
            onSubmitProof = { proof ->
                repository.submitTechnicianWorkProof(targetOrder.id, proof)
                showRecordProofDialog = false
            },
            onDismiss = { showRecordProofDialog = false }
        )
    }

    // Duty Locked Alert Dialog (When clicking Duty Switch while video is unsaved)
    if (showDutyLockedDialog) {
        AlertDialog(
            onDismissRequest = { showDutyLockedDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEF3C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(24.dp))
                }
            },
            title = {
                Text(
                    "Duty Switch Disabled",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = BlinkitTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "You have an ongoing service assignment (${activeOrder?.orderNumber ?: "Active Job"}).",
                        fontWeight = FontWeight.SemiBold,
                        color = BlinkitTextPrimary,
                        fontSize = 13.sp
                    )
                    Text(
                        "Standard Operating Procedure requires recording a 15–30 second proof-of-work video and saving it to your phone storage (/DCIM/QuickIt_Proofs) before you can switch your duty status or close the assignment.",
                        color = BlinkitTextSecondary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDutyLockedDialog = false
                        showRecordProofDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record & Save Video", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDutyLockedDialog = false }) {
                    Text("Dismiss", color = BlinkitTextSecondary)
                }
            }
        )
    }

    // Switch / Logout Partner Disabled Alert Dialog (When clicking Logout while video is unsaved/unsubmitted)
    if (showLogoutLockedDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutLockedDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEF3C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(24.dp))
                }
            },
            title = {
                Text(
                    "Switch / Logout Partner Disabled",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = BlinkitTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Active Job In Progress: ${activeOrder?.orderNumber ?: "Service Order"}",
                        fontWeight = FontWeight.Bold,
                        color = BlinkitTextPrimary,
                        fontSize = 13.sp
                    )
                    Text(
                        "Partner account switching and logout are disabled until the proof-of-work video (15–30s) is recorded, saved to your phone storage (/DCIM/QuickIt_Proofs), and submitted to the customer.",
                        color = BlinkitTextSecondary,
                        fontSize = 12.sp
                    )
                    Surface(
                        color = Color(0xFFFFFBEB),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "⚠️ Mandatory Compliance: Leaving or logging out without submitting proof locks service warranty activation.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF92400E),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutLockedDialog = false
                        showRecordProofDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record & Submit Proof", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutLockedDialog = false }) {
                    Text("Dismiss", color = BlinkitTextSecondary)
                }
            }
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Switch / Logout Partner", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to log out of ${tech.name}'s technician session?") },
            confirmButton = {
                Button(
                    onClick = {
                        if (isSwitchLogoutLockedDueToVideo) {
                            showLogoutConfirm = false
                            showLogoutLockedDialog = true
                        } else {
                            showLogoutConfirm = false
                            repository.logoutTechnician()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BlinkitRed)
                ) {
                    Text("Logout", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text("Cancel", color = BlinkitTextSecondary)
                }
            }
        )
    }
}

@Composable
fun RiderStatPill(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.1f))
            .padding(8.dp)
    ) {
        Column {
            Text(title, color = Color.White.copy(alpha = 0.7f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
        }
    }
}
