package com.example.data

import com.example.ui.theme.*
import com.example.util.LocalStorageVideoManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class BlinkitRepository {

    private val _categories = MutableStateFlow<List<CategoryItem>>(emptyList())
    val categories: StateFlow<List<CategoryItem>> = _categories.asStateFlow()

    private val _services = MutableStateFlow<List<ServiceItem>>(emptyList())
    val services: StateFlow<List<ServiceItem>> = _services.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _pendingDiagnosticVideo = MutableStateFlow<DiagnosticVideoRecord?>(null)
    val pendingDiagnosticVideo: StateFlow<DiagnosticVideoRecord?> = _pendingDiagnosticVideo.asStateFlow()

    fun setPendingDiagnosticVideo(video: DiagnosticVideoRecord?) {
        _pendingDiagnosticVideo.value = video
    }

    fun clearPendingDiagnosticVideo() {
        _pendingDiagnosticVideo.value = null
    }

    private val _activeOrder = MutableStateFlow<OrderItem?>(null)
    val activeOrder: StateFlow<OrderItem?> = _activeOrder.asStateFlow()

    private val _pastOrders = MutableStateFlow<List<OrderItem>>(emptyList())
    val pastOrders: StateFlow<List<OrderItem>> = _pastOrders.asStateFlow()

    private val _allOrders = MutableStateFlow<List<OrderItem>>(emptyList())
    val allOrders: StateFlow<List<OrderItem>> = _allOrders.asStateFlow()

    // ADMIN STATE & AUTH
    private val _adminUser = MutableStateFlow<AdminUser?>(null)
    val adminUser: StateFlow<AdminUser?> = _adminUser.asStateFlow()

    private val _technicians = MutableStateFlow<List<TechnicianProfile>>(emptyList())
    val technicians: StateFlow<List<TechnicianProfile>> = _technicians.asStateFlow()

    private val _hubTools = MutableStateFlow<List<HubToolItem>>(emptyList())
    val hubTools: StateFlow<List<HubToolItem>> = _hubTools.asStateFlow()

    // Admin authentication is backend-controlled; no credentials are embedded in the APK.
    val demoAdminCredentials: List<Triple<String, String, AdminUser>> = emptyList()

    private val _selectedAddress = MutableStateFlow(
        DeliveryAddress(
            id = "addr_1",
            label = "Home",
            addressLine = "Flat 402, Sunshine Residency, 12th Main Road, Indiranagar",
            landmark = "Near 100ft Road Metro Station",
            receiverName = "John Doe",
            phone = "+91 98765 43210"
        )
    )
    val selectedAddress: StateFlow<DeliveryAddress> = _selectedAddress.asStateFlow()

    private val _walletBalance = MutableStateFlow(350.0)
    val walletBalance: StateFlow<Double> = _walletBalance.asStateFlow()

    // FIREBASE & GEMINI AI
    private val geminiService = GeminiService()
    var firebaseAuthHelper: FirebaseAuthHelper? = null

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _aiConversation = MutableStateFlow<List<ChatMessage>>(emptyList())
    val aiConversation: StateFlow<List<ChatMessage>> = _aiConversation.asStateFlow()

    private val _nearbyProviders = MutableStateFlow<List<NearbyServiceProvider>>(emptyList())
    val nearbyProviders: StateFlow<List<NearbyServiceProvider>> = _nearbyProviders.asStateFlow()

    private val _vicinityGrounding = MutableStateFlow<VicinityGroundingData?>(null)
    val vicinityGrounding: StateFlow<VicinityGroundingData?> = _vicinityGrounding.asStateFlow()

    private val _isGroundingLoading = MutableStateFlow(false)
    val isGroundingLoading: StateFlow<Boolean> = _isGroundingLoading.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // FAVORITE PROVIDERS (Synced with Firestore across devices)
    private val _favoriteProviderIds = MutableStateFlow<Set<String>>(setOf("prov_1", "prov_3"))
    val favoriteProviderIds: StateFlow<Set<String>> = _favoriteProviderIds.asStateFlow()

    // TECHNICIAN PARTNER MOBILE OTP AUTHENTICATION STATE
    private val _activeTechnicianSession = MutableStateFlow<TechnicianPartnerSession?>(null)
    val activeTechnicianSession: StateFlow<TechnicianPartnerSession?> = _activeTechnicianSession.asStateFlow()

    private val _pendingTechnicianOtp = MutableStateFlow<String?>("4829")
    val pendingTechnicianOtp: StateFlow<String?> = _pendingTechnicianOtp.asStateFlow()

    private val _pendingTechnicianPhone = MutableStateFlow<String?>("+91 98450 12345")
    val pendingTechnicianPhone: StateFlow<String?> = _pendingTechnicianPhone.asStateFlow()

    // FIREBASE CLOUD MESSAGING (FCM) & PROXIMITY PUSH ALERTS
    private var appContext: android.content.Context? = null
    private val _fcmToken = MutableStateFlow<String?>("fcm_token_qkt_live_auth_39201")
    val fcmToken: StateFlow<String?> = _fcmToken.asStateFlow()

    private val _latestProximityAlert = MutableStateFlow<FcmProximityAlert?>(null)
    val latestProximityAlert: StateFlow<FcmProximityAlert?> = _latestProximityAlert.asStateFlow()

    private val _proximityAlertHistory = MutableStateFlow<List<FcmProximityAlert>>(emptyList())
    val proximityAlertHistory: StateFlow<List<FcmProximityAlert>> = _proximityAlertHistory.asStateFlow()

    fun initFirebase(context: android.content.Context) {
        appContext = context.applicationContext
        QuickItFirebaseMessagingService.activeRepository = this
        QuickItNotificationHelper.createNotificationChannels(context)

        if (firebaseAuthHelper == null) {
            firebaseAuthHelper = FirebaseAuthHelper(context)
            syncFavoritesFromFirestore()
        }

        // Fetch real Firebase Cloud Messaging device registration token
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().token
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val token = task.result
                        _fcmToken.value = token
                        android.util.Log.d("QuickItFCM", "Real FCM Token fetched: $token")
                    } else {
                        android.util.Log.w("QuickItFCM", "Fetching FCM token failed", task.exception)
                    }
                }
        } catch (e: Exception) {
            android.util.Log.w("QuickItFCM", "FCM token lookup note: ${e.message}")
        }
    }

    fun setFcmToken(token: String) {
        _fcmToken.value = token
    }

    fun postProximityAlert(alert: FcmProximityAlert) {
        _latestProximityAlert.value = alert
        val list = _proximityAlertHistory.value.toMutableList()
        list.add(0, alert)
        _proximityAlertHistory.value = list
    }

    fun dismissProximityAlert(alertId: String? = null) {
        if (alertId == null || _latestProximityAlert.value?.id == alertId) {
            _latestProximityAlert.value = null
        }
    }

    /**
     * Triggers a real-time technician proximity alert.
     * Fires a high-priority Android Notification with action buttons and shows in-app HUD banner.
     */
    fun triggerTechnicianProximityPush(
        context: android.content.Context? = appContext,
        order: OrderItem? = _activeOrder.value,
        distanceMeters: Int = 380,
        etaMinutes: Int = 2
    ): FcmProximityAlert {
        val targetOrder = order ?: _activeOrder.value
        val techName = targetOrder?.riderName ?: "Ramesh Sharma"
        val techPhone = targetOrder?.riderPhone ?: "+91 98765 43210"
        val otpCode = targetOrder?.otpCode ?: "4829"
        val orderId = targetOrder?.orderNumber ?: "SRV-10M-8492"

        val alert = FcmProximityAlert(
            title = "⚡ Technician $techName is Nearby! ($distanceMeters m)",
            body = "$techName on ${targetOrder?.riderVehicle ?: "EV Bike"} is arriving in ~$etaMinutes mins. Verification OTP: $otpCode",
            orderId = orderId,
            technicianName = techName,
            technicianPhone = techPhone,
            distanceMeters = distanceMeters,
            etaMinutes = etaMinutes,
            otpCode = otpCode,
            alertType = if (distanceMeters <= 50) ProximityAlertType.ARRIVED else ProximityAlertType.NEARBY
        )

        // 1. Post to in-app reactive StateFlow
        postProximityAlert(alert)

        // 2. Dispatch system notification
        context?.let { ctx ->
            QuickItNotificationHelper.showProximityNotification(ctx, alert)
        }

        return alert
    }

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val catList = listOf(
            CategoryItem("cat_all", "All Services", "⚡", BlinkitYellowLight, "FAST"),
            CategoryItem("cat_plumbing", "Plumbing", "🔧", CatCleanBg, "Instant 10m"),
            CategoryItem("cat_cleaning", "Deep Cleaning", "✨", CatDairyBg, "Top Rated"),
            CategoryItem("cat_electric", "Electrician", "⚡", CatSnacksBg, "Safety 1st"),
            CategoryItem("cat_appliance", "AC & Appliances", "❄️", CatDrinksBg, "Warranty"),
            CategoryItem("cat_carpentry", "Carpentry", "🪚", CatBakeryBg, "Pro Tools"),
            CategoryItem("cat_pest", "Pest Control", "🐜", CatVeggiesBg, "Eco Safe"),
            CategoryItem("cat_drill", "Drilling & Painting", "🎨", CatInstantBg, "Quick")
        )
        _categories.value = catList

        val srvList = listOf(
            // Plumbing Services
            ServiceItem(
                id = "s_1",
                name = "Tap & Mixer Repair / Replacement",
                categoryId = "cat_plumbing",
                subCategory = "Taps & Valves",
                duration = "30 mins",
                price = 149.0,
                originalPrice = 199.0,
                discountPercent = 25,
                emoji = "🚰",
                etaMinutes = "10 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Plumbing Kit + Teflon + Spanners",
                rating = 4.9,
                ratingCount = 1840,
                description = "Fix dripping taps, loose handles, water pressure drop, or install new chrome fixtures.",
                includedTasks = listOf("Gasket & washer replacement", "Internal cartridge check", "Thread sealing", "Pressure leak testing"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_2",
                name = "Blocked Drain & Sink Clearing",
                categoryId = "cat_plumbing",
                subCategory = "Drainage",
                duration = "45 mins",
                price = 249.0,
                originalPrice = 320.0,
                discountPercent = 22,
                emoji = "🚿",
                etaMinutes = "10 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Snake Auger Cable + Eco Drain Cleaner",
                rating = 4.8,
                ratingCount = 920,
                description = "Rapid unclogging of kitchen sinks, bathroom washbasins, and shower floor traps.",
                includedTasks = listOf("High-pressure mechanical augering", "P-trap dismantling & descaling", "Bacterial odor treatment"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_3",
                name = "Toilet Jet Spray & Flush Tank Fix",
                categoryId = "cat_plumbing",
                subCategory = "Toilets",
                duration = "30 mins",
                price = 179.0,
                originalPrice = 229.0,
                discountPercent = 21,
                emoji = "🚽",
                etaMinutes = "12 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Angle Valve Kit + Silicone Sealer",
                rating = 4.9,
                ratingCount = 760,
                description = "Fix continuous tank water leakage, faulty siphon valves, or replace high-pressure jet spray.",
                includedTasks = listOf("Flush siphon ballcock adjustment", "Jet pipe washer replacement", "Angle cock connection sealing")
            ),
            ServiceItem(
                id = "s_4",
                name = "Geyser & Pipe Joint Leakage Sealing",
                categoryId = "cat_plumbing",
                subCategory = "Pipes & Geysers",
                duration = "45 mins",
                price = 299.0,
                originalPrice = 399.0,
                discountPercent = 25,
                emoji = "🔧",
                etaMinutes = "12 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "CPVC/UPVC Pipe Welder + Pressure Gauge",
                rating = 4.85,
                ratingCount = 640,
                description = "Triage water heater inlet/outlet seepage, burst flex hoses, or wall pipe fractures.",
                includedTasks = listOf("Pressure burst testing", "SS braided hose replacement", "Anti-siphon valve check")
            ),

            // Deep Cleaning & Housekeeping
            ServiceItem(
                id = "s_5",
                name = "Bathroom Deep Stain Removal & Sanitization",
                categoryId = "cat_cleaning",
                subCategory = "Bathrooms",
                duration = "60 mins",
                price = 399.0,
                originalPrice = 549.0,
                discountPercent = 27,
                emoji = "🧼",
                etaMinutes = "15 mins",
                warranty = "100% Sparkle Guarantee",
                toolkitRequired = "Rotary Tile Scrubber + Diversey Solvents",
                rating = 4.92,
                ratingCount = 2140,
                description = "Hard water scaling removal from tiles, mirrors, taps, toilet bowls, and exhaust fans.",
                includedTasks = listOf("Acid-free scaling treatment", "Mirror & glass buffing", "Grout scrubbing & sanitization", "Exhaust fan degreasing"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_6",
                name = "Kitchen Deep Degreasing & Hob Cleaning",
                categoryId = "cat_cleaning",
                subCategory = "Kitchens",
                duration = "90 mins",
                price = 599.0,
                originalPrice = 799.0,
                discountPercent = 25,
                emoji = "🍳",
                etaMinutes = "15 mins",
                warranty = "Grease-Free Guarantee",
                toolkitRequired = "Steam Degreaser + Non-abrasive Pads",
                rating = 4.88,
                ratingCount = 1320,
                description = "Intense steam cleaning of stove counters, chimney exterior, splashback tiles, and sink basins.",
                includedTasks = listOf("Heavy oil/grease emulsification", "Countertop buffing", "Sink sterilization", "Cabinet exterior wipe-down"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_7",
                name = "Sofa & Cushion Shampooing (3-Seater)",
                categoryId = "cat_cleaning",
                subCategory = "Living Room",
                duration = "60 mins",
                price = 449.0,
                originalPrice = 600.0,
                discountPercent = 25,
                emoji = "🛋️",
                etaMinutes = "15 mins",
                warranty = "Anti-Allergen Guarantee",
                toolkitRequired = "Wet-Dry Injection Extraction Machine",
                rating = 4.8,
                ratingCount = 890,
                description = "Deep fabric foam injection & high-suction water extraction removing food stains & dust mites.",
                includedTasks = listOf("Dry vacuuming dust removal", "Eco foam shampoo agitation", "High-suction water extraction")
            ),
            ServiceItem(
                id = "s_8",
                name = "Full Home Deep Cleaning (2 BHK)",
                categoryId = "cat_cleaning",
                subCategory = "Complete Home",
                duration = "180 mins",
                price = 1499.0,
                originalPrice = 1999.0,
                discountPercent = 25,
                emoji = "✨",
                etaMinutes = "15 mins",
                warranty = "Complete Clean Guarantee",
                toolkitRequired = "2-Pro Crew + Industrial Vacuum + Steamer",
                rating = 4.95,
                ratingCount = 1750,
                description = "Comprehensive cleaning of 2 bedrooms, hall, kitchen, and 2 bathrooms from ceiling to floor.",
                includedTasks = listOf("Floor scrubbing & polishing", "Window rail detailing", "Doors & wardrobes dusting", "Appliance exterior wipe")
            ),

            // Electrician & Wiring
            ServiceItem(
                id = "s_9",
                name = "Ceiling Fan Installation & Regulator Fix",
                categoryId = "cat_electric",
                subCategory = "Fans & Lights",
                duration = "30 mins",
                price = 149.0,
                originalPrice = 199.0,
                discountPercent = 25,
                emoji = "🌀",
                etaMinutes = "10 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Insulated Multimeter + Heavy Step Ladder",
                rating = 4.9,
                ratingCount = 1420,
                description = "Mount ceiling fans, balance wobble blades, replace faulty capacitors, or install step regulators.",
                includedTasks = listOf("Downrod safety pin locking", "Capacitor speed calibration", "Wobble & noise balancing"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_10",
                name = "Switchboard & Power Socket Fix",
                categoryId = "cat_electric",
                subCategory = "Switches & Sockets",
                duration = "20 mins",
                price = 99.0,
                originalPrice = 149.0,
                discountPercent = 33,
                emoji = "🔌",
                etaMinutes = "10 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Digital Voltage Tester + Fire-safe Wire Kit",
                rating = 4.85,
                ratingCount = 1180,
                description = "Replace burnt 6A/16A sockets, toggle switches, or fix loose sparking neutral contacts.",
                includedTasks = listOf("Load test with multimeter", "Fire-resistant terminal crimping", "Earthing ground verification")
            ),
            ServiceItem(
                id = "s_11",
                name = "MCB Tripping & Short Circuit Triage",
                categoryId = "cat_electric",
                subCategory = "Circuit Protection",
                duration = "45 mins",
                price = 249.0,
                originalPrice = 349.0,
                discountPercent = 28,
                emoji = "⚡",
                etaMinutes = "10 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Current Clamp Meter + RCCB Tester",
                rating = 4.92,
                ratingCount = 890,
                description = "Emergency diagnostic of sudden power cut, burning smell, or repeated breaker trips.",
                includedTasks = listOf("Phase load distribution check", "Neutral leakage detection", "Defective breaker replacement")
            ),

            // AC & Appliance Repair
            ServiceItem(
                id = "s_12",
                name = "AC Jet Pump Foam Deep Servicing",
                categoryId = "cat_appliance",
                subCategory = "Air Conditioners",
                duration = "45 mins",
                price = 499.0,
                originalPrice = 699.0,
                discountPercent = 28,
                emoji = "❄️",
                etaMinutes = "15 mins",
                warranty = "60-Day Cooling Guarantee",
                toolkitRequired = "High-Pressure Jet Washer + AC Service Jacket",
                rating = 4.95,
                ratingCount = 2890,
                description = "Deep coil cleaning with non-corrosive antibacterial foam jacket ensuring 2x cooling efficiency.",
                includedTasks = listOf("Indoor cooling coil jet wash", "Outdoor condenser pressure rinse", "Drain tray fungus clearing", "Gas pressure check"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_13",
                name = "Washing Machine Drum & Drain Repair",
                categoryId = "cat_appliance",
                subCategory = "Washing Machines",
                duration = "60 mins",
                price = 349.0,
                originalPrice = 499.0,
                discountPercent = 30,
                emoji = "🧺",
                etaMinutes = "15 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Universal Belt & Pump Kit + Diagnostic Tool",
                rating = 4.82,
                ratingCount = 740,
                description = "Fix unbalance spinning error, water not draining (E2/OE error), or loud vibration sounds.",
                includedTasks = listOf("Inlet filter cleaning", "Drain pump lint removal", "Belt tension calibration")
            ),
            ServiceItem(
                id = "s_14",
                name = "Refrigerator Cooling & Gas Checkup",
                categoryId = "cat_appliance",
                subCategory = "Refrigerators",
                duration = "45 mins",
                price = 299.0,
                originalPrice = 399.0,
                discountPercent = 25,
                emoji = "🧊",
                etaMinutes = "15 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "R600a Manifold Gauge + Thermocouple",
                rating = 4.86,
                ratingCount = 610,
                description = "Triage freezer ice buildup, insufficient lower cooling, compressor clicking, or door seal leak.",
                includedTasks = listOf("Defrost sensor check", "Compressor relay test", "Condenser coil dusting", "Door gasket inspection")
            ),

            // Carpentry & Furniture
            ServiceItem(
                id = "s_15",
                name = "Door Lock & Handle Replacement",
                categoryId = "cat_carpentry",
                subCategory = "Doors & Locks",
                duration = "30 mins",
                price = 199.0,
                originalPrice = 269.0,
                discountPercent = 26,
                emoji = "🔐",
                etaMinutes = "12 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Mortise Chisel Set + Cordless Impact Driver",
                rating = 4.88,
                ratingCount = 930,
                description = "Fix stuck door latches, install new high-security mortise cylinder locks, or align deadbolts.",
                includedTasks = listOf("Door frame slot re-chiseling", "Smooth locking alignment", "Handle lubrication"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_16",
                name = "Cupboard Hinge Alignment & Magnet Catch",
                categoryId = "cat_carpentry",
                subCategory = "Wardrobes",
                duration = "30 mins",
                price = 149.0,
                originalPrice = 199.0,
                discountPercent = 25,
                emoji = "🚪",
                etaMinutes = "12 mins",
                warranty = "30-Day Guarantee",
                toolkitRequired = "Soft-Close Hydraulic Hinge Set",
                rating = 4.8,
                ratingCount = 580,
                description = "Re-align sagging modular wardrobe doors, replace broken auto-hinges, or fix loose magnets.",
                includedTasks = listOf("Hinge screw tightening", "Door gap leveling", "Soft-close damper calibration")
            ),

            // Pest Control
            ServiceItem(
                id = "s_17",
                name = "Cockroach & Ant Odorless Gel Treatment",
                categoryId = "cat_pest",
                subCategory = "Insect Control",
                duration = "45 mins",
                price = 499.0,
                originalPrice = 699.0,
                discountPercent = 28,
                emoji = "🪳",
                etaMinutes = "15 mins",
                warranty = "90-Day Pest-Free Guarantee",
                toolkitRequired = "Bayer Maxforce Gel Gun + Residual Spray",
                rating = 4.93,
                ratingCount = 1450,
                description = "No need to empty kitchen cabinets! Odorless food-grade gel applied to hidden cracks.",
                includedTasks = listOf("Gel baiting behind shelves", "Drain trap residual barrier", "Egg cluster inspection"),
                isBestseller = true
            ),

            // Drilling & Wall Care
            ServiceItem(
                id = "s_18",
                name = "Wall Drill & TV / Mirror / Frame Hanging",
                categoryId = "cat_drill",
                subCategory = "Wall Mounting",
                duration = "30 mins",
                price = 149.0,
                originalPrice = 199.0,
                discountPercent = 25,
                emoji = "🔨",
                etaMinutes = "10 mins",
                warranty = "Rock-Solid Anchor Guarantee",
                toolkitRequired = "Bosch Hammer Drill + Laser Bubble Level",
                rating = 4.91,
                ratingCount = 1680,
                description = "Precision laser drilling for heavy mirrors, TV wall mounts, painting frames, curtain rods, or shelves.",
                includedTasks = listOf("Laser leveling alignment", "Heavy duty wall plugs", "Zero dust collection sleeve", "Weight load test"),
                isBestseller = true
            ),

            // Additional Plumbing Offerings
            ServiceItem(
                id = "s_19",
                name = "RO Water Purifier Filter & Membrane Replacement",
                categoryId = "cat_plumbing",
                subCategory = "Water Purifiers",
                duration = "40 mins",
                price = 349.0,
                originalPrice = 499.0,
                discountPercent = 30,
                emoji = "💧",
                etaMinutes = "10 mins",
                warranty = "30-Day Pure Flow Guarantee",
                toolkitRequired = "TDS Digital Meter + Spanner & Food-Grade Tubes",
                rating = 4.94,
                ratingCount = 1120,
                description = "Replace sediment, carbon, and RO membrane filters, calibrate TDS output, and sanitize chamber.",
                includedTasks = listOf("TDS input/output testing", "Sediment filter change", "Pre-carbon flush", "Leak-tight pressure check"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_20",
                name = "Overhead Tank Float Valve & Overflow Fix",
                categoryId = "cat_plumbing",
                subCategory = "Pipes & Geysers",
                duration = "35 mins",
                price = 229.0,
                originalPrice = 299.0,
                discountPercent = 23,
                emoji = "🚰",
                etaMinutes = "12 mins",
                warranty = "30-Day Zero-Spill Guarantee",
                toolkitRequired = "Brass Ball Valve + Pipe Sealant",
                rating = 4.87,
                ratingCount = 530,
                description = "Fix continuous roof tank water overflowing, faulty brass ballcock, or leaking delivery joint.",
                includedTasks = listOf("Float valve replacement", "Overflow pipe alignment", "Thread Teflon sealing")
            ),

            // Additional Electrical Offerings
            ServiceItem(
                id = "s_21",
                name = "Smart LED Strip & Chandelier Ceiling Fitting",
                categoryId = "cat_electric",
                subCategory = "Fans & Lights",
                duration = "45 mins",
                price = 299.0,
                originalPrice = 399.0,
                discountPercent = 25,
                emoji = "💡",
                etaMinutes = "10 mins",
                warranty = "30-Day Safe Wiring Guarantee",
                toolkitRequired = "Laser Measure + Insulated Wire Strippers",
                rating = 4.93,
                ratingCount = 890,
                description = "Install decorative ceiling pendants, LED profile strips, chandeliers, or smart home light switches.",
                includedTasks = listOf("Ceiling hook reinforcement", "Safe neutral wiring", "Dimmer & smart controller pairing"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_22",
                name = "Home Inverter & Battery Wiring Health Check",
                categoryId = "cat_electric",
                subCategory = "Circuit Protection",
                duration = "35 mins",
                price = 199.0,
                originalPrice = 279.0,
                discountPercent = 28,
                emoji = "🔋",
                etaMinutes = "10 mins",
                warranty = "30-Day Power Shield Guarantee",
                toolkitRequired = "Battery Hydrometer + High Amp Load Tester",
                rating = 4.89,
                ratingCount = 670,
                description = "Check distilled water levels, de-sulfate terminal corrosion, and test automatic backup switchover.",
                includedTasks = listOf("Terminal petroleum jelly coating", "Voltage load drop test", "Backup relay inspection")
            ),

            // Additional Cleaning Offerings
            ServiceItem(
                id = "s_23",
                name = "Kitchen Chimney & Baffle Filter Deep Degreasing",
                categoryId = "cat_cleaning",
                subCategory = "Kitchens",
                duration = "50 mins",
                price = 399.0,
                originalPrice = 549.0,
                discountPercent = 27,
                emoji = "🍲",
                etaMinutes = "15 mins",
                warranty = "Grease-Free Air Guarantee",
                toolkitRequired = "Hot Steam Degreasing Tub + Alkaline Bath",
                rating = 4.91,
                ratingCount = 1240,
                description = "Remove thick oily grime from baffle filters, suction blowers, oil collector cups, and outer steel body.",
                includedTasks = listOf("Baffle filter caustic bath", "Blower motor wipe-down", "Oil cup emptying", "Stainless steel polish"),
                isBestseller = true
            ),
            ServiceItem(
                id = "s_24",
                name = "Balcony & Window High-Pressure Wash",
                categoryId = "cat_cleaning",
                subCategory = "Complete Home",
                duration = "45 mins",
                price = 349.0,
                originalPrice = 450.0,
                discountPercent = 22,
                emoji = "🪟",
                etaMinutes = "15 mins",
                warranty = "Crystal Clear Guarantee",
                toolkitRequired = "High-Pressure Jet Gun + Rubber Squeegee",
                rating = 4.86,
                ratingCount = 780,
                description = "Power wash pigeon droppings, grime from balcony floor tiles, metal railings, and sliding glass tracks.",
                includedTasks = listOf("High-pressure floor rinse", "Railings sanitization", "Glass squeegee finish", "Track vacuuming")
            ),

            // Additional Appliance Care Offerings
            ServiceItem(
                id = "s_25",
                name = "Microwave Magnetron & Heating Diagnostic",
                categoryId = "cat_appliance",
                subCategory = "Microwaves",
                duration = "40 mins",
                price = 249.0,
                originalPrice = 349.0,
                discountPercent = 28,
                emoji = "📻",
                etaMinutes = "15 mins",
                warranty = "30-Day Heat Safe Guarantee",
                toolkitRequired = "High Voltage Probe + Turntable Motor Tester",
                rating = 4.88,
                ratingCount = 510,
                description = "Fix microwave turning on but not heating food, spark in cavity, or turntable roller wheel jamming.",
                includedTasks = listOf("High voltage diode check", "Mica sheet inspection", "Door interlock safety test", "Turntable motor repair")
            ),
            ServiceItem(
                id = "s_26",
                name = "Water Geyser Heating Element & Anode Rod Fix",
                categoryId = "cat_appliance",
                subCategory = "Geysers",
                duration = "45 mins",
                price = 349.0,
                originalPrice = 499.0,
                discountPercent = 30,
                emoji = "♨️",
                etaMinutes = "12 mins",
                warranty = "60-Day Hot Water Guarantee",
                toolkitRequired = "Descaling Pump + Thermostat Calibrator",
                rating = 4.92,
                ratingCount = 890,
                description = "Triage geyser not heating, water taking too long, electric shock on tap, or scale buildup inside tank.",
                includedTasks = listOf("Magnesium anode rod check", "Heating coil descaling", "Thermostat cutoff calibration", "Earthing ground test"),
                isBestseller = true
            )
        )
        _services.value = srvList

        // Seed 1 active sample 10-15 minute service booking to showcase live tracking & 1-minute video review
        val sampleItems = listOf(
            CartItem(srvList[0], 1), // Tap & Mixer Repair
            CartItem(srvList[4], 1)  // Bathroom Deep Stain Removal
        )
        val initialBooking = OrderItem(
            id = "srv_1001",
            orderNumber = "SRV-10M-8492",
            items = sampleItems,
            itemTotal = 548.0,
            discountTotal = 200.0,
            deliveryFee = 0.0, // Free visit on > 299
            handlingFee = 29.0, // Safety gear & Sanitization
            tip = 30.0,
            grandTotal = 607.0,
            status = OrderStatus.AWAITING_TECHNICIAN_REVIEW,
            address = _selectedAddress.value,
            instructions = listOf("Wear shoe covers 👟", "Bring pipe wrench 🔧", "Mask required 😷"),
            placedAtTime = "Just now",
            etaMinutesLeft = 10,
            riderName = "Ramesh Sharma",
            riderPhone = "+91 98765 43210",
            riderVehicle = "KA 01 EK 8821 (EV with Toolbag)",
            riderRating = 4.96,
            technicianSpeciality = "Certified Master Plumber & Hygiene Expert (8+ Yrs Exp)",
            otpCode = "4829",
            darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
            technicianReviewDecision = TechnicianReviewDecision.AWAITING_REVIEW,
            diagnosticVideo = DiagnosticVideoRecord(
                id = "DIAG-8821",
                localFilePath = "/storage/emulated/0/DCIM/QuickIt_Diagnostic_Videos/VID_DIAG_1MIN_PLUMB_LEAK.mp4",
                durationSeconds = 60,
                serviceCategory = "Plumbing Leak",
                issueDescription = "1-minute video recording showing severe under-sink angle cock joint leak and water hammer noise",
                aiDiagnosticSummary = "High-pressure washer gasket rupture detected in sink drain coupling",
                recommendedSpareParts = listOf("3/4 CPVC Teflon Seal", "Brass Angle Valve", "High-Flow Drain Trap"),
                technicianPreparationNotes = "Carry pipe spanner, PTFE seal, and heavy-duty basin wrench."
            )
        )
        _activeOrder.value = initialBooking

        val mockPastOrder1 = OrderItem(
            id = "srv_1000",
            orderNumber = "SRV-10M-7190",
            items = listOf(CartItem(srvList[11], 1)), // AC Jet Pump
            itemTotal = 499.0,
            discountTotal = 200.0,
            deliveryFee = 0.0,
            handlingFee = 29.0,
            tip = 50.0,
            grandTotal = 578.0,
            status = OrderStatus.DELIVERED,
            address = _selectedAddress.value,
            instructions = listOf("Ladder available on-site", "Outdoor unit on balcony"),
            placedAtTime = "Yesterday, 3:45 PM",
            etaMinutesLeft = 0,
            riderName = "Karthik Raja",
            riderPhone = "+91 98765 11223",
            riderVehicle = "KA 03 HM 4019 (EV van)",
            riderRating = 4.98,
            technicianSpeciality = "Master HVAC & AC Jet Specialist",
            otpCode = "9182",
            darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)"
        )

        val mockOrder2 = OrderItem(
            id = "srv_1002",
            orderNumber = "SRV-10M-9021",
            items = listOf(CartItem(srvList[8], 1)), // Ceiling Fan
            itemTotal = 149.0,
            discountTotal = 50.0,
            deliveryFee = 49.0,
            handlingFee = 29.0,
            tip = 20.0,
            grandTotal = 247.0,
            status = OrderStatus.PACKING,
            address = DeliveryAddress("addr_2", "Office", "9th Floor, Tech Park, Outer Ring Rd", "Tower B", "Vikram Sen", "+91 98111 22334"),
            instructions = listOf("Visitor pass required at gate", "High ceiling 12ft"),
            placedAtTime = "5 mins ago",
            etaMinutesLeft = 14,
            riderName = "Arjun Verma",
            riderPhone = "+91 97722 33445",
            riderVehicle = "KA 05 AB 1234 (EV)",
            riderRating = 4.91,
            technicianSpeciality = "Licensed High-Voltage Wireman",
            otpCode = "3190",
            darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)"
        )

        _pastOrders.value = listOf(mockPastOrder1)
        _allOrders.value = listOf(initialBooking, mockOrder2, mockPastOrder1)

        // Seed Technicians Fleet
        _technicians.value = listOf(
            TechnicianProfile("tech_1", "Ramesh Sharma", "+91 98765 43210", "KA 01 EK 8821", "Ather EV 450X (Toolbox)", "Master Plumber & Sanitizer", 4.96, 6, 88, TechnicianStatus.ON_DISPATCH, "SRV-10M-8492", "👨‍🔧"),
            TechnicianProfile("tech_2", "Arjun Verma", "+91 97722 33445", "KA 05 AB 1234", "Ola S1 Pro (Ladder Mount)", "Certified Senior Electrician", 4.91, 5, 74, TechnicianStatus.ON_DISPATCH, "SRV-10M-9021", "⚡"),
            TechnicianProfile("tech_3", "Karthik Raja", "+91 98765 11223", "KA 03 HM 4019", "Chetak EV (Pressure Rig)", "Master HVAC & AC Jet Pro", 4.98, 8, 92, TechnicianStatus.AVAILABLE, null, "❄️"),
            TechnicianProfile("tech_4", "Deepak Gupta", "+91 98333 44556", "KA 02 MN 7712", "TVS iQube (Chisel/Drill kit)", "Precision Joinery & Locks", 4.87, 4, 65, TechnicianStatus.AVAILABLE, null, "🪚"),
            TechnicianProfile("tech_5", "Sameer Khan", "+91 98444 55667", "KA 04 ZZ 9090", "River Indie (Heavy Carrier)", "Deep Cleaning Specialist", 4.94, 7, 81, TechnicianStatus.AVAILABLE, null, "🧼"),
            TechnicianProfile("tech_6", "Manoj Kumar", "+91 98555 66778", "KA 01 CC 3344", "Ather 450S", "Pest & Termite Eliminator", 4.89, 3, 58, TechnicianStatus.OFF_DUTY, null, "🐜")
        )

        // Seed Hub Tools & Equipment Inventory
        _hubTools.value = listOf(
            HubToolItem("tool_1", "CPVC/UPVC Rapid Pipe Welder (800W)", "Plumbing", "🔥", 8, 3, "100% Calibrated", isCritical = true),
            HubToolItem("tool_2", "Electric Snake Drain Auger 25ft", "Plumbing", "🌀", 12, 4, "Sterilized & Checked"),
            HubToolItem("tool_3", "Heavy Duty Basin & Angle Valve Spanner Kit", "Plumbing", "🔧", 20, 6, "Standard Tooling"),
            HubToolItem("tool_4", "High-Pressure AC Foam Jet Washer Pump", "Appliance", "💦", 10, 2, "Tested 140 Bar", isCritical = true),
            HubToolItem("tool_5", "R600a/R32 Eco Refrigerant Manifold Gauge", "Appliance", "❄️", 6, 1, "Calibrated 0-500 PSI"),
            HubToolItem("tool_6", "Fluke Insulated True-RMS Multimeter & Clamp", "Electrical", "⚡", 15, 5, "Safety Certified 1000V", isCritical = true),
            HubToolItem("tool_7", "Bosch Professional Hammer Drill + Laser Level", "Drilling", "🔨", 14, 4, "Zero-Dust Sleeve Fitted"),
            HubToolItem("tool_8", "Industrial Foam Injection Extraction Shampooer", "Cleaning", "🛋️", 9, 3, "HEPA Filtered"),
            HubToolItem("tool_9", "Bayer Maxforce Odorless Gel Injector Gun", "Pest Control", "🪳", 18, 2, "Fresh Gel Loaded")
        )

        // Seed Nearby Service Providers in Vicinity
        _nearbyProviders.value = listOf(
            NearbyServiceProvider(
                id = "prov_1",
                name = "Ramesh Sharma",
                speciality = "Master Plumber & Pipe Leak Specialist",
                categoryId = "cat_plumbing",
                rating = 4.96,
                ratingCount = 840,
                distanceKm = 0.4,
                etaMinutes = 6,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = -0.35f,
                longitudeOffset = 0.45f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "👨‍🔧",
                phone = "+91 98765 43210",
                vehicleNumber = "KA 01 EK 8821",
                vehicleType = "Ather EV 450X with Rapid Toolbag",
                completedJobsToday = 6,
                currentVicinityLandmark = "100ft Road, Near CMH Metro",
                isAvailableNow = true,
                primaryToolkits = listOf("Rothenberger Pipe Wrench", "CPVC Fast Seal Kit", "Drain Snake")
            ),
            NearbyServiceProvider(
                id = "prov_2",
                name = "Arjun Verma",
                speciality = "Licensed Senior Wireman & MCB Specialist",
                categoryId = "cat_electric",
                rating = 4.92,
                ratingCount = 620,
                distanceKm = 0.8,
                etaMinutes = 8,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = 0.55f,
                longitudeOffset = -0.30f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "⚡",
                phone = "+91 97722 33445",
                vehicleNumber = "KA 05 AB 1234",
                vehicleType = "Ola S1 Pro with Ladder Carrier",
                completedJobsToday = 5,
                currentVicinityLandmark = "12th Main Club Road",
                isAvailableNow = true,
                primaryToolkits = listOf("Fluke 1000V Multimeter", "Schneider MCB Kit", "Laser Tester")
            ),
            NearbyServiceProvider(
                id = "prov_3",
                name = "Karthik Raja",
                speciality = "Master HVAC & AC Jet Power Washer",
                categoryId = "cat_appliance",
                rating = 4.98,
                ratingCount = 910,
                distanceKm = 1.1,
                etaMinutes = 10,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = -0.60f,
                longitudeOffset = -0.50f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "❄️",
                phone = "+91 98765 11223",
                vehicleNumber = "KA 03 HM 4019",
                vehicleType = "Chetak EV with High Pressure Rig",
                completedJobsToday = 8,
                currentVicinityLandmark = "HAL 2nd Stage, Defence Colony",
                isAvailableNow = true,
                primaryToolkits = listOf("140 Bar Jet Pump", "R32 Gas Manifold", "Anti-Fungal Coil Spray")
            ),
            NearbyServiceProvider(
                id = "prov_4",
                name = "Sameer Khan",
                speciality = "Sofa & Deep Home Sanitization Pro",
                categoryId = "cat_cleaning",
                rating = 4.88,
                ratingCount = 450,
                distanceKm = 0.6,
                etaMinutes = 7,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = 0.40f,
                longitudeOffset = 0.65f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "🧼",
                phone = "+91 98444 55667",
                vehicleNumber = "KA 04 ZZ 9090",
                vehicleType = "River Indie Heavy Utility EV",
                completedJobsToday = 7,
                currentVicinityLandmark = "Old Airport Road Junction",
                isAvailableNow = true,
                primaryToolkits = listOf("Kärcher HEPA Vacuum", "Odor Neutralizer Gun", "Steam Sanitizer")
            ),
            NearbyServiceProvider(
                id = "prov_5",
                name = "Deepak Gupta",
                speciality = "Precision Carpenter & Digital Locks",
                categoryId = "cat_carpentry",
                rating = 4.85,
                ratingCount = 380,
                distanceKm = 1.3,
                etaMinutes = 12,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = -0.20f,
                longitudeOffset = -0.75f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "🪚",
                phone = "+91 98333 44556",
                vehicleNumber = "KA 02 MN 7712",
                vehicleType = "TVS iQube with Hardware Case",
                completedJobsToday = 4,
                currentVicinityLandmark = "Domlur Flyover / EGL Corridor",
                isAvailableNow = true,
                primaryToolkits = listOf("Bosch 18V Cordless Jigsaw", "Yale Lock Router", "Hettich Hinges")
            ),
            NearbyServiceProvider(
                id = "prov_6",
                name = "Imran Khan",
                speciality = "Emergency Jet Spray & Tap Fixer",
                categoryId = "cat_plumbing",
                rating = 4.95,
                ratingCount = 530,
                distanceKm = 0.3,
                etaMinutes = 5,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = 0.15f,
                longitudeOffset = -0.35f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "🔧",
                phone = "+91 98111 44552",
                vehicleNumber = "KA 01 CC 7788",
                vehicleType = "Ather 450X Rapid",
                completedJobsToday = 9,
                currentVicinityLandmark = "Indiranagar 100ft Road Metro",
                isAvailableNow = true,
                primaryToolkits = listOf("Jaguar Ceramic Spindle Kit", "Teflon Thread Seal", "Drain Blaster")
            ),
            NearbyServiceProvider(
                id = "prov_7",
                name = "Praveen Nair",
                speciality = "Ceiling Fan & Inverter Wiring Tech",
                categoryId = "cat_electric",
                rating = 4.89,
                ratingCount = 410,
                distanceKm = 0.5,
                etaMinutes = 6,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = -0.10f,
                longitudeOffset = 0.20f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "💡",
                phone = "+91 98222 11990",
                vehicleNumber = "KA 03 EX 9901",
                vehicleType = "Ather 450S",
                completedJobsToday = 4,
                currentVicinityLandmark = "Defence Colony Main Gate",
                isAvailableNow = true,
                primaryToolkits = listOf("Fluke Clamp Meter", "Laser Level", "Havells Capacitor Kit")
            ),
            NearbyServiceProvider(
                id = "prov_8",
                name = "Sunil Joshi",
                speciality = "Kitchen Steam & Chimney Degreaser",
                categoryId = "cat_cleaning",
                rating = 4.93,
                ratingCount = 680,
                distanceKm = 0.7,
                etaMinutes = 8,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = 0.30f,
                longitudeOffset = -0.45f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "✨",
                phone = "+91 98333 77881",
                vehicleNumber = "KA 04 MM 5566",
                vehicleType = "Ola S1 Air",
                completedJobsToday = 6,
                currentVicinityLandmark = "CMH Road Crossing",
                isAvailableNow = true,
                primaryToolkits = listOf("Steam Jet Gun", "Diversey Suma Degreaser", "Microfiber Rig")
            ),
            NearbyServiceProvider(
                id = "prov_9",
                name = "Rajesh Goud",
                speciality = "Washing Machine & Refrigerator Tech",
                categoryId = "cat_appliance",
                rating = 4.91,
                ratingCount = 740,
                distanceKm = 0.9,
                etaMinutes = 9,
                darkStoreHub = "QuickIt Service Hub #14 (Indiranagar)",
                latitudeOffset = 0.25f,
                longitudeOffset = 0.35f,
                status = TechnicianStatus.AVAILABLE,
                avatarEmoji = "🧺",
                phone = "+91 98444 33221",
                vehicleNumber = "KA 05 CD 8899",
                vehicleType = "TVS iQube Electric",
                completedJobsToday = 5,
                currentVicinityLandmark = "Double Road BDA Complex",
                isAvailableNow = true,
                primaryToolkits = listOf("LG/Samsung Motor Tester", "Drain Valve Puller", "Multimeter")
            )
        )

        _vicinityGrounding.value = VicinityGroundingData(
            locationName = "Indiranagar, Bangalore",
            summaryText = "6 Verified Service Pros stationed within 1.5 km of Dark Store Hub #14. High availability with 5-10 min dispatch.",
            nearestDarkStoreHub = "QuickIt Service Hub #14 (Indiranagar 100ft Rd)",
            averageDispatchEtaMinutes = 8,
            liveTrafficCondition = "Light Corridor (Fast EV Routing)",
            landmarks = listOf(
                GroundingSource(title = "QuickIt Service Hub #14 Depot", uri = "https://maps.google.com/?q=Indiranagar+Hub", snippet = "100ft Road, Stage 1, Indiranagar • 0.3 km away"),
                GroundingSource(title = "Hardware & Spares Central Warehouse", uri = "https://maps.google.com/?q=Old+Airport+Rd", snippet = "Old Airport Road • 1.1 km away")
            )
        )
    }

    // CART OPERATIONS
    fun addToCart(service: ServiceItem) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.service.id == service.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + 1)
        } else {
            current.add(CartItem(service = service, quantity = 1))
        }
        _cart.value = current
    }

    fun removeFromCart(serviceId: String) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.service.id == serviceId }
        if (index >= 0) {
            val existing = current[index]
            if (existing.quantity > 1) {
                current[index] = existing.copy(quantity = existing.quantity - 1)
            } else {
                current.removeAt(index)
            }
        }
        _cart.value = current
    }

    fun getServiceQuantity(serviceId: String): Int {
        return _cart.value.firstOrNull { it.service.id == serviceId }?.quantity ?: 0
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    // BOOK INSTANT 10-15 MINUTE SERVICE
    fun placeOrder(
        tipAmount: Double,
        instructions: List<String>,
        paymentMethod: String,
        assignedTechnician: NearbyServiceProvider? = null,
        etaMinutes: Int? = null,
        paymentStatus: String = if (paymentMethod.contains("After", ignoreCase = true)) "PAY_AFTER_SERVICE" else "PAID_ONLINE",
        transactionId: String = "TXN-QKT-" + (100000..999999).random()
    ): OrderItem {
        val items = _cart.value
        val itemTotal = items.sumOf { it.service.price * it.quantity }
        val discountTotal = items.sumOf { (it.service.originalPrice - it.service.price) * it.quantity }
        val deliveryFee = if (itemTotal >= 299.0) 0.0 else 49.0
        val handlingFee = 29.0 // Safety gear & warranty processing
        val grandTotal = itemTotal + deliveryFee + handlingFee + tipAmount

        // Deduct from wallet if paid via wallet
        if (paymentMethod.contains("Wallet", ignoreCase = true)) {
            _walletBalance.value = maxOf(0.0, _walletBalance.value - grandTotal)
        }

        val primaryCategory = items.firstOrNull()?.service?.categoryId ?: "cat_plumbing"
        val matchedTech = assignedTechnician 
            ?: _nearbyProviders.value.firstOrNull { it.categoryId == primaryCategory && it.status == TechnicianStatus.AVAILABLE && it.isAvailableNow }
            ?: _nearbyProviders.value.firstOrNull { it.status == TechnicianStatus.AVAILABLE }
            ?: _nearbyProviders.value.firstOrNull()

        val orderNum = "SRV-10M-" + (1000..9999).random()
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val randomOtp = (1000..9999).random().toString()
        val calculatedEta = etaMinutes ?: (matchedTech?.etaMinutes ?: 10)

        val newBooking = OrderItem(
            id = "srv_" + System.currentTimeMillis(),
            orderNumber = orderNum,
            items = items,
            itemTotal = itemTotal,
            discountTotal = discountTotal,
            deliveryFee = deliveryFee,
            handlingFee = handlingFee,
            tip = tipAmount,
            grandTotal = grandTotal,
            status = OrderStatus.AWAITING_TECHNICIAN_REVIEW,
            address = _selectedAddress.value,
            instructions = instructions,
            placedAtTime = timeNow,
            etaMinutesLeft = calculatedEta,
            riderName = matchedTech?.name ?: "Ramesh Sharma",
            riderPhone = matchedTech?.phone ?: "+91 98765 43210",
            riderVehicle = (matchedTech?.vehicleNumber ?: "KA 01 EK 8821") + " (" + (matchedTech?.vehicleType ?: "EV Scooter with Toolbag") + ")",
            riderRating = matchedTech?.rating ?: 4.96,
            technicianSpeciality = matchedTech?.speciality ?: "Certified Master Specialist",
            otpCode = randomOtp,
            darkStoreHub = matchedTech?.darkStoreHub ?: "QuickIt Service Hub #14 (Indiranagar)",
            paymentMethod = paymentMethod,
            paymentStatus = paymentStatus,
            transactionId = transactionId,
            diagnosticVideo = _pendingDiagnosticVideo.value,
            technicianReviewDecision = TechnicianReviewDecision.AWAITING_REVIEW
        )

        _activeOrder.value = newBooking
        _cart.value = emptyList()
        _pendingDiagnosticVideo.value = null

        // Also add to allOrders queue for Admin real-time tracking
        val all = _allOrders.value.toMutableList()
        all.add(0, newBooking)
        _allOrders.value = all

        // Real-Time Alert to Customer
        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "📹 1-Min Diagnostic Video Submitted",
                message = "Technician ${newBooking.riderName} is reviewing your video to verify equipment & accept booking.",
                orderId = newBooking.id
            )
        }

        // Persistent Sync to Firebase Firestore
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                firebaseAuthHelper?.saveBookingToFirestore(newBooking)
            } catch (e: Exception) {
                android.util.Log.w("QuickItRepository", "Firestore booking sync: ${e.message}")
            }
        }

        return newBooking
    }

    // TECHNICIAN VIDEO REVIEW ACTIONS: ACCEPT OR REJECT
    fun acceptServiceRequest(orderId: String, technicianNotes: String = "", etaMinutes: Int = 8) {
        val current = _activeOrder.value
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        if (current != null && current.id == orderId) {
            val updated = current.copy(
                status = OrderStatus.PACKING,
                etaMinutesLeft = etaMinutes,
                technicianReviewDecision = TechnicianReviewDecision.ACCEPTED,
                technicianReviewNotes = technicianNotes.ifBlank { "Diagnostic video verified. Parts & calibrated tools packed." },
                technicianReviewedAt = timeNow
            )
            _activeOrder.value = updated
            syncOrderAcrossLists(updated)

            appContext?.let { ctx ->
                QuickItNotificationHelper.showServiceStatusNotification(
                    context = ctx,
                    title = "✅ Service Request Accepted!",
                    message = "${updated.riderName} reviewed your 1-minute video and accepted the job. Dispatched with parts!",
                    orderId = updated.id
                )
            }

            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    firebaseAuthHelper?.saveBookingToFirestore(updated)
                } catch (e: Exception) {
                    android.util.Log.w("QuickItRepository", "Firestore accept sync: ${e.message}")
                }
            }
        }
    }

    fun rejectServiceRequest(orderId: String, rejectionReason: String, technicianNotes: String = "") {
        val current = _activeOrder.value
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        if (current != null && current.id == orderId) {
            // Instant 100% refund back to wallet
            _walletBalance.value = _walletBalance.value + current.grandTotal

            val updated = current.copy(
                status = OrderStatus.REJECTED_BY_TECHNICIAN,
                etaMinutesLeft = 0,
                technicianReviewDecision = TechnicianReviewDecision.REJECTED,
                technicianRejectionReason = rejectionReason.ifBlank { "Service scope exceeds rapid on-site standard equipment." },
                technicianReviewNotes = technicianNotes,
                technicianReviewedAt = timeNow,
                paymentStatus = "REFUNDED_TO_WALLET"
            )
            _activeOrder.value = updated
            syncOrderAcrossLists(updated)

            appContext?.let { ctx ->
                QuickItNotificationHelper.showServiceStatusNotification(
                    context = ctx,
                    title = "❌ Service Request Declined",
                    message = "Technician reviewed video: $rejectionReason. 100% refund of ₹${current.grandTotal.toInt()} added to wallet.",
                    orderId = updated.id
                )
            }

            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    firebaseAuthHelper?.saveBookingToFirestore(updated)
                } catch (e: Exception) {
                    android.util.Log.w("QuickItRepository", "Firestore reject sync: ${e.message}")
                }
            }
        }
    }

    fun resubmitDiagnosticVideo(orderId: String, video: DiagnosticVideoRecord) {
        val current = _activeOrder.value
        if (current != null && current.id == orderId) {
            val updated = current.copy(
                diagnosticVideo = video,
                status = OrderStatus.AWAITING_TECHNICIAN_REVIEW,
                technicianReviewDecision = TechnicianReviewDecision.AWAITING_REVIEW,
                technicianRejectionReason = null,
                etaMinutesLeft = 10
            )
            _activeOrder.value = updated
            syncOrderAcrossLists(updated)

            appContext?.let { ctx ->
                QuickItNotificationHelper.showServiceStatusNotification(
                    context = ctx,
                    title = "📹 1-Min Video Resubmitted",
                    message = "New diagnostic video sent to technician ${updated.riderName} for instant review.",
                    orderId = updated.id
                )
            }
        }
    }

    private fun syncOrderAcrossLists(order: OrderItem) {
        val pastList = _pastOrders.value.toMutableList()
        val pastIdx = pastList.indexOfFirst { it.id == order.id }
        if (pastIdx >= 0) {
            pastList[pastIdx] = order
            _pastOrders.value = pastList
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == order.id }
        if (idx >= 0) {
            all[idx] = order
            _allOrders.value = all
        }
    }

    // SERVICE BOOKING STATUS MUTATIONS
    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        val current = _activeOrder.value
        if (current != null && current.id == orderId) {
            val updated = current.copy(
                status = newStatus,
                etaMinutesLeft = when (newStatus) {
                    OrderStatus.AWAITING_TECHNICIAN_REVIEW -> 10
                    OrderStatus.PLACED -> 12
                    OrderStatus.PACKING -> 8
                    OrderStatus.OUT_FOR_DELIVERY -> 4
                    OrderStatus.IN_SERVICE -> 1
                    OrderStatus.DELIVERED -> 0
                    OrderStatus.CANCELLED -> 0
                    OrderStatus.REJECTED_BY_TECHNICIAN -> 0
                }
            )
            _activeOrder.value = updated
            if (newStatus == OrderStatus.DELIVERED) {
                val past = _pastOrders.value.toMutableList()
                if (past.none { it.id == orderId }) {
                    past.add(0, updated)
                    _pastOrders.value = past
                }
            }

            // Real-Time Push Notification Alerts based on Technician Status
            when (newStatus) {
                OrderStatus.OUT_FOR_DELIVERY -> {
                    triggerTechnicianProximityPush(
                        order = updated,
                        distanceMeters = 350,
                        etaMinutes = 3
                    )
                }
                OrderStatus.IN_SERVICE -> {
                    triggerTechnicianProximityPush(
                        order = updated,
                        distanceMeters = 20,
                        etaMinutes = 0
                    )
                }
                OrderStatus.DELIVERED -> {
                    appContext?.let { ctx ->
                        QuickItNotificationHelper.showServiceStatusNotification(
                            context = ctx,
                            title = "✅ Service Completed Successfully!",
                            message = "30-Day warranty card activated for booking ${updated.orderNumber}.",
                            orderId = updated.id
                        )
                    }
                }
                else -> {}
            }

            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    firebaseAuthHelper?.saveBookingToFirestore(updated)
                } catch (e: Exception) {
                    android.util.Log.w("QuickItRepository", "Firestore update status sync: ${e.message}")
                }
            }
        }
        // Sync in pastOrders if present
        val pastList = _pastOrders.value.toMutableList()
        val pastIdx = pastList.indexOfFirst { it.id == orderId }
        if (pastIdx >= 0) {
            pastList[pastIdx] = pastList[pastIdx].copy(status = newStatus)
            _pastOrders.value = pastList
        }
        // Sync in allOrders
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            all[idx] = all[idx].copy(status = newStatus)
            _allOrders.value = all
        }
    }

    fun advanceOrderStatus(orderId: String): OrderStatus {
        val order = _allOrders.value.find { it.id == orderId } ?: _activeOrder.value
        val nextStatus = when (order?.status) {
            OrderStatus.AWAITING_TECHNICIAN_REVIEW -> OrderStatus.PACKING
            OrderStatus.PLACED -> OrderStatus.PACKING
            OrderStatus.PACKING -> OrderStatus.OUT_FOR_DELIVERY
            OrderStatus.OUT_FOR_DELIVERY -> OrderStatus.IN_SERVICE
            OrderStatus.IN_SERVICE -> OrderStatus.DELIVERED
            OrderStatus.DELIVERED -> OrderStatus.AWAITING_TECHNICIAN_REVIEW // Loop for continuous demonstration
            OrderStatus.CANCELLED -> OrderStatus.AWAITING_TECHNICIAN_REVIEW
            OrderStatus.REJECTED_BY_TECHNICIAN -> OrderStatus.AWAITING_TECHNICIAN_REVIEW
            null -> OrderStatus.AWAITING_TECHNICIAN_REVIEW
        }
        updateOrderStatus(orderId, nextStatus)
        return nextStatus
    }

    fun setDeliveryAddress(address: DeliveryAddress) {
        _selectedAddress.value = address
    }

    // ==========================================
    // WORK VERIFICATION & VIDEO PROOF OPERATIONS
    // ==========================================

    fun submitTechnicianWorkProof(orderId: String, proof: WorkProofRecord) {
        val current = _activeOrder.value
        val actualSavedPath = appContext?.let { ctx ->
            try {
                val file = LocalStorageVideoManager.saveTechnicianVideoProofToLocalStorage(
                    context = ctx,
                    orderId = orderId,
                    serviceName = proof.videoTitle
                )
                file.absolutePath
            } catch (e: Exception) {
                "/storage/emulated/0/DCIM/QuickIt_Service_Proofs/PROOF_${orderId}_${System.currentTimeMillis()}.mp4"
            }
        } ?: proof.savedLocalPhonePath ?: "/storage/emulated/0/DCIM/QuickIt_Service_Proofs/PROOF_${orderId}.mp4"

        val submittedProof = proof.copy(
            status = WorkProofStatus.SUBMITTED,
            recordedTimestamp = "Just now",
            isSavedToPhoneStorage = true,
            savedLocalPhonePath = actualSavedPath,
            storageFolder = "DCIM/QuickIt_Service_Proofs"
        )
        if (current != null && current.id == orderId) {
            val updated = current.copy(workProof = submittedProof)
            _activeOrder.value = updated
        }
        
        // Update all orders list
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            all[idx] = all[idx].copy(workProof = submittedProof)
            _allOrders.value = all
        }

        // Fire notification to customer
        val targetOrder = _activeOrder.value ?: all.find { it.id == orderId }
        val techName = targetOrder?.riderName ?: "Technician"
        postProximityAlert(
            FcmProximityAlert(
                title = "📹 Work Verification Proof Submitted",
                body = "$techName has recorded job verification video (Saved locally to phone storage) for your review before closing the order.",
                orderId = orderId,
                technicianName = techName,
                technicianPhone = targetOrder?.riderPhone ?: "+91 98765 43210",
                distanceMeters = 0,
                etaMinutes = 0,
                otpCode = targetOrder?.otpCode ?: "4829",
                alertType = ProximityAlertType.STATUS_UPDATE
            )
        )
        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "📹 Work Verification Proof Submitted",
                message = "$techName has submitted video proof saved in DCIM storage for booking ${targetOrder?.orderNumber ?: orderId}. Tap to inspect, download or approve.",
                orderId = orderId
            )
        }
    }

    fun approveWorkProofByClient(orderId: String, rating: Int = 5, paymentMethod: String = "UPI (Instant)") {
        val current = _activeOrder.value
        if (current != null && current.id == orderId) {
            val approvedProof = (current.workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.APPROVED_BY_CLIENT,
                clientFeedbackRating = rating,
                isCustomerPaidAfterProof = true,
                paymentSettledMethod = paymentMethod,
                isPaymentOnHold = false
            )
            val updated = current.copy(
                workProof = approvedProof,
                paymentStatus = "PAID_POST_PROOF_VERIFIED"
            )
            _activeOrder.value = updated
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val approvedProof = (all[idx].workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.APPROVED_BY_CLIENT,
                clientFeedbackRating = rating,
                isCustomerPaidAfterProof = true,
                paymentSettledMethod = paymentMethod,
                isPaymentOnHold = false
            )
            all[idx] = all[idx].copy(
                workProof = approvedProof,
                paymentStatus = "PAID_POST_PROOF_VERIFIED"
            )
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "💳 Payment Settled & OTP Unlocked",
                message = "Work proof approved for booking ${current?.orderNumber ?: orderId}. Reveal 4-digit OTP to technician.",
                orderId = orderId
            )
        }
    }

    fun downloadProofVideoLocally(orderId: String): String {
        val current = _activeOrder.value
        val actualSavedPath = appContext?.let { ctx ->
            try {
                val file = LocalStorageVideoManager.downloadProofVideoToCustomerStorage(
                    context = ctx,
                    orderId = orderId,
                    orderNumber = current?.orderNumber ?: orderId
                )
                file.absolutePath
            } catch (e: Exception) {
                "/storage/emulated/0/DCIM/QuickIt_Service_Proofs/DOWNLOAD_VID_${orderId}_${System.currentTimeMillis()}.mp4"
            }
        } ?: "/storage/emulated/0/DCIM/QuickIt_Service_Proofs/DOWNLOAD_VID_${orderId}.mp4"

        if (current != null && current.id == orderId) {
            val updatedProof = (current.workProof ?: WorkProofRecord()).copy(
                customerDownloadedVideo = true,
                customerDownloadedPath = actualSavedPath
            )
            _activeOrder.value = current.copy(workProof = updatedProof)
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val updatedProof = (all[idx].workProof ?: WorkProofRecord()).copy(
                customerDownloadedVideo = true,
                customerDownloadedPath = actualSavedPath
            )
            all[idx] = all[idx].copy(workProof = updatedProof)
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "⬇️ Work Video Proof Downloaded Locally",
                message = "Video saved to phone storage at $actualSavedPath",
                orderId = orderId
            )
        }
        return actualSavedPath
    }

    fun uploadCustomerLocalProofVideo(
        orderId: String,
        localVideoPath: String,
        issueNotes: String = "",
        issueCategory: String = "Quality Issue"
    ) {
        val current = _activeOrder.value
        val actualSavedPath = appContext?.let { ctx ->
            try {
                val file = LocalStorageVideoManager.saveCustomerRebuttalVideoToLocalStorage(
                    context = ctx,
                    orderId = orderId,
                    issueCategory = issueCategory
                )
                file.absolutePath
            } catch (e: Exception) {
                localVideoPath
            }
        } ?: localVideoPath

        val updatedProof = (current?.workProof ?: WorkProofRecord()).copy(
            customerLocalVideoPath = actualSavedPath,
            customerIssueNotes = issueNotes,
            customerUploadTimestamp = "Just now",
            issueCategory = issueCategory,
            status = WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD,
            isPaymentOnHold = true,
            paymentHoldReason = "Customer uploaded device video proof: $issueNotes"
        )
        if (current != null && current.id == orderId) {
            _activeOrder.value = current.copy(
                workProof = updatedProof,
                paymentStatus = "PAYMENT_ON_HOLD_DISPUTED"
            )
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            all[idx] = all[idx].copy(
                workProof = updatedProof,
                paymentStatus = "PAYMENT_ON_HOLD_DISPUTED"
            )
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "⏸️ Payment Placed On Hold & Evidence Stored Locally",
                message = "Your local video evidence was saved to device and submitted. Payment is frozen until Admin review.",
                orderId = orderId
            )
        }
    }

    fun escalateToAdminReview(
        orderId: String,
        reason: String,
        issueCategory: String = "Quality Issue",
        customerVideoPath: String? = null
    ) {
        val current = _activeOrder.value
        val updatedProof = (current?.workProof ?: WorkProofRecord()).copy(
            status = WorkProofStatus.DISPUTED_PAYMENT_ON_HOLD,
            isPaymentOnHold = true,
            paymentHoldReason = reason,
            issueCategory = issueCategory,
            customerLocalVideoPath = customerVideoPath ?: current?.workProof?.customerLocalVideoPath,
            clientRejectionReason = reason
        )
        if (current != null && current.id == orderId) {
            _activeOrder.value = current.copy(
                workProof = updatedProof,
                paymentStatus = "PAYMENT_ON_HOLD_ADMIN_REVIEW"
            )
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            all[idx] = all[idx].copy(
                workProof = updatedProof,
                paymentStatus = "PAYMENT_ON_HOLD_ADMIN_REVIEW"
            )
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "🛡️ Admin Review Escalation Active",
                message = "Payment on hold for booking ${current?.orderNumber ?: orderId}. Admin team is inspecting video proof.",
                orderId = orderId
            )
        }
    }

    fun adminApproveVideoProof(orderId: String, adminNotes: String) {
        val timeNow = SimpleDateFormat("dd-MMM hh:mm a", Locale.getDefault()).format(Date())
        val reviewer = _adminUser.value?.name ?: "Operations Supervisor"
        
        val current = _activeOrder.value
        if (current != null && current.id == orderId) {
            val approvedProof = (current.workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.ADMIN_APPROVED,
                isPaymentOnHold = false,
                adminApprovalNotes = adminNotes,
                adminReviewedAt = timeNow,
                adminReviewerName = reviewer
            )
            _activeOrder.value = current.copy(
                workProof = approvedProof,
                paymentStatus = "PAID_ADMIN_APPROVED",
                status = OrderStatus.DELIVERED
            )
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val approvedProof = (all[idx].workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.ADMIN_APPROVED,
                isPaymentOnHold = false,
                adminApprovalNotes = adminNotes,
                adminReviewedAt = timeNow,
                adminReviewerName = reviewer
            )
            all[idx] = all[idx].copy(
                workProof = approvedProof,
                paymentStatus = "PAID_ADMIN_APPROVED",
                status = OrderStatus.DELIVERED
            )
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "✅ Admin Approved Video Proof",
                message = "Admin has verified the video proof for booking $orderId. Payment released and 30-day warranty activated.",
                orderId = orderId
            )
        }
    }

    fun adminRejectAndRefund(orderId: String, refundNotes: String) {
        val timeNow = SimpleDateFormat("dd-MMM hh:mm a", Locale.getDefault()).format(Date())
        val reviewer = _adminUser.value?.name ?: "Operations Supervisor"

        val current = _activeOrder.value
        val refundAmount = current?.grandTotal ?: 500.0
        _walletBalance.value = _walletBalance.value + refundAmount

        if (current != null && current.id == orderId) {
            val rejectedProof = (current.workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.ADMIN_REFUNDED,
                isPaymentOnHold = false,
                adminApprovalNotes = "Claim Approved: $refundNotes. Full refund of ₹${String.format("%.0f", refundAmount)} credited to wallet.",
                adminReviewedAt = timeNow,
                adminReviewerName = reviewer
            )
            _activeOrder.value = current.copy(
                workProof = rejectedProof,
                paymentStatus = "REFUNDED_TO_WALLET",
                status = OrderStatus.CANCELLED
            )
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val rejectedProof = (all[idx].workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.ADMIN_REFUNDED,
                isPaymentOnHold = false,
                adminApprovalNotes = "Claim Approved: $refundNotes. Full refund of ₹${String.format("%.0f", refundAmount)} credited to wallet.",
                adminReviewedAt = timeNow,
                adminReviewerName = reviewer
            )
            all[idx] = all[idx].copy(
                workProof = rejectedProof,
                paymentStatus = "REFUNDED_TO_WALLET",
                status = OrderStatus.CANCELLED
            )
            _allOrders.value = all
        }

        appContext?.let { ctx ->
            QuickItNotificationHelper.showServiceStatusNotification(
                context = ctx,
                title = "💸 Full Refund Processed: ₹${String.format("%.0f", refundAmount)}",
                message = "Admin approved customer claim for $orderId. Refund credited to QuickIt Wallet.",
                orderId = orderId
            )
        }
    }

    fun requestWorkProofRevision(orderId: String, reason: String) {
        val current = _activeOrder.value
        if (current != null && current.id == orderId) {
            val rejectedProof = (current.workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.REVISION_REQUESTED,
                clientRejectionReason = reason
            )
            val updated = current.copy(workProof = rejectedProof)
            _activeOrder.value = updated
        }
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val rejectedProof = (all[idx].workProof ?: WorkProofRecord()).copy(
                status = WorkProofStatus.REVISION_REQUESTED,
                clientRejectionReason = reason
            )
            all[idx] = all[idx].copy(workProof = rejectedProof)
            _allOrders.value = all
        }
    }


    // ==========================================
    // ADMIN AUTHENTICATION & OPERATIONS
    // ==========================================

    fun loginAdmin(email: String, pass: String): Boolean {
        // Phase 2: Android no longer authenticates admins with embedded credentials.
        // Admin authentication must be implemented through the authenticated backend.
        return false
    }

    fun logoutAdmin() {
        _adminUser.value = null
    }

    // SERVICE CATALOG CRUD
    fun addService(service: ServiceItem) {
        val list = _services.value.toMutableList()
        list.add(0, service)
        _services.value = list
    }

    fun updateService(service: ServiceItem) {
        val list = _services.value.toMutableList()
        val index = list.indexOfFirst { it.id == service.id }
        if (index >= 0) {
            list[index] = service
            _services.value = list
        }
    }

    fun deleteService(serviceId: String) {
        val list = _services.value.toMutableList()
        list.removeAll { it.id == serviceId }
        _services.value = list
        // Remove from cart if present
        removeFromCart(serviceId)
    }

    fun toggleServiceAvailability(serviceId: String, available: Boolean) {
        val list = _services.value.toMutableList()
        val index = list.indexOfFirst { it.id == serviceId }
        if (index >= 0) {
            list[index] = list[index].copy(isAvailable = available)
            _services.value = list
        }
    }

    // DISPATCH & BOOKING ACTIONS BY ADMIN
    fun assignTechnicianToOrder(orderId: String, techId: String) {
        val tech = _technicians.value.firstOrNull { it.id == techId } ?: return
        val all = _allOrders.value.toMutableList()
        val idx = all.indexOfFirst { it.id == orderId }
        if (idx >= 0) {
            val updated = all[idx].copy(
                riderName = tech.name,
                riderPhone = tech.phone,
                riderVehicle = "${tech.vehicleNumber} (${tech.vehicleType})",
                riderRating = tech.rating,
                technicianSpeciality = tech.speciality
            )
            all[idx] = updated
            _allOrders.value = all

            if (_activeOrder.value?.id == orderId) {
                _activeOrder.value = updated
            }
        }

        // Update technician status
        updateTechnicianStatus(techId, TechnicianStatus.ON_DISPATCH, all.getOrNull(idx)?.orderNumber)
    }

    fun cancelOrderByAdmin(orderId: String, reason: String) {
        updateOrderStatus(orderId, OrderStatus.CANCELLED)
    }

    // FLEET / TECHNICIANS MANAGEMENT
    fun updateTechnicianStatus(techId: String, status: TechnicianStatus, bookingNum: String? = null) {
        val techs = _technicians.value.toMutableList()
        val idx = techs.indexOfFirst { it.id == techId }
        if (idx >= 0) {
            techs[idx] = techs[idx].copy(
                status = status,
                activeBookingNumber = bookingNum ?: techs[idx].activeBookingNumber
            )
            _technicians.value = techs
        }
    }

    // HUB TOOLS & INVENTORY
    fun restockTool(toolId: String, addedQty: Int) {
        val tools = _hubTools.value.toMutableList()
        val idx = tools.indexOfFirst { it.id == toolId }
        if (idx >= 0) {
            val existing = tools[idx]
            tools[idx] = existing.copy(totalStock = existing.totalStock + addedQty)
            _hubTools.value = tools
        }
    }

    fun toggleToolCondition(toolId: String) {
        val tools = _hubTools.value.toMutableList()
        val idx = tools.indexOfFirst { it.id == toolId }
        if (idx >= 0) {
            val existing = tools[idx]
            val newCond = if (existing.condition.contains("100%")) "Routine Maintenance Due" else "100% Calibrated & Certified"
            tools[idx] = existing.copy(condition = newCond)
            _hubTools.value = tools
        }
    }

    // ==========================================
    // GEMINI AI ASSISTANT & GROUNDING METHODS
    // ==========================================

    suspend fun sendAiChatMessage(
        userMessage: String,
        model: GeminiModel = GeminiModel.FLASH,
        systemInstruction: String = "You are QuickIt's 10-Minute Home Services Certified Repair Specialist. Give fast, clear, step-by-step diagnostic advice with price estimates in ₹.",
        groundingType: GroundingType = GroundingType.NONE
    ) {
        val currentHistory = _aiConversation.value.toMutableList()
        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = userMessage
        )
        currentHistory.add(userMsg)
        _aiConversation.value = currentHistory
        _isAiThinking.value = true

        try {
            val aiResponse = geminiService.generateChatResponse(
                conversation = currentHistory,
                userMessage = userMessage,
                model = model,
                systemInstruction = systemInstruction,
                groundingType = groundingType
            )
            val updated = _aiConversation.value.toMutableList()
            updated.add(aiResponse)
            _aiConversation.value = updated
        } finally {
            _isAiThinking.value = false
        }
    }

    suspend fun transcribeVoiceAudio(audioBytes: ByteArray): String {
        return geminiService.transcribeAudio(audioBytes, "audio/wav")
    }

    suspend fun queryMapsGrounding(locationQuery: String): ChatMessage {
        return geminiService.queryMapsGrounding(locationQuery)
    }

    suspend fun refreshVicinityWithGrounding(locationQuery: String): VicinityGroundingData {
        _isGroundingLoading.value = true
        try {
            val response = geminiService.queryMapsGrounding(locationQuery)
            val cleanSummary = if (response.text.isNotBlank()) response.text else "Active Dark Store Hub with certified technicians available for 10-minute dispatch."
            
            val updatedGrounding = VicinityGroundingData(
                locationName = locationQuery,
                summaryText = cleanSummary,
                nearestDarkStoreHub = "QuickIt Service Hub ($locationQuery Corridor)",
                averageDispatchEtaMinutes = (6..12).random(),
                liveTrafficCondition = if (locationQuery.contains("Metro", ignoreCase = true) || locationQuery.contains("Indiranagar", ignoreCase = true)) "Fast EV Corridor (5-8 mins)" else "Normal Urban Traffic (8-12 mins)",
                landmarks = response.groundingSources.ifEmpty {
                    listOf(
                        GroundingSource(
                            title = "QuickIt Service Hub Depot ($locationQuery)",
                            uri = "https://maps.google.com/?q=${java.net.URLEncoder.encode(locationQuery, "UTF-8")}",
                            snippet = "Local technician dispatch point & calibrated toolkit store"
                        ),
                        GroundingSource(
                            title = "Verified Hardware & Spare Parts Depot",
                            uri = "https://maps.google.com/?q=${java.net.URLEncoder.encode(locationQuery + " Hardware", "UTF-8")}",
                            snippet = "Genuine OEM spares & high-voltage safety gear"
                        )
                    )
                }
            )
            _vicinityGrounding.value = updatedGrounding

            // Adapt nearby provider landmarks & distances to match the grounded area
            val currentList = _nearbyProviders.value.map { provider ->
                val randomOffsetDist = (0.2 + (provider.id.hashCode() % 12) * 0.1).coerceIn(0.2, 1.8)
                val roundedDist = Math.round(randomOffsetDist * 10.0) / 10.0
                val randomEta = (roundedDist * 6 + 3).toInt().coerceIn(4, 15)
                provider.copy(
                    distanceKm = roundedDist,
                    etaMinutes = randomEta,
                    darkStoreHub = "QuickIt Service Hub ($locationQuery)",
                    currentVicinityLandmark = "$locationQuery Sector ${provider.id.takeLast(1)}"
                )
            }
            _nearbyProviders.value = currentList
            return updatedGrounding
        } catch (e: Exception) {
            val fallback = VicinityGroundingData(
                locationName = locationQuery,
                summaryText = "Service Pros deployed within 1.5 km of $locationQuery. Instant 10-minute dispatch active.",
                nearestDarkStoreHub = "QuickIt Service Hub ($locationQuery)",
                averageDispatchEtaMinutes = 8,
                liveTrafficCondition = "Optimal Dispatch Route",
                landmarks = listOf(
                    GroundingSource(
                        title = "Local Hub Station",
                        uri = "https://maps.google.com",
                        snippet = "Near $locationQuery center"
                    )
                )
            )
            _vicinityGrounding.value = fallback
            return fallback
        } finally {
            _isGroundingLoading.value = false
        }
    }

    suspend fun querySearchGrounding(searchQuery: String): ChatMessage {
        return geminiService.querySearchGrounding(searchQuery)
    }

    fun clearAiChat() {
        _aiConversation.value = emptyList()
    }

    // ==========================================
    // FAVORITE PROVIDER (FIRESTORE SYNCED) METHODS
    // ==========================================

    fun isProviderFavorite(providerId: String): Boolean {
        return _favoriteProviderIds.value.contains(providerId)
    }

    fun toggleFavoriteProvider(providerId: String) {
        val current = _favoriteProviderIds.value.toMutableSet()
        val isNowFavorite = if (current.contains(providerId)) {
            current.remove(providerId)
            false
        } else {
            current.add(providerId)
            true
        }
        _favoriteProviderIds.value = current

        // Sync change across devices using Firestore
        val provider = _nearbyProviders.value.find { it.id == providerId }
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                firebaseAuthHelper?.toggleFavoriteProviderInFirestore(providerId, provider, isNowFavorite)
            } catch (e: Exception) {
                // Logged in helper
            }
        }
    }

    fun syncFavoritesFromFirestore() {
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val remoteFavorites = firebaseAuthHelper?.loadFavoriteProvidersFromFirestore() ?: emptySet()
                if (remoteFavorites.isNotEmpty()) {
                    val merged = _favoriteProviderIds.value.toMutableSet()
                    merged.addAll(remoteFavorites)
                    _favoriteProviderIds.value = merged
                }
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun getProviderForRiderName(riderName: String): NearbyServiceProvider? {
        return _nearbyProviders.value.find { it.name.equals(riderName, ignoreCase = true) }
            ?: _nearbyProviders.value.firstOrNull()
    }

    // ========================================================
    // TECHNICIAN PARTNER MOBILE OTP LOGIN & SESSION MANAGEMENT
    // ========================================================

    fun sendTechnicianOtp(rawPhone: String): String {
        val cleanPhone = rawPhone.trim()
        _pendingTechnicianPhone.value = cleanPhone

        // Generate a 4-digit OTP (e.g. 4829 or deterministic based on phone or random)
        val generatedOtp = when {
            cleanPhone.contains("98450") -> "4829"
            cleanPhone.contains("98765") -> "7193"
            cleanPhone.contains("91234") -> "5581"
            cleanPhone.contains("99887") -> "3624"
            else -> {
                val rand = (1000..9999).random().toString()
                rand
            }
        }
        _pendingTechnicianOtp.value = generatedOtp
        return generatedOtp
    }

    fun verifyTechnicianOtp(rawPhone: String, enteredOtp: String): Boolean {
        val cleanPhone = rawPhone.trim()
        val expectedOtp = _pendingTechnicianOtp.value ?: "4829"

        // Accept matched OTP or demo wildcard if blank
        val isValid = enteredOtp.trim() == expectedOtp || (enteredOtp.length == 4 && enteredOtp == "4829")

        if (isValid) {
            // Find registered provider or construct partner session
            val matchedProvider = _nearbyProviders.value.find { prov ->
                prov.phone.contains(cleanPhone.takeLast(6)) ||
                cleanPhone.contains(prov.phone.takeLast(6))
            } ?: when {
                cleanPhone.contains("98450") -> _nearbyProviders.value.find { it.id == "prov_1" }
                cleanPhone.contains("98765") -> _nearbyProviders.value.find { it.id == "prov_2" }
                cleanPhone.contains("91234") -> _nearbyProviders.value.find { it.id == "prov_3" }
                cleanPhone.contains("99887") -> _nearbyProviders.value.find { it.id == "prov_4" }
                else -> _nearbyProviders.value.firstOrNull()
            }

            val session = if (matchedProvider != null) {
                TechnicianPartnerSession(
                    providerId = matchedProvider.id,
                    name = matchedProvider.name,
                    phone = cleanPhone.ifEmpty { matchedProvider.phone },
                    speciality = matchedProvider.speciality,
                    vehicleNumber = matchedProvider.vehicleNumber,
                    vehicleType = matchedProvider.vehicleType,
                    avatarEmoji = matchedProvider.avatarEmoji,
                    hubName = matchedProvider.darkStoreHub,
                    rating = matchedProvider.rating,
                    isDutyOn = true,
                    todayEarnings = 2450,
                    todayJobs = matchedProvider.completedJobsToday,
                    primaryToolkits = matchedProvider.primaryToolkits
                )
            } else {
                TechnicianPartnerSession(
                    providerId = "tech_${System.currentTimeMillis() % 10000}",
                    name = "Ramesh Sharma",
                    phone = cleanPhone.ifEmpty { "+91 98450 12345" },
                    speciality = "Certified Plumbing Lead",
                    vehicleNumber = "KA 01 EK 8821 (EV)",
                    vehicleType = "Electric Scooter",
                    avatarEmoji = "👨🏽‍🔧",
                    hubName = "Indiranagar Hub #14",
                    rating = 4.96,
                    isDutyOn = true,
                    todayEarnings = 2450,
                    todayJobs = 6,
                    primaryToolkits = listOf("Pipe Wrench Pro", "Laser Leak Detector", "O-Ring Seal Kit")
                )
            }

            _activeTechnicianSession.value = session
            return true
        }
        return false
    }

    fun setTechnicianDuty(isOn: Boolean) {
        val current = _activeTechnicianSession.value ?: return
        _activeTechnicianSession.value = current.copy(isDutyOn = isOn)
    }

    fun logoutTechnician() {
        _activeTechnicianSession.value = null
    }

    fun registerNewTechnician(
        name: String,
        phone: String,
        speciality: String,
        categoryId: String,
        darkStoreHub: String,
        vehicleType: String,
        vehicleNumber: String,
        experienceYears: Int,
        selectedToolkits: List<String>,
        governmentIdNumber: String = ""
    ): TechnicianPartnerSession {
        val cleanPhone = if (phone.startsWith("+91")) phone else "+91 ${phone.trim()}"
        val providerId = "prov_reg_${System.currentTimeMillis() % 100000}"

        val emoji = when (categoryId) {
            "cat_plumbing" -> "👨🏽‍🔧"
            "cat_electric" -> "⚡"
            "cat_cleaning" -> "✨"
            "cat_appliance" -> "❄️"
            "cat_carpentry" -> "🪚"
            "cat_painting" -> "🎨"
            else -> "👷‍♂️"
        }

        val defaultToolkits = when (categoryId) {
            "cat_plumbing" -> listOf("Pipe Wrench Pro", "Laser Leak Detector", "O-Ring Seal Kit")
            "cat_electric" -> listOf("Fluke Multimeter", "Insulated VDE Set", "Circuit Tracer")
            "cat_cleaning" -> listOf("HEPA Steam Vacuum", "UV Sterilizer", "Bio-Enzyme Pack")
            "cat_appliance" -> listOf("Refrigerant Manifold", "Digital Thermometer", "Fin Straightener")
            "cat_carpentry" -> listOf("Laser Precision Level", "Jigsaw Pro", "Pocket Hole Jig")
            else -> listOf("Professional Hand Tool Set", "Safety Inspection Kit")
        }

        val toolkits = if (selectedToolkits.isNotEmpty()) selectedToolkits else defaultToolkits

        val newProvider = NearbyServiceProvider(
            id = providerId,
            name = name.trim(),
            speciality = speciality.ifEmpty {
                "Certified " + when (categoryId) {
                    "cat_plumbing" -> "Plumbing Specialist"
                    "cat_electric" -> "Master Electrician"
                    "cat_cleaning" -> "Sanitization Expert"
                    "cat_appliance" -> "HVAC & Appliance Tech"
                    "cat_carpentry" -> "Precision Carpenter"
                    else -> "Field Service Pro"
                }
            },
            categoryId = categoryId,
            rating = 5.00,
            ratingCount = 1,
            distanceKm = 0.6,
            etaMinutes = 8,
            darkStoreHub = darkStoreHub.ifEmpty { "Indiranagar Hub #14" },
            latitudeOffset = ((-35..35).random() / 100f),
            longitudeOffset = ((-35..35).random() / 100f),
            status = TechnicianStatus.AVAILABLE,
            avatarEmoji = emoji,
            phone = cleanPhone,
            vehicleNumber = vehicleNumber.ifEmpty { "KA 01 EK 9911 (EV)" },
            vehicleType = vehicleType.ifEmpty { "Electric Scooter" },
            completedJobsToday = 0,
            currentVicinityLandmark = "${darkStoreHub.ifEmpty { "Indiranagar Hub #14" }} Priority Zone",
            isAvailableNow = true,
            primaryToolkits = toolkits
        )

        // Add to active nearby providers list so user can see this provider on the live radar!
        _nearbyProviders.value = listOf(newProvider) + _nearbyProviders.value

        val session = TechnicianPartnerSession(
            providerId = providerId,
            name = name.trim(),
            phone = cleanPhone,
            speciality = newProvider.speciality,
            vehicleNumber = newProvider.vehicleNumber,
            vehicleType = newProvider.vehicleType,
            avatarEmoji = emoji,
            hubName = newProvider.darkStoreHub,
            rating = 5.00,
            isDutyOn = true,
            todayEarnings = 0,
            todayJobs = 0,
            primaryToolkits = toolkits
        )

        _activeTechnicianSession.value = session
        return session
    }

    // ==========================================
    // FIREBASE AUTH & FIRESTORE METHODS
    // ==========================================

    suspend fun signInWithGoogle(): Boolean {
        val helper = firebaseAuthHelper ?: return false
        val success = helper.signInWithGoogle()
        if (success) {
            _currentUser.value = helper.currentUser.value
            syncFavoritesFromFirestore()
        }
        return success
    }

    suspend fun signInWithEmail(email: String, pass: String): Boolean {
        val helper = firebaseAuthHelper ?: return false
        val success = helper.signInWithEmail(email, pass)
        if (success) {
            _currentUser.value = helper.currentUser.value
            syncFavoritesFromFirestore()
        }
        return success
    }

    fun signOutFirebase() {
        firebaseAuthHelper?.signOut()
        _currentUser.value = null
    }

    fun syncOrderWithFirestore(order: OrderItem) {
        kotlinx.coroutines.GlobalScope.let {
            // Non-blocking firestore sync
            try {
                firebaseAuthHelper?.let { helper ->
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).run {
                        // async persist
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}


