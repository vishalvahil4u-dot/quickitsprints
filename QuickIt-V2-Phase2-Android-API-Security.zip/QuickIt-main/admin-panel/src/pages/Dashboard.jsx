import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { DollarSign, Percent, TrendingUp, Users, Wrench, Calendar, ArrowUpRight, CheckCircle2, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const [metrics, setMetrics] = useState(null);
  const [pendingProviders, setPendingProviders] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [mRes, pRes] = await Promise.all([
        api.get('/admin/metrics'),
        api.get('/admin/providers/pending'),
      ]);
      setMetrics(mRes.data.data);
      setPendingProviders(pRes.data.data || []);
    } catch (err) {
      console.error('Failed to load admin metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleApprove = async (id, status) => {
    try {
      await api.patch(`/admin/providers/${id}/approve`, { status });
      fetchDashboardData();
    } catch (err) {
      alert('Action failed: ' + (err.response?.data?.error || err.message));
    }
  };

  if (loading && !metrics) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Platform Performance & Oversight</h1>
          <p className="text-sm text-slate-400">Real-time marketplace volume, 1% commission revenue, and operations</p>
        </div>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          1.00% Platform Commission Model Active
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Total GMV */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Gross Merchandise Value</span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-white font-mono">${metrics?.total_gmv?.toFixed(2) || '0.00'}</span>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>Across {metrics?.total_paid_transactions || 0} completed payments</span>
            </p>
          </div>
        </div>

        {/* Card 2: 1% Platform Revenue */}
        <div className="bg-gradient-to-br from-blue-950/60 to-indigo-950/40 border border-blue-800/40 rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-blue-300 tracking-wider">1% Platform Revenue</span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center">
              <Percent className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-blue-400 font-mono">${metrics?.total_platform_fee_1%?.toFixed(2) || '0.00'}</span>
            <p className="text-xs text-blue-300/80 mt-1">
              Provider Net: ${(metrics?.total_provider_payouts || 0).toFixed(2)} (99%)
            </p>
          </div>
        </div>

        {/* Card 3: Active Bookings */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Active Bookings</span>
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-white font-mono">{metrics?.active_bookings || 0}</span>
            <p className="text-xs text-slate-400 mt-1">In requested, accepted, or in-progress states</p>
          </div>
        </div>

        {/* Card 4: Verified Providers & Users */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-slate-400 tracking-wider">Verified Pros / Customers</span>
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono">{metrics?.approved_providers || 0}</span>
              <span className="text-sm text-slate-400">Pros / {metrics?.total_customers || 0} Users</span>
            </div>
            <p className="text-xs text-amber-400 mt-1 font-medium">
              {metrics?.pending_providers_queue || 0} awaiting verification
            </p>
          </div>
        </div>
      </div>

      {/* Pending Providers Approval Queue */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Pending Provider Verification Queue</h2>
              <p className="text-xs text-slate-400">Review documents and approve local professionals before listing</p>
            </div>
          </div>
          <Link to="/providers" className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium">
            View All Providers <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {pendingProviders.length === 0 ? (
          <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-dashed border-slate-800 text-slate-400 text-sm">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400 mb-2 opacity-80" />
            No providers currently pending verification. All applications are up to date.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950 text-slate-400 text-xs uppercase border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Provider / Business</th>
                  <th className="py-3 px-4">Service Category</th>
                  <th className="py-3 px-4">Rate & Exp</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {pendingProviders.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-800/30">
                    <td className="py-4 px-4">
                      <div className="font-semibold text-white">{p.business_name}</div>
                      <div className="text-xs text-slate-400">{p.user?.full_name} ({p.user?.email})</div>
                    </td>
                    <td className="py-4 px-4 text-slate-300">{p.category?.name || 'General'}</td>
                    <td className="py-4 px-4 text-slate-300 font-mono">${p.hourly_rate}/hr • {p.experience_years} yrs</td>
                    <td className="py-4 px-4">
                      <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded-full text-xs font-semibold">
                        Pending Review
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleApprove(p.id, 'approved')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleApprove(p.id, 'rejected')}
                        className="px-3 py-1.5 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 rounded-lg text-xs font-semibold transition"
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Revenue & Commission Summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-base font-bold text-white mb-2">1% Platform Revenue Split Breakdown</h3>
        <p className="text-xs text-slate-400 mb-4">Every payment processed through the platform is automatically apportioned:</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400">Total Customer Paid</span>
            <div className="text-xl font-bold font-mono text-white mt-1">${(metrics?.total_gmv || 0).toFixed(2)}</div>
            <span className="text-[11px] text-slate-500">100% gross collected volume</span>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-blue-900/40">
            <span className="text-xs text-blue-400">Platform Commission (1%)</span>
            <div className="text-xl font-bold font-mono text-blue-400 mt-1">${(metrics?.total_platform_fee_1% || 0).toFixed(2)}</div>
            <span className="text-[11px] text-blue-300/70">Retained platform net revenue</span>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-xs text-emerald-400">Provider Disbursals (99%)</span>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-1">${(metrics?.total_provider_payouts || 0).toFixed(2)}</div>
            <span className="text-[11px] text-emerald-500/70">Net payed directly to service providers</span>
          </div>
        </div>
      </div>
    </div>
  );
}
