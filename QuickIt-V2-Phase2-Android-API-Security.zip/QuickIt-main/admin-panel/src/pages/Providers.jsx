import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Wrench, CheckCircle2, XCircle, Clock, Search, Filter } from 'lucide-react';

export default function Providers() {
  const [providers, setProviders] = useState([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchProviders = async () => {
    setLoading(true);
    try {
      // In real admin API, we can fetch all providers
      const res = await api.get('/providers');
      const pendingRes = await api.get('/admin/providers/pending');
      const combined = [...(res.data.data || []), ...(pendingRes.data.data || [])];
      
      // Remove duplicates by ID
      const unique = Array.from(new Map(combined.map(item => [item.id, item])).values());
      setProviders(unique);
    } catch (err) {
      console.error('Failed to fetch providers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProviders();
  }, []);

  const handleStatusChange = async (id, newStatus) => {
    try {
      await api.patch(`/admin/providers/${id}/approve`, { status: newStatus });
      fetchProviders();
    } catch (err) {
      alert('Failed to update status: ' + (err.response?.data?.error || err.message));
    }
  };

  const filteredProviders = providers.filter((p) => {
    if (filter !== 'all' && p.status !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        p.business_name?.toLowerCase().includes(q) ||
        p.user?.full_name?.toLowerCase().includes(q) ||
        p.category?.name?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Service Providers Directory</h1>
          <p className="text-sm text-slate-400">Manage verification statuses, category assignments, and provider profiles</p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row items-center gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search provider by name, business, or category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-500" />
          {['all', 'approved', 'pending', 'rejected'].map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition ${
                filter === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Providers Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400">Loading providers list...</div>
        ) : filteredProviders.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No service providers match criteria.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950 text-slate-400 text-xs uppercase border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Business / Professional</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Rate & Experience</th>
                  <th className="py-3 px-4">Rating</th>
                  <th className="py-3 px-4">Verification</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredProviders.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-800/30">
                    <td className="py-4 px-4">
                      <div className="font-semibold text-white">{p.business_name}</div>
                      <div className="text-xs text-slate-400">{p.user?.full_name} • {p.user?.email}</div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded text-xs">
                        {p.category?.name || 'Home Services'}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-300 font-mono">
                      ${p.hourly_rate}/hr • {p.experience_years} yrs
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1 text-amber-400 font-semibold text-xs">
                        ★ {p.rating?.toFixed(1) || '5.0'}
                        <span className="text-slate-500 font-normal">({p.total_reviews})</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      {p.status === 'approved' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full text-xs font-semibold">
                          <CheckCircle2 className="w-3 h-3" /> Approved
                        </span>
                      )}
                      {p.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-full text-xs font-semibold">
                          <Clock className="w-3 h-3" /> Pending Review
                        </span>
                      )}
                      {p.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-500/10 text-red-400 border border-red-500/20 rounded-full text-xs font-semibold">
                          <XCircle className="w-3 h-3" /> Rejected
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-4 text-right space-x-2">
                      {p.status !== 'approved' && (
                        <button
                          onClick={() => handleStatusChange(p.id, 'approved')}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-medium"
                        >
                          Approve
                        </button>
                      )}
                      {p.status !== 'rejected' && (
                        <button
                          onClick={() => handleStatusChange(p.id, 'rejected')}
                          className="px-2.5 py-1 bg-red-950 text-red-300 border border-red-800 hover:bg-red-900 rounded text-xs font-medium"
                        >
                          Reject
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
