import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { CreditCard, DollarSign, Percent, ArrowDownRight, CheckCircle2, XCircle, Clock } from 'lucide-react';

export default function Transactions() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      setLoading(true);
      try {
        const res = await api.get('/admin/transactions');
        setTransactions(res.data.data || []);
      } catch (err) {
        console.error('Failed to load transactions:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTransactions();
  }, []);

  const totalGross = transactions
    .filter(t => t.status === 'success')
    .reduce((acc, curr) => acc + (curr.amount || 0), 0);
  const totalCommission = transactions
    .filter(t => t.status === 'success')
    .reduce((acc, curr) => acc + (curr.platform_fee || 0), 0);
  const totalPayouts = transactions
    .filter(t => t.status === 'success')
    .reduce((acc, curr) => acc + (curr.provider_payout || 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Financial Transactions & 1% Commission Audit</h1>
        <p className="text-sm text-slate-400">Complete payment settlement log with granular 1% fee and 99% provider payout breakdown</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <div className="text-xs text-slate-400 font-semibold uppercase">Total Settled Volume</div>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">${totalGross.toFixed(2)}</div>
        </div>
        <div className="bg-slate-900 border border-blue-900/40 rounded-2xl p-5">
          <div className="text-xs text-blue-400 font-semibold uppercase">1% Platform Revenue Retained</div>
          <div className="text-2xl font-extrabold text-blue-400 font-mono mt-1">${totalCommission.toFixed(2)}</div>
        </div>
        <div className="bg-slate-900 border border-emerald-900/40 rounded-2xl p-5">
          <div className="text-xs text-emerald-400 font-semibold uppercase">99% Provider Payouts</div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">${totalPayouts.toFixed(2)}</div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400">Loading transaction records...</div>
        ) : transactions.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No transactions recorded yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950 text-slate-400 text-xs uppercase border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Transaction Ref</th>
                  <th className="py-3 px-4">Booking ID</th>
                  <th className="py-3 px-4">Gross Amount</th>
                  <th className="py-3 px-4">1% Platform Fee</th>
                  <th className="py-3 px-4">Provider Payout (99%)</th>
                  <th className="py-3 px-4">Payment Method</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Settled At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {transactions.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/30">
                    <td className="py-4 px-4 font-mono font-medium text-slate-200 text-xs">{t.transaction_ref}</td>
                    <td className="py-4 px-4 text-slate-400 font-mono text-xs">#{t.booking_id}</td>
                    <td className="py-4 px-4 font-mono font-bold text-white">${t.amount?.toFixed(2)}</td>
                    <td className="py-4 px-4 font-mono font-semibold text-blue-400">+${t.platform_fee?.toFixed(2)}</td>
                    <td className="py-4 px-4 font-mono font-semibold text-emerald-400">${t.provider_payout?.toFixed(2)}</td>
                    <td className="py-4 px-4 text-xs text-slate-400 uppercase font-mono">{t.payment_method}</td>
                    <td className="py-4 px-4">
                      {t.status === 'success' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full text-xs font-semibold">
                          <CheckCircle2 className="w-3 h-3" /> Settled
                        </span>
                      )}
                      {t.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-full text-xs font-semibold">
                          <Clock className="w-3 h-3" /> Pending
                        </span>
                      )}
                      {t.status === 'failed' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-500/10 text-red-400 border border-red-500/20 rounded-full text-xs font-semibold">
                          <XCircle className="w-3 h-3" /> Failed
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-4 text-xs text-slate-400">
                      {t.paid_at ? new Date(t.paid_at).toLocaleString() : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
