import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Calendar, Filter, Search, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await api.get('/admin/bookings');
      setBookings(res.data.data || []);
    } catch (err) {
      console.error('Failed to fetch bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleStatusUpdate = async (id, status) => {
    try {
      await api.patch(`/bookings/${id}/status`, { status });
      fetchBookings();
    } catch (err) {
      alert('Failed: ' + (err.response?.data?.error || err.message));
    }
  };

  const filtered = bookings.filter((b) => {
    if (filter !== 'all' && b.status !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        b.booking_number?.toLowerCase().includes(q) ||
        b.customer?.full_name?.toLowerCase().includes(q) ||
        b.service?.name?.toLowerCase().includes(q) ||
        b.provider?.business_name?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Service Bookings Oversight</h1>
        <p className="text-sm text-slate-400">Track and manage lifecycle status across all customer bookings</p>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search booking #, customer, service..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-slate-100 text-sm focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {['all', 'requested', 'accepted', 'in_progress', 'completed', 'cancelled'].map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition ${
                filter === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400">Loading bookings...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No bookings match the filter.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950 text-slate-400 text-xs uppercase border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Booking #</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Service & Provider</th>
                  <th className="py-3 px-4">Schedule</th>
                  <th className="py-3 px-4">Total Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-800/30">
                    <td className="py-4 px-4 font-mono font-bold text-blue-400 text-xs">{b.booking_number}</td>
                    <td className="py-4 px-4">
                      <div className="font-semibold text-white">{b.customer?.full_name}</div>
                      <div className="text-xs text-slate-400">{b.customer?.email}</div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-white font-medium">{b.service?.name}</div>
                      <div className="text-xs text-slate-400">Pro: {b.provider?.business_name}</div>
                    </td>
                    <td className="py-4 px-4 text-xs text-slate-300">
                      <div>{b.scheduled_date}</div>
                      <div className="text-slate-500">{b.scheduled_time}</div>
                    </td>
                    <td className="py-4 px-4 font-mono font-bold text-white">
                      ${b.total_amount?.toFixed(2)}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${
                        b.status === 'completed'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : b.status === 'in_progress'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          : b.status === 'accepted'
                          ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                          : b.status === 'requested'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}>
                        {b.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      {b.status === 'accepted' && (
                        <button
                          onClick={() => handleStatusUpdate(b.id, 'in_progress')}
                          className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-medium"
                        >
                          Start Job
                        </button>
                      )}
                      {b.status === 'in_progress' && (
                        <button
                          onClick={() => handleStatusUpdate(b.id, 'completed')}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-medium"
                        >
                          Complete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
