# Admin Panel (React + Vite)

Internal operator web console for monitoring marketplace volume, approving service providers, managing bookings, and auditing the 1% platform commission payments.

## Setup & Run

```bash
cp .env.example .env
npm install
npm run dev -- --port 5174
```

Access at `http://localhost:5174`.

Demo Admin: `admin@platform.com` / `admin123`
