# QuickIt Phase 2 — Android API Layer + Security Refactor

## Status
Implemented as an additive migration layer. Existing UI remains intact while new production API boundaries are introduced.

## Added
- `data/auth/AuthSessionStore.kt` — DataStore-backed auth token/session state.
- `data/auth/BackendAuthFacade.kt` — UI migration boundary.
- `data/remote/ApiClient.kt` — centralized Retrofit/OkHttp client, Authorization and request ID headers, HTTPS guard, production logging policy.
- `data/remote/QuickItApi.kt` — auth, booking and payment API contracts.
- `data/remote/ApiModels.kt` — request/response DTOs.
- `data/remote/QuickItApiProvider.kt` — app-level API provider.
- `domain/auth/AuthRepository.kt` — auth request/error abstraction.

## Security changes
- Removed hardcoded admin credentials from the repository.
- Removed generic `admin123` admin bypass.
- Removed hardcoded customer identity from the repository initial auth state.
- Removed guest/mock authentication fallbacks from Firebase email/Google sign-in failures.
- Google Sign-In now reads `GOOGLE_SERVER_CLIENT_ID` from build configuration.
- API base URL is build-time configuration and the API client rejects non-HTTPS URLs.
- No backend secrets are added to the Android source.

## Enabled dependencies for upcoming phases
- Navigation Compose
- DataStore Preferences
- Coil Compose
- Play Services Location

## Build configuration
Set environment variables before a real build:

`API_BASE_URL=https://your-api.example.com/`

`GOOGLE_SERVER_CLIENT_ID=<Google OAuth web/server client ID>`

## Validation limitation
The uploaded project does not contain the Gradle wrapper executable (`gradlew`), and this environment has no system Gradle installation. Therefore a local Android compilation could not be executed here. Source-level checks and secret/demo credential scans were performed.
