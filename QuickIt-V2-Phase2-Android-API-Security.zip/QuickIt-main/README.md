# 1% Service Collaboration Platform — 3-Tier MVP

A full-structure MVP scaffold for an on-demand services marketplace (e.g., Home Services: Plumbing, Electrical, Cleaning, Appliance Repair, Painting) featuring a **1% platform commission model** on all transactions.

---

## 🏛️ Architecture Overview

The platform is designed with clean modular boundaries across three distinct tiers plus an Android client:

```
┌─────────────────────────────────────────────────────────────┐
│                       1% Marketplace                        │
├──────────────────────────────┬──────────────────────────────┤
│  Tier 2: Admin Panel (React) │ Tier 3: User Dashboard(React)│
│  - Metrics (GMV, 1% Fee)     │ - Service Catalog            │
│  - Provider Approval Queue   │ - Booking & Slot Selection   │
│  - Transactions Audit        │ - Mock 1% Fee Checkout       │
│  - Port: 5174                │ - Port: 5173                 │
├──────────────────────────────┴──────────────────────────────┤
│               Tier 1: Backend API (Go + Gin)                │
│  - JWT Role Auth (Customer, Provider, Admin)                │
│  - GORM + PostgreSQL Persistence                            │
│  - Swappable Mocked Payment Gateway (1% Fee Auto-Split)     │
│  - Port: 8080                                               │
├─────────────────────────────────────────────────────────────┤
│               PostgreSQL Database (Port: 5432)               │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 Repository Structure

```
├── docker-compose.yml           # Multi-container orchestration (Postgres, Backend, Admin, User)
├── README.md                    # System documentation & setup guide
├── backend/                     # Tier 1: Go REST API Monolith
│   ├── cmd/server/main.go       # Entry point
│   ├── internal/
│   │   ├── config/              # Environment & App configuration
│   │   ├── database/            # Postgres GORM connection & Auto-migrations
│   │   ├── models/              # User, Provider, ServiceCategory, Service, Booking, Payment, Review
│   │   ├── middleware/          # JWT Auth, Role Guard, CORS
│   │   ├── services/            # PaymentGateway interface + Mock Gateway
│   │   ├── handlers/            # REST endpoint handlers
│   │   ├── routes/              # Route definitions
│   │   └── utils/               # JWT token utilities & JSON responses
│   ├── seed/                    # Initial seed data (Home services, sample users & providers)
│   ├── .env.example             # Backend environment template
│   ├── Dockerfile               # Production Go container
│   └── go.mod                   # Go module definitions
├── admin-panel/                 # Tier 2: Internal Admin React Application
│   ├── src/                     # React components, pages (Dashboard, Providers, Bookings, Transactions)
│   ├── package.json             # NPM dependencies (React, Vite, Lucide, Tailwind)
│   ├── Dockerfile               # Multi-stage Nginx container
│   └── .env.example             # Frontend environment template
├── user-dashboard/              # Tier 3: Customer Web React Application
│   ├── src/                     # React components, pages (Catalog, Booking Flow, Payment, Bookings)
│   ├── package.json             # NPM dependencies
│   ├── Dockerfile               # Multi-stage Nginx container
│   └── .env.example             # Frontend environment template
└── app/                         # Android Native App (Mobile Client for Streaming Emulator)
```

---

## 💳 1% Commission Calculation Model

When a customer pays for a service:
1. **Total Booking Amount**: $A$
2. **Platform Fee (1%)**: $F = A \times 0.01$
3. **Provider Payout (99%)**: $P = A - F = A \times 0.99$

### Mock Payment Gateway Lifecycle
- `POST /api/payments/initiate` creates a `Payment` with `status: pending` and returns a session token.
- `POST /api/payments/confirm` validates the payment after a short delay, computes the exact 1% platform fee vs provider net payout, and transitions the booking status from `requested` to `accepted`.
- The `PaymentGateway` interface in `internal/services/payment_gateway.go` allows swapping the mock implementation for Stripe or Razorpay without modifying handler logic.

---

## 🚀 Quick Start with Docker Compose

Run all tiers with a single command:

```bash
# Clone the repository
git clone <repo-url>
cd <repo-name>

# Start all services with Docker Compose
docker compose up --build
```

### Accessing the Web Services:
- **User Dashboard**: [http://localhost:5173](http://localhost:5173)
- **Admin Panel**: [http://localhost:5174](http://localhost:5174)
- **Backend API**: [http://localhost:8080](http://localhost:8080)
- **Postgres Database**: `localhost:5432` (`postgres:postgres`)

---

## 🛠️ Manual Local Setup (Without Docker)

### 1. Backend API (Go)
```bash
cd backend
cp .env.example .env
go mod tidy
go run cmd/server/main.go
```

### 2. Admin Panel (React)
```bash
cd admin-panel
cp .env.example .env
npm install
npm run dev -- --port 5174
```

### 3. User Dashboard (React)
```bash
cd user-dashboard
cp .env.example .env
npm install
npm run dev -- --port 5173
```

---

## 🔑 Demo Seed Accounts

| Role | Email | Password | Access |
|---|---|---|---|
| **Admin** | `admin@platform.com` | `admin123` | Full Admin Panel Access |
| **Customer** | `customer@example.com` | `password123` | Browse, Book, Pay, Review |
| **Provider** | `plumber.mike@example.com` | `password123` | Manage Jobs, View Net Payouts |
| **Provider (Pending)** | `cleaner.sara@example.com` | `password123` | In Admin Approval Queue |

---

## 📡 API Reference Summary

- `POST /api/auth/register` — Register customer or provider
- `POST /api/auth/login` — Authenticate and receive JWT token
- `GET /api/services/categories` — Browse service categories (Plumbing, Electrical, Cleaning)
- `GET /api/services/:categoryId` — Get category details and active services
- `POST /api/bookings` — Create a new service booking
- `GET /api/bookings/mine` — Get current user's bookings with lifecycle tracking
- `PATCH /api/bookings/:id/status` — Update booking status (`requested → accepted → in_progress → completed → cancelled`)
- `POST /api/payments/initiate` — Initiate checkout session
- `POST /api/payments/confirm` — Confirm payment, trigger 1% fee calculation
- `POST /api/reviews` — Submit rating and review for completed booking
- `GET /api/admin/metrics` — Aggregate GMV, 1% commission revenue, active users/providers
- `GET /api/admin/providers/pending` — Fetch pending provider verification queue
- `PATCH /api/admin/providers/:id/approve` — Approve or reject provider application
- `GET /api/admin/transactions` — Audit trail of all transactions with fee breakdown
