package main

import (
	"log"

	"github.com/platform/service-marketplace/internal/config"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/routes"
	"github.com/platform/service-marketplace/internal/services"
	"github.com/platform/service-marketplace/seed"
)

func main() {
	log.Println("🚀 Initializing 1% Service Collaboration Platform Backend...")

	// 1. Load configuration
	cfg := config.LoadConfig()

	// 2. Initialize Database & run Auto-migrations
	_, err := database.InitDB(cfg)
	if err != nil {
		log.Fatalf("❌ Database initialization error: %v", err)
	}

	// 3. Seed Database with initial demo accounts & categories
	seed.SeedDatabase()

	// 4. Initialize Payment Gateway (Mock Gateway with 1% Fee calculation)
	mockGateway := services.NewMockPaymentGateway(cfg)

	// 5. Setup Router & Middleware
	router := routes.SetupRouter(cfg, mockGateway)

	// 6. Start HTTP Server
	serverAddr := ":" + cfg.Port
	log.Printf("✨ Backend API server running on %s", serverAddr)
	if err := router.Run(serverAddr); err != nil {
		log.Fatalf("❌ Server failed to start: %v", err)
	}
}
