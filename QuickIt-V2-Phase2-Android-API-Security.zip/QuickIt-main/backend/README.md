# Backend API (Go + Gin + GORM + PostgreSQL)

The core monolith-first REST API powering the 1% Service Collaboration Platform.

## 🛠️ Requirements & Setup

- Go 1.22+
- PostgreSQL 16+ (or automatic SQLite fallback for isolated unit testing)

### Run locally:
```bash
cp .env.example .env
go mod tidy
go run cmd/server/main.go
```

The server runs on `http://localhost:8080`.
Auto-migration creates all tables (`users`, `providers`, `service_categories`, `services`, `bookings`, `payments`, `reviews`) and runs the initial seed dataset automatically.
