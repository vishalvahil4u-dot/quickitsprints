package handlers

import (
	"context"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/services"
	"github.com/platform/service-marketplace/internal/utils"
)

type PaymentHandler struct {
	gateway services.PaymentGateway
}

func NewPaymentHandler(gateway services.PaymentGateway) *PaymentHandler {
	return &PaymentHandler{gateway: gateway}
}

type InitiateRequest struct {
	BookingID uint `json:"booking_id" binding:"required"`
}

type ConfirmRequest struct {
	TransactionRef string `json:"transaction_ref" binding:"required"`
	ForceStatus    string `json:"force_status"` // "success" or "failed"
}

func (h *PaymentHandler) Initiate(c *gin.Context) {
	var req InitiateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var booking models.Booking
	if err := database.DB.Preload("Customer").First(&booking, req.BookingID).Error; err != nil {
		utils.JSONNotFound(c, "Booking not found")
		return
	}

	initResp, err := h.gateway.InitiatePayment(context.Background(), services.InitiatePaymentRequest{
		BookingID:     booking.ID,
		Amount:        booking.TotalAmount,
		Currency:      "USD",
		CustomerEmail: booking.Customer.Email,
	})
	if err != nil {
		utils.JSONInternal(c, "Failed to initiate payment gateway session")
		return
	}

	// Persist pending payment
	payment := models.Payment{
		BookingID:      booking.ID,
		TransactionRef: initResp.TransactionRef,
		Amount:         initResp.Amount,
		PlatformFee:    initResp.PlatformFee,
		ProviderPayout: initResp.ProviderPayout,
		Status:         models.PaymentPending,
		PaymentMethod:  "mock_card",
		GatewayPayload: fmt.Sprintf(`{"checkout_session": "%s"}`, initResp.TransactionRef),
	}

	if err := database.DB.Create(&payment).Error; err != nil {
		utils.JSONInternal(c, "Failed to store payment record")
		return
	}

	// Link payment to booking
	booking.PaymentID = &payment.ID
	database.DB.Save(&booking)

	utils.JSONSuccess(c, http.StatusOK, "Payment session initiated", gin.H{
		"payment":         payment,
		"checkout_url":    initResp.CheckoutURL,
		"transaction_ref": initResp.TransactionRef,
		"breakdown": gin.H{
			"total_amount":    initResp.Amount,
			"platform_fee_1%": initResp.PlatformFee,
			"provider_payout": initResp.ProviderPayout,
		},
	})
}

func (h *PaymentHandler) Confirm(c *gin.Context) {
	var req ConfirmRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var payment models.Payment
	if err := database.DB.Where("transaction_ref = ?", req.TransactionRef).First(&payment).Error; err != nil {
		utils.JSONNotFound(c, "Transaction reference not found")
		return
	}

	confirmResp, err := h.gateway.ConfirmPayment(context.Background(), services.ConfirmPaymentRequest{
		TransactionRef: req.TransactionRef,
		ForceStatus:    req.ForceStatus,
	})
	if err != nil {
		utils.JSONInternal(c, "Payment confirmation failed")
		return
	}

	payment.Status = confirmResp.Status
	payment.PaidAt = confirmResp.PaidAt
	database.DB.Save(&payment)

	// If successful, advance booking status to accepted
	var booking models.Booking
	if err := database.DB.First(&booking, payment.BookingID).Error; err == nil {
		if confirmResp.Status == models.PaymentSuccess && booking.Status == models.BookingRequested {
			booking.Status = models.BookingAccepted
			database.DB.Save(&booking)
		}
	}

	utils.JSONSuccess(c, http.StatusOK, confirmResp.GatewayMessage, gin.H{
		"payment": payment,
		"booking": booking,
		"fee_split": gin.H{
			"gross_amount":    payment.Amount,
			"platform_fee_1%": payment.PlatformFee,
			"provider_net":    payment.ProviderPayout,
		},
	})
}

func (h *PaymentHandler) MockWebhook(c *gin.Context) {
	// Async simulated webhook callback
	var payload map[string]interface{}
	if err := c.ShouldBindJSON(&payload); err != nil {
		utils.JSONBadRequest(c, "Invalid webhook body")
		return
	}

	txnRef, _ := payload["transaction_ref"].(string)
	if txnRef == "" {
		utils.JSONBadRequest(c, "Missing transaction_ref in webhook")
		return
	}

	var payment models.Payment
	if err := database.DB.Where("transaction_ref = ?", txnRef).First(&payment).Error; err != nil {
		utils.JSONNotFound(c, "Payment record not found")
		return
	}

	payment.Status = models.PaymentSuccess
	database.DB.Save(&payment)

	utils.JSONSuccess(c, http.StatusOK, "Webhook received and processed", payment)
}
