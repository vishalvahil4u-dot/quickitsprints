package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type ReviewHandler struct{}

func NewReviewHandler() *ReviewHandler {
	return &ReviewHandler{}
}

type CreateReviewRequest struct {
	BookingID uint   `json:"booking_id" binding:"required"`
	Rating    int    `json:"rating" binding:"required,min=1,max=5"`
	Comment   string `json:"comment"`
}

func (h *ReviewHandler) CreateReview(c *gin.Context) {
	userIDVal, _ := c.Get("user_id")
	customerID := userIDVal.(uint)

	var req CreateReviewRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var booking models.Booking
	if err := database.DB.First(&booking, req.BookingID).Error; err != nil {
		utils.JSONNotFound(c, "Booking not found")
		return
	}

	if booking.CustomerID != customerID {
		utils.JSONForbidden(c, "You can only review your own bookings")
		return
	}

	// Check if already reviewed
	var existing models.Review
	if err := database.DB.Where("booking_id = ?", req.BookingID).First(&existing).Error; err == nil {
		utils.JSONBadRequest(c, "Review already submitted for this booking")
		return
	}

	review := models.Review{
		BookingID:  booking.ID,
		CustomerID: customerID,
		ProviderID: booking.ProviderID,
		Rating:     req.Rating,
		Comment:    req.Comment,
	}

	if err := database.DB.Create(&review).Error; err != nil {
		utils.JSONInternal(c, "Failed to save review")
		return
	}

	// Recalculate provider average rating
	var allReviews []models.Review
	database.DB.Where("provider_id = ?", booking.ProviderID).Find(&allReviews)
	if len(allReviews) > 0 {
		var sum float64
		for _, r := range allReviews {
			sum += float64(r.Rating)
		}
		avg := sum / float64(len(allReviews))
		database.DB.Model(&models.Provider{}).Where("id = ?", booking.ProviderID).Updates(map[string]interface{}{
			"rating":        avg,
			"total_reviews": len(allReviews),
		})
	}

	utils.JSONSuccess(c, http.StatusCreated, "Review submitted successfully", review)
}
