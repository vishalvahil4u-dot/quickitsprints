package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type ServiceHandler struct{}

func NewServiceHandler() *ServiceHandler {
	return &ServiceHandler{}
}

func (h *ServiceHandler) GetCategories(c *gin.Context) {
	var categories []models.ServiceCategory
	if err := database.DB.Preload("Services").Find(&categories).Error; err != nil {
		utils.JSONInternal(c, "Failed to retrieve service categories")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Service categories fetched", categories)
}

func (h *ServiceHandler) GetCategoryByID(c *gin.Context) {
	id := c.Param("categoryId")
	var category models.ServiceCategory
	if err := database.DB.Preload("Services").First(&category, "id = ? OR slug = ?", id, id).Error; err != nil {
		utils.JSONNotFound(c, "Category not found")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Category fetched", category)
}

func (h *ServiceHandler) GetAllServices(c *gin.Context) {
	var services []models.Service
	query := database.DB.Preload("Category").Where("is_active = ?", true)

	categoryID := c.Query("category_id")
	if categoryID != "" {
		query = query.Where("category_id = ?", categoryID)
	}

	if err := query.Find(&services).Error; err != nil {
		utils.JSONInternal(c, "Failed to fetch services")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Services fetched", services)
}
