package handlers

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type BookingHandler struct{}

func NewBookingHandler() *BookingHandler {
	return &BookingHandler{}
}

type CreateBookingRequest struct {
	ProviderID     uint    `json:"provider_id" binding:"required"`
	ServiceID      uint    `json:"service_id" binding:"required"`
	ScheduledDate  string  `json:"scheduled_date" binding:"required"`
	ScheduledTime  string  `json:"scheduled_time" binding:"required"`
	ServiceAddress string  `json:"service_address" binding:"required"`
	Notes          string  `json:"notes"`
	TotalAmount    float64 `json:"total_amount"`
}

type UpdateBookingStatusRequest struct {
	Status models.BookingStatus `json:"status" binding:"required"`
}

func (h *BookingHandler) CreateBooking(c *gin.Context) {
	userIDVal, _ := c.Get("user_id")
	customerID := userIDVal.(uint)

	var req CreateBookingRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	// Validate service
	var service models.Service
	if err := database.DB.First(&service, req.ServiceID).Error; err != nil {
		utils.JSONBadRequest(c, "Invalid service selected")
		return
	}

	// Validate provider
	var provider models.Provider
	if err := database.DB.Preload("User").First(&provider, req.ProviderID).Error; err != nil {
		utils.JSONBadRequest(c, "Invalid service provider")
		return
	}

	amount := req.TotalAmount
	if amount <= 0 {
		amount = service.BasePrice
	}

	bookingNumber := fmt.Sprintf("BK-%s-%d", time.Now().Format("20060102"), time.Now().Unix()%10000)
	booking := models.Booking{
		BookingNumber:  bookingNumber,
		CustomerID:     customerID,
		ProviderID:     provider.ID,
		ServiceID:      service.ID,
		ScheduledDate:  req.ScheduledDate,
		ScheduledTime:  req.ScheduledTime,
		ServiceAddress: req.ServiceAddress,
		Notes:          req.Notes,
		Status:         models.BookingRequested,
		TotalAmount:    amount,
	}

	if err := database.DB.Create(&booking).Error; err != nil {
		utils.JSONInternal(c, "Failed to create booking")
		return
	}

	// Fetch full details
	database.DB.Preload("Customer").Preload("Provider.User").Preload("Service.Category").First(&booking, booking.ID)

	utils.JSONSuccess(c, http.StatusCreated, "Booking requested successfully", booking)
}

func (h *BookingHandler) GetMyBookings(c *gin.Context) {
	userIDVal, _ := c.Get("user_id")
	roleVal, _ := c.Get("role")
	userID := userIDVal.(uint)
	role := roleVal.(models.UserRole)

	var bookings []models.Booking
	query := database.DB.Preload("Customer").
		Preload("Provider.User").
		Preload("Provider.Category").
		Preload("Service").
		Preload("Payment").
		Preload("Review").
		Order("created_at desc")

	if role == models.RoleCustomer {
		query = query.Where("customer_id = ?", userID)
	} else if role == models.RoleProvider {
		var provider models.Provider
		if err := database.DB.Where("user_id = ?", userID).First(&provider).Error; err == nil {
			query = query.Where("provider_id = ?", provider.ID)
		} else {
			utils.JSONSuccess(c, http.StatusOK, "No bookings found", []models.Booking{})
			return
		}
	}

	if err := query.Find(&bookings).Error; err != nil {
		utils.JSONInternal(c, "Failed to fetch bookings")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Bookings retrieved", bookings)
}

func (h *BookingHandler) GetBookingByID(c *gin.Context) {
	id := c.Param("id")
	var booking models.Booking
	if err := database.DB.Preload("Customer").
		Preload("Provider.User").
		Preload("Service.Category").
		Preload("Payment").
		Preload("Review").
		First(&booking, id).Error; err != nil {
		utils.JSONNotFound(c, "Booking not found")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Booking retrieved", booking)
}

func (h *BookingHandler) UpdateStatus(c *gin.Context) {
	id := c.Param("id")
	var req UpdateBookingStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var booking models.Booking
	if err := database.DB.First(&booking, id).Error; err != nil {
		utils.JSONNotFound(c, "Booking not found")
		return
	}

	// Validate status transition
	validStatuses := map[models.BookingStatus]bool{
		models.BookingRequested:  true,
		models.BookingAccepted:   true,
		models.BookingInProgress: true,
		models.BookingCompleted:  true,
		models.BookingCancelled:  true,
	}

	if !validStatuses[req.Status] {
		utils.JSONBadRequest(c, "Invalid booking status provided")
		return
	}

	booking.Status = req.Status
	database.DB.Save(&booking)

	utils.JSONSuccess(c, http.StatusOK, fmt.Sprintf("Booking status updated to %s", req.Status), booking)
}
