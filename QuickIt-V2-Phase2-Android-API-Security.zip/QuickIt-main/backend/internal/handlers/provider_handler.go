package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type ProviderHandler struct{}

func NewProviderHandler() *ProviderHandler {
	return &ProviderHandler{}
}

func (h *ProviderHandler) GetProviders(c *gin.Context) {
	var providers []models.Provider
	query := database.DB.Preload("User").Preload("Category").Where("status = ?", models.ProviderApproved)

	categoryID := c.Query("category_id")
	if categoryID != "" {
		query = query.Where("service_category_id = ?", categoryID)
	}

	if err := query.Find(&providers).Error; err != nil {
		utils.JSONInternal(c, "Failed to retrieve providers")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Providers list fetched", providers)
}

func (h *ProviderHandler) GetProviderByID(c *gin.Context) {
	id := c.Param("id")
	var provider models.Provider
	if err := database.DB.Preload("User").Preload("Category").First(&provider, id).Error; err != nil {
		utils.JSONNotFound(c, "Provider not found")
		return
	}

	// Fetch provider reviews
	var reviews []models.Review
	database.DB.Preload("Customer").Where("provider_id = ?", provider.ID).Order("created_at desc").Find(&reviews)

	utils.JSONSuccess(c, http.StatusOK, "Provider detail retrieved", gin.H{
		"provider": provider,
		"reviews":  reviews,
	})
}

type ApplyProviderRequest struct {
	BusinessName      string  `json:"business_name" binding:"required"`
	Bio               string  `json:"bio"`
	ServiceCategoryID uint    `json:"service_category_id" binding:"required"`
	HourlyRate        float64 `json:"hourly_rate" binding:"required"`
	ExperienceYears   int     `json:"experience_years"`
}

func (h *ProviderHandler) Apply(c *gin.Context) {
	userIDVal, _ := c.Get("user_id")
	userID := userIDVal.(uint)

	var req ApplyProviderRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	// Check if already provider
	var existing models.Provider
	if err := database.DB.Where("user_id = ?", userID).First(&existing).Error; err == nil {
		utils.JSONBadRequest(c, "You have already applied as a service provider")
		return
	}

	provider := models.Provider{
		UserID:            userID,
		BusinessName:      req.BusinessName,
		Bio:               req.Bio,
		ServiceCategoryID: req.ServiceCategoryID,
		HourlyRate:        req.HourlyRate,
		ExperienceYears:   req.ExperienceYears,
		Status:            models.ProviderPending,
		Rating:            5.0,
		IsAvailable:       true,
	}

	if err := database.DB.Create(&provider).Error; err != nil {
		utils.JSONInternal(c, "Failed to submit provider application")
		return
	}

	// Update user role to provider
	database.DB.Model(&models.User{}).Where("id = ?", userID).Update("role", models.RoleProvider)

	utils.JSONSuccess(c, http.StatusCreated, "Provider application submitted for admin approval", provider)
}
