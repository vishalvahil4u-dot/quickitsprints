package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/config"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type AuthHandler struct {
	cfg *config.Config
}

func NewAuthHandler(cfg *config.Config) *AuthHandler {
	return &AuthHandler{cfg: cfg}
}

type RegisterRequest struct {
	Email             string          `json:"email" binding:"required,email"`
	Password          string          `json:"password" binding:"required,min=6"`
	FullName          string          `json:"full_name" binding:"required"`
	Phone             string          `json:"phone"`
	Role              models.UserRole `json:"role"`
	Address           string          `json:"address"`
	BusinessName      string          `json:"business_name"`
	ServiceCategoryID uint            `json:"service_category_id"`
	HourlyRate        float64         `json:"hourly_rate"`
	ExperienceYears   int             `json:"experience_years"`
	Bio               string          `json:"bio"`
}

type LoginRequest struct {
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

func (h *AuthHandler) Register(c *gin.Context) {
	var req RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	// Check if email exists
	var existing models.User
	if err := database.DB.Where("email = ?", req.Email).First(&existing).Error; err == nil {
		utils.JSONBadRequest(c, "Email already registered")
		return
	}

	hashedPassword, err := utils.HashPassword(req.Password)
	if err != nil {
		utils.JSONInternal(c, "Failed to hash password")
		return
	}

	role := req.Role
	if role == "" {
		role = models.RoleCustomer
	}

	user := models.User{
		Email:    req.Email,
		Password: hashedPassword,
		FullName: req.FullName,
		Phone:    req.Phone,
		Role:     role,
		Address:  req.Address,
	}

	if err := database.DB.Create(&user).Error; err != nil {
		utils.JSONInternal(c, "Failed to create user account")
		return
	}

	// If registering as provider, create Provider profile with status 'pending'
	if role == models.RoleProvider {
		provider := models.Provider{
			UserID:            user.ID,
			BusinessName:      req.BusinessName,
			Bio:               req.Bio,
			ServiceCategoryID: req.ServiceCategoryID,
			HourlyRate:        req.HourlyRate,
			ExperienceYears:   req.ExperienceYears,
			Status:            models.ProviderPending,
			Rating:            5.0,
			IsAvailable:       true,
		}
		if provider.BusinessName == "" {
			provider.BusinessName = user.FullName
		}
		if provider.ServiceCategoryID == 0 {
			provider.ServiceCategoryID = 1 // Default to Home Services category
		}
		_ = database.DB.Create(&provider)
	}

	token, err := utils.GenerateJWT(&user, h.cfg.JWTSecret)
	if err != nil {
		utils.JSONInternal(c, "Failed to generate authentication token")
		return
	}

	utils.JSONSuccess(c, http.StatusCreated, "Registration successful", gin.H{
		"token": token,
		"user": gin.H{
			"id":        user.ID,
			"email":     user.Email,
			"full_name": user.FullName,
			"role":      user.Role,
			"phone":     user.Phone,
			"address":   user.Address,
		},
	})
}

func (h *AuthHandler) Login(c *gin.Context) {
	var req LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var user models.User
	if err := database.DB.Preload("ProviderProfile").Where("email = ?", req.Email).First(&user).Error; err != nil {
		utils.JSONUnauthorized(c, "Invalid email or password")
		return
	}

	if !utils.CheckPasswordHash(req.Password, user.Password) {
		utils.JSONUnauthorized(c, "Invalid email or password")
		return
	}

	token, err := utils.GenerateJWT(&user, h.cfg.JWTSecret)
	if err != nil {
		utils.JSONInternal(c, "Failed to generate token")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Login successful", gin.H{
		"token": token,
		"user": gin.H{
			"id":               user.ID,
			"email":            user.Email,
			"full_name":        user.FullName,
			"role":             user.Role,
			"phone":            user.Phone,
			"address":          user.Address,
			"provider_profile": user.ProviderProfile,
		},
	})
}

func (h *AuthHandler) GetMe(c *gin.Context) {
	userID, _ := c.Get("user_id")
	var user models.User
	if err := database.DB.Preload("ProviderProfile.Category").First(&user, userID).Error; err != nil {
		utils.JSONNotFound(c, "User profile not found")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "User profile retrieved", user)
}
