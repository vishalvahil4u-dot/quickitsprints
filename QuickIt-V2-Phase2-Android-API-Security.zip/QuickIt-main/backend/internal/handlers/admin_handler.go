package handlers

import (
	"math"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

type AdminHandler struct{}

func NewAdminHandler() *AdminHandler {
	return &AdminHandler{}
}

func (h *AdminHandler) GetMetrics(c *gin.Context) {
	var totalGMV float64
	var totalPlatformFee float64
	var totalTransactions int64
	var activeBookingsCount int64
	var approvedProvidersCount int64
	var pendingProvidersCount int64
	var totalCustomersCount int64

	// Total GMV and 1% fees from successful payments
	type SumResult struct {
		TotalAmount float64
		TotalFee    float64
	}
	var sumRes SumResult
	database.DB.Model(&models.Payment{}).
		Where("status = ?", models.PaymentSuccess).
		Select("COALESCE(SUM(amount), 0) as total_amount, COALESCE(SUM(platform_fee), 0) as total_fee").
		Scan(&sumRes)

	totalGMV = math.Round(sumRes.TotalAmount*100) / 100
	totalPlatformFee = math.Round(sumRes.TotalFee*100) / 100

	database.DB.Model(&models.Payment{}).Where("status = ?", models.PaymentSuccess).Count(&totalTransactions)
	database.DB.Model(&models.Booking{}).Where("status IN ?", []models.BookingStatus{models.BookingRequested, models.BookingAccepted, models.BookingInProgress}).Count(&activeBookingsCount)
	database.DB.Model(&models.Provider{}).Where("status = ?", models.ProviderApproved).Count(&approvedProvidersCount)
	database.DB.Model(&models.Provider{}).Where("status = ?", models.ProviderPending).Count(&pendingProvidersCount)
	database.DB.Model(&models.User{}).Where("role = ?", models.RoleCustomer).Count(&totalCustomersCount)

	utils.JSONSuccess(c, http.StatusOK, "Admin platform metrics", gin.H{
		"total_gmv":                totalGMV,
		"total_platform_fee_1%":    totalPlatformFee,
		"total_provider_payouts":   math.Round((totalGMV-totalPlatformFee)*100) / 100,
		"commission_rate_percent":  1.0,
		"total_paid_transactions":  totalTransactions,
		"active_bookings":          activeBookingsCount,
		"approved_providers":       approvedProvidersCount,
		"pending_providers_queue":  pendingProvidersCount,
		"total_customers":          totalCustomersCount,
	})
}

func (h *AdminHandler) GetPendingProviders(c *gin.Context) {
	var providers []models.Provider
	if err := database.DB.Preload("User").Preload("Category").Where("status = ?", models.ProviderPending).Find(&providers).Error; err != nil {
		utils.JSONInternal(c, "Failed to fetch pending providers")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Pending providers queue fetched", providers)
}

type ProviderStatusActionRequest struct {
	Status models.ProviderStatus `json:"status" binding:"required"` // "approved" or "rejected"
}

func (h *AdminHandler) UpdateProviderStatus(c *gin.Context) {
	id := c.Param("id")
	var req ProviderStatusActionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.JSONBadRequest(c, err.Error())
		return
	}

	var provider models.Provider
	if err := database.DB.Preload("User").First(&provider, id).Error; err != nil {
		utils.JSONNotFound(c, "Provider not found")
		return
	}

	provider.Status = req.Status
	database.DB.Save(&provider)

	utils.JSONSuccess(c, http.StatusOK, "Provider status updated successfully", provider)
}

func (h *AdminHandler) GetTransactions(c *gin.Context) {
	var payments []models.Payment
	if err := database.DB.Order("created_at desc").Find(&payments).Error; err != nil {
		utils.JSONInternal(c, "Failed to retrieve transactions")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Transactions log retrieved", payments)
}

func (h *AdminHandler) GetAllUsers(c *gin.Context) {
	var users []models.User
	query := database.DB.Preload("ProviderProfile").Order("created_at desc")

	role := c.Query("role")
	if role != "" {
		query = query.Where("role = ?", role)
	}

	if err := query.Find(&users).Error; err != nil {
		utils.JSONInternal(c, "Failed to fetch users")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Users list retrieved", users)
}

func (h *AdminHandler) GetAllBookings(c *gin.Context) {
	var bookings []models.Booking
	query := database.DB.Preload("Customer").
		Preload("Provider.User").
		Preload("Service").
		Preload("Payment").
		Order("created_at desc")

	status := c.Query("status")
	if status != "" {
		query = query.Where("status = ?", status)
	}

	if err := query.Find(&bookings).Error; err != nil {
		utils.JSONInternal(c, "Failed to fetch bookings")
		return
	}

	utils.JSONSuccess(c, http.StatusOK, "Bookings list retrieved", bookings)
}
