package routes

import (
	"github.com/gin-gonic/gin"
	"github.com/platform/service-marketplace/internal/config"
	"github.com/platform/service-marketplace/internal/handlers"
	"github.com/platform/service-marketplace/internal/middleware"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/services"
)

func SetupRouter(cfg *config.Config, gateway services.PaymentGateway) *gin.Engine {
	r := gin.Default()

	// CORS
	r.Use(middleware.CORSMiddleware(cfg.CORSAllowedOrigins))

	// Instantiate Handlers
	authHandler := handlers.NewAuthHandler(cfg)
	serviceHandler := handlers.NewServiceHandler()
	bookingHandler := handlers.NewBookingHandler()
	paymentHandler := handlers.NewPaymentHandler(gateway)
	providerHandler := handlers.NewProviderHandler()
	reviewHandler := handlers.NewReviewHandler()
	adminHandler := handlers.NewAdminHandler()

	api := r.Group("/api")
	{
		// Health check
		api.GET("/health", func(c *gin.Context) {
			c.JSON(200, gin.H{"status": "ok", "service": "1% Service Collaboration Platform API"})
		})

		// Auth endpoints
		auth := api.Group("/auth")
		{
			auth.POST("/register", authHandler.Register)
			auth.POST("/login", authHandler.Login)
		}

		// Public Service Catalog
		api.GET("/services/categories", serviceHandler.GetCategories)
		api.GET("/services/categories/:categoryId", serviceHandler.GetCategoryByID)
		api.GET("/services", serviceHandler.GetAllServices)
		api.GET("/providers", providerHandler.GetProviders)
		api.GET("/providers/:id", providerHandler.GetProviderByID)

		// Public Mock Payment Webhook
		api.POST("/payments/webhook/mock", paymentHandler.MockWebhook)

		// Authenticated Routes
		authenticated := api.Group("")
		authenticated.Use(middleware.AuthMiddleware(cfg.JWTSecret))
		{
			// Current user profile
			authenticated.GET("/auth/me", authHandler.GetMe)

			// Provider application
			authenticated.POST("/providers/apply", providerHandler.Apply)

			// Bookings
			authenticated.POST("/bookings", bookingHandler.CreateBooking)
			authenticated.GET("/bookings/mine", bookingHandler.GetMyBookings)
			authenticated.GET("/bookings/:id", bookingHandler.GetBookingByID)
			authenticated.PATCH("/bookings/:id/status", bookingHandler.UpdateStatus)

			// Payments
			authenticated.POST("/payments/initiate", paymentHandler.Initiate)
			authenticated.POST("/payments/confirm", paymentHandler.Confirm)

			// Reviews
			authenticated.POST("/reviews", reviewHandler.CreateReview)

			// Admin Only Routes
			adminGroup := authenticated.Group("/admin")
			adminGroup.Use(middleware.RequireRoles(models.RoleAdmin))
			{
				adminGroup.GET("/metrics", adminHandler.GetMetrics)
				adminGroup.GET("/providers/pending", adminHandler.GetPendingProviders)
				adminGroup.PATCH("/providers/:id/approve", adminHandler.UpdateProviderStatus)
				adminGroup.GET("/transactions", adminHandler.GetTransactions)
				adminGroup.GET("/users", adminHandler.GetAllUsers)
				adminGroup.GET("/bookings", adminHandler.GetAllBookings)
			}
		}
	}

	return r
}
