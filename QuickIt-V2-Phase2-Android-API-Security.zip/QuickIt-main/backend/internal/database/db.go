package database

import (
	"fmt"
	"log"

	"github.com/platform/service-marketplace/internal/config"
	"github.com/platform/service-marketplace/internal/models"
	"gorm.io/driver/postgres"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var DB *gorm.DB

func InitDB(cfg *config.Config) (*gorm.DB, error) {
	dsn := fmt.Sprintf(
		"host=%s user=%s password=%s dbname=%s port=%s sslmode=%s TimeZone=UTC",
		cfg.DBHost, cfg.DBUser, cfg.DBPassword, cfg.DBName, cfg.DBPort, cfg.DBSSLMode,
	)

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Info),
	})

	if err != nil {
		log.Printf("⚠️ Failed to connect to PostgreSQL (%v), attempting SQLite fallback for local testing...", err)
		db, err = gorm.Open(sqlite.Open("services.db"), &gorm.Config{
			Logger: logger.Default.LogMode(logger.Info),
		})
		if err != nil {
			return nil, fmt.Errorf("failed to open database: %w", err)
		}
		log.Println("✅ Connected to SQLite fallback database")
	} else {
		log.Println("✅ Connected to PostgreSQL database successfully")
	}

	// Auto-migrate tables
	err = db.AutoMigrate(
		&models.User{},
		&models.ServiceCategory{},
		&models.Provider{},
		&models.Service{},
		&models.Booking{},
		&models.Payment{},
		&models.Review{},
	)
	if err != nil {
		return nil, fmt.Errorf("failed to auto-migrate database: %w", err)
	}

	DB = db
	return db, nil
}
