package services

import (
	"context"
	"fmt"
	"math"
	"time"

	"github.com/google/uuid"
	"github.com/platform/service-marketplace/internal/config"
	"github.com/platform/service-marketplace/internal/models"
)

type InitiatePaymentRequest struct {
	BookingID   uint    `json:"booking_id"`
	Amount      float64 `json:"amount"`
	Currency    string  `json:"currency"`
	CustomerEmail string `json:"customer_email"`
}

type InitiatePaymentResponse struct {
	TransactionRef string  `json:"transaction_ref"`
	CheckoutURL    string  `json:"checkout_url"`
	Amount         float64 `json:"amount"`
	PlatformFee    float64 `json:"platform_fee"`
	ProviderPayout float64 `json:"provider_payout"`
	Status         models.PaymentStatus `json:"status"`
}

type ConfirmPaymentRequest struct {
	TransactionRef string `json:"transaction_ref"`
	ForceStatus    string `json:"force_status,omitempty"` // "success" or "failed" to simulate
}

type ConfirmPaymentResponse struct {
	TransactionRef string               `json:"transaction_ref"`
	Status         models.PaymentStatus `json:"status"`
	Amount         float64              `json:"amount"`
	PlatformFee    float64              `json:"platform_fee"`
	ProviderPayout float64              `json:"provider_payout"`
	PaidAt         *time.Time           `json:"paid_at"`
	GatewayMessage string               `json:"gateway_message"`
}

// PaymentGateway interface makes it swappable with Stripe, Razorpay, etc.
type PaymentGateway interface {
	InitiatePayment(ctx context.Context, req InitiatePaymentRequest) (*InitiatePaymentResponse, error)
	ConfirmPayment(ctx context.Context, req ConfirmPaymentRequest) (*ConfirmPaymentResponse, error)
	ComputeFee(amount float64) (platformFee float64, providerPayout float64)
}

type MockPaymentGateway struct {
	cfg *config.Config
}

func NewMockPaymentGateway(cfg *config.Config) PaymentGateway {
	return &MockPaymentGateway{cfg: cfg}
}

func (m *MockPaymentGateway) ComputeFee(amount float64) (float64, float64) {
	// 1% Commission formula
	feePercentage := m.cfg.PlatformFeePercentage / 100.0
	platformFee := math.Round(amount*feePercentage*100) / 100
	providerPayout := math.Round((amount-platformFee)*100) / 100
	return platformFee, providerPayout
}

func (m *MockPaymentGateway) InitiatePayment(ctx context.Context, req InitiatePaymentRequest) (*InitiatePaymentResponse, error) {
	platformFee, providerPayout := m.ComputeFee(req.Amount)
	txnRef := fmt.Sprintf("txn_mock_%s", uuid.New().String()[:12])

	return &InitiatePaymentResponse{
		TransactionRef: txnRef,
		CheckoutURL:    fmt.Sprintf("/checkout/%s", txnRef),
		Amount:         req.Amount,
		PlatformFee:    platformFee,
		ProviderPayout: providerPayout,
		Status:         models.PaymentPending,
	}, nil
}

func (m *MockPaymentGateway) ConfirmPayment(ctx context.Context, req ConfirmPaymentRequest) (*ConfirmPaymentResponse, error) {
	status := models.PaymentSuccess
	if req.ForceStatus == "failed" {
		status = models.PaymentFailed
	} else if req.ForceStatus == "success" {
		status = models.PaymentSuccess
	} else if m.cfg.MockPaymentDefaultStatus == "failed" {
		status = models.PaymentFailed
	}

	var paidAt *time.Time
	message := "Mock payment completed successfully with 1% platform fee deduction"
	if status == models.PaymentSuccess {
		now := time.Now()
		paidAt = &now
	} else {
		message = "Mock payment simulation failed by request"
	}

	return &ConfirmPaymentResponse{
		TransactionRef: req.TransactionRef,
		Status:         status,
		PaidAt:         paidAt,
		GatewayMessage: message,
	}, nil
}
