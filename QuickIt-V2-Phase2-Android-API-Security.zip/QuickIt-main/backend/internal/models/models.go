package models

import (
	"time"
)

type UserRole string

const (
	RoleCustomer UserRole = "customer"
	RoleProvider UserRole = "provider"
	RoleAdmin    UserRole = "admin"
)

type ProviderStatus string

const (
	ProviderPending  ProviderStatus = "pending"
	ProviderApproved ProviderStatus = "approved"
	ProviderRejected ProviderStatus = "rejected"
)

type BookingStatus string

const (
	BookingRequested  BookingStatus = "requested"
	BookingAccepted   BookingStatus = "accepted"
	BookingInProgress BookingStatus = "in_progress"
	BookingCompleted  BookingStatus = "completed"
	BookingCancelled  BookingStatus = "cancelled"
)

type PaymentStatus string

const (
	PaymentPending PaymentStatus = "pending"
	PaymentSuccess PaymentStatus = "success"
	PaymentFailed  PaymentStatus = "failed"
)

type User struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Email     string    `gorm:"uniqueIndex;not null" json:"email"`
	Password  string    `gorm:"not null" json:"-"`
	FullName  string    `gorm:"not null" json:"full_name"`
	Phone     string    `json:"phone"`
	Role      UserRole  `gorm:"type:varchar(20);default:'customer'" json:"role"`
	Address   string    `json:"address"`
	AvatarURL string    `json:"avatar_url"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`

	ProviderProfile *Provider `gorm:"foreignKey:UserID" json:"provider_profile,omitempty"`
}

type Provider struct {
	ID                uint           `gorm:"primaryKey" json:"id"`
	UserID            uint           `gorm:"uniqueIndex;not null" json:"user_id"`
	User              User           `gorm:"foreignKey:UserID" json:"user"`
	BusinessName      string         `gorm:"not null" json:"business_name"`
	Bio               string         `json:"bio"`
	ServiceCategoryID uint           `gorm:"not null" json:"service_category_id"`
	Category          ServiceCategory `gorm:"foreignKey:ServiceCategoryID" json:"category"`
	HourlyRate        float64        `gorm:"default:0.0" json:"hourly_rate"`
	ExperienceYears   int            `json:"experience_years"`
	Status            ProviderStatus `gorm:"type:varchar(20);default:'pending'" json:"status"`
	Rating            float64        `gorm:"default:5.0" json:"rating"`
	TotalReviews      int            `gorm:"default:0" json:"total_reviews"`
	IsAvailable       bool           `gorm:"default:true" json:"is_available"`
	CreatedAt         time.Time      `json:"created_at"`
	UpdatedAt         time.Time      `json:"updated_at"`
}

type ServiceCategory struct {
	ID          uint      `gorm:"primaryKey" json:"id"`
	Name        string    `gorm:"uniqueIndex;not null" json:"name"`
	Slug        string    `gorm:"uniqueIndex;not null" json:"slug"`
	Description string    `json:"description"`
	Icon        string    `json:"icon"`
	Services    []Service `gorm:"foreignKey:CategoryID" json:"services,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type Service struct {
	ID          uint            `gorm:"primaryKey" json:"id"`
	CategoryID  uint            `gorm:"not null" json:"category_id"`
	Category    ServiceCategory `gorm:"foreignKey:CategoryID" json:"category,omitempty"`
	Name        string          `gorm:"not null" json:"name"`
	Description string          `json:"description"`
	BasePrice   float64         `gorm:"not null" json:"base_price"`
	DurationMin int             `gorm:"default:60" json:"duration_min"`
	IsActive    bool            `gorm:"default:true" json:"is_active"`
	CreatedAt   time.Time       `json:"created_at"`
	UpdatedAt   time.Time       `json:"updated_at"`
}

type Booking struct {
	ID             uint          `gorm:"primaryKey" json:"id"`
	BookingNumber  string        `gorm:"uniqueIndex;not null" json:"booking_number"`
	CustomerID     uint          `gorm:"not null" json:"customer_id"`
	Customer       User          `gorm:"foreignKey:CustomerID" json:"customer"`
	ProviderID     uint          `gorm:"not null" json:"provider_id"`
	Provider       Provider      `gorm:"foreignKey:ProviderID" json:"provider"`
	ServiceID      uint          `gorm:"not null" json:"service_id"`
	Service        Service       `gorm:"foreignKey:ServiceID" json:"service"`
	ScheduledDate  string        `gorm:"not null" json:"scheduled_date"`
	ScheduledTime  string        `gorm:"not null" json:"scheduled_time"`
	ServiceAddress string        `gorm:"not null" json:"service_address"`
	Notes          string        `json:"notes"`
	Status         BookingStatus `gorm:"type:varchar(20);default:'requested'" json:"status"`
	TotalAmount    float64       `gorm:"not null" json:"total_amount"`
	PaymentID      *uint         `json:"payment_id"`
	Payment        *Payment      `gorm:"foreignKey:PaymentID" json:"payment,omitempty"`
	Review         *Review       `gorm:"foreignKey:BookingID" json:"review,omitempty"`
	CreatedAt      time.Time     `json:"created_at"`
	UpdatedAt      time.Time     `json:"updated_at"`
}

type Payment struct {
	ID             uint          `gorm:"primaryKey" json:"id"`
	BookingID      uint          `gorm:"not null" json:"booking_id"`
	TransactionRef string        `gorm:"uniqueIndex;not null" json:"transaction_ref"`
	Amount         float64       `gorm:"not null" json:"amount"`
	PlatformFee    float64       `gorm:"not null" json:"platform_fee"`    // 1% platform commission
	ProviderPayout float64       `gorm:"not null" json:"provider_payout"` // 99% payout to provider
	PaymentMethod  string        `gorm:"default:'mock_card'" json:"payment_method"`
	Status         PaymentStatus `gorm:"type:varchar(20);default:'pending'" json:"status"`
	GatewayPayload string        `gorm:"type:text" json:"gateway_payload"`
	PaidAt         *time.Time    `json:"paid_at"`
	CreatedAt      time.Time     `json:"created_at"`
	UpdatedAt      time.Time     `json:"updated_at"`
}

type Review struct {
	ID         uint      `gorm:"primaryKey" json:"id"`
	BookingID  uint      `gorm:"uniqueIndex;not null" json:"booking_id"`
	CustomerID uint      `gorm:"not null" json:"customer_id"`
	Customer   User      `gorm:"foreignKey:CustomerID" json:"customer"`
	ProviderID uint      `gorm:"not null" json:"provider_id"`
	Rating     int       `gorm:"not null" json:"rating"` // 1-5
	Comment    string    `json:"comment"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}
