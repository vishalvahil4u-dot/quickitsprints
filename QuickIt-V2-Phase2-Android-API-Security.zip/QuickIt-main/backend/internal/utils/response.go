package utils

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type APIResponse struct {
	Success bool        `json:"success"`
	Message string      `json:"message,omitempty"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

func JSONSuccess(c *gin.Context, statusCode int, message string, data interface{}) {
	c.JSON(statusCode, APIResponse{
		Success: true,
		Message: message,
		Data:    data,
	})
}

func JSONError(c *gin.Context, statusCode int, errMsg string) {
	c.JSON(statusCode, APIResponse{
		Success: false,
		Error:   errMsg,
	})
}

func JSONBadRequest(c *gin.Context, errMsg string) {
	JSONError(c, http.StatusBadRequest, errMsg)
}

func JSONUnauthorized(c *gin.Context, errMsg string) {
	JSONError(c, http.StatusUnauthorized, errMsg)
}

func JSONForbidden(c *gin.Context, errMsg string) {
	JSONError(c, http.StatusForbidden, errMsg)
}

func JSONNotFound(c *gin.Context, errMsg string) {
	JSONError(c, http.StatusNotFound, errMsg)
}

func JSONInternal(c *gin.Context, errMsg string) {
	JSONError(c, http.StatusInternalServerError, errMsg)
}
