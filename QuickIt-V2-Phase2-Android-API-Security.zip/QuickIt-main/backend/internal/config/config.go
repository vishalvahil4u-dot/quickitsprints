package config

import (
	"os"
	"strconv"
)

type Config struct {
	Port                     string
	DBHost                   string
	DBPort                   string
	DBUser                   string
	DBPassword               string
	DBName                   string
	DBSSLMode                string
	JWTSecret                string
	PlatformFeePercentage    float64
	MockPaymentDefaultStatus string
	CORSAllowedOrigins       string
}

func LoadConfig() *Config {
	feeStr := getEnv("PLATFORM_FEE_PERCENTAGE", "1.0")
	fee, err := strconv.ParseFloat(feeStr, 64)
	if err != nil {
		fee = 1.0
	}

	return &Config{
		Port:                     getEnv("PORT", "8080"),
		DBHost:                   getEnv("DB_HOST", "localhost"),
		DBPort:                   getEnv("DB_PORT", "5432"),
		DBUser:                   getEnv("DB_USER", "postgres"),
		DBPassword:               getEnv("DB_PASSWORD", "postgres"),
		DBName:                   getEnv("DB_NAME", "services_marketplace"),
		DBSSLMode:                getEnv("DB_SSLMODE", "disable"),
		JWTSecret:                getEnv("JWT_SECRET", "super-secret-jwt-key-for-mvp-1-percent"),
		PlatformFeePercentage:    fee,
		MockPaymentDefaultStatus: getEnv("MOCK_PAYMENT_DEFAULT_STATUS", "success"),
		CORSAllowedOrigins:       getEnv("CORS_ALLOWED_ORIGINS", "http://localhost:5173,http://localhost:5174,http://localhost:3000"),
	}
}

func getEnv(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}
