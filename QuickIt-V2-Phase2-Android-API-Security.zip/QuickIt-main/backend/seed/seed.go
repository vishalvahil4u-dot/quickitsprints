package seed

import (
	"log"
	"time"

	"github.com/platform/service-marketplace/internal/database"
	"github.com/platform/service-marketplace/internal/models"
	"github.com/platform/service-marketplace/internal/utils"
)

func SeedDatabase() {
	var count int64
	database.DB.Model(&models.User{}).Count(&count)
	if count > 0 {
		log.Println("ℹ️ Database already contains data, skipping initial seed.")
		return
	}

	log.Println("🌱 Seeding initial MVP marketplace data...")

	// 1. Password hash for demo users
	adminPass, _ := utils.HashPassword("admin123")
	userPass, _ := utils.HashPassword("password123")

	// 2. Create Users
	admin := models.User{
		Email:    "admin@platform.com",
		Password: adminPass,
		FullName: "Platform Administrator",
		Role:     models.RoleAdmin,
		Phone:    "+1-555-0100",
		Address:  "HQ Operations Center",
	}
	database.DB.Create(&admin)

	customer := models.User{
		Email:    "customer@example.com",
		Password: userPass,
		FullName: "John Doe",
		Role:     models.RoleCustomer,
		Phone:    "+1-555-0101",
		Address:  "742 Evergreen Terrace, Springfield",
	}
	database.DB.Create(&customer)

	providerUser1 := models.User{
		Email:    "plumber.mike@example.com",
		Password: userPass,
		FullName: "Mike Miller",
		Role:     models.RoleProvider,
		Phone:    "+1-555-0102",
		Address:  "120 Industrial Way, Springfield",
	}
	database.DB.Create(&providerUser1)

	providerUser2 := models.User{
		Email:    "electrician.dave@example.com",
		Password: userPass,
		FullName: "Dave Sparks",
		Role:     models.RoleProvider,
		Phone:    "+1-555-0103",
		Address:  "88 Copper Rd, Springfield",
	}
	database.DB.Create(&providerUser2)

	providerUser3 := models.User{
		Email:    "cleaner.sara@example.com",
		Password: userPass,
		FullName: "Sara Bright",
		Role:     models.RoleProvider,
		Phone:    "+1-555-0104",
		Address:  "45 Maple Ave, Springfield",
	}
	database.DB.Create(&providerUser3)

	// 3. Service Categories
	catPlumbing := models.ServiceCategory{
		Name:        "Plumbing",
		Slug:        "plumbing",
		Description: "Pipe repairs, drain cleaning, leaks, faucet and water heater installation.",
		Icon:        "wrench",
	}
	database.DB.Create(&catPlumbing)

	catElectrical := models.ServiceCategory{
		Name:        "Electrical",
		Slug:        "electrical",
		Description: "Wiring, switchboard fixes, lighting installation, fuse box troubleshooting.",
		Icon:        "zap",
	}
	database.DB.Create(&catElectrical)

	catCleaning := models.ServiceCategory{
		Name:        "Cleaning",
		Slug:        "cleaning",
		Description: "Full home deep cleaning, kitchen sanitation, carpet & sofa shampooing.",
		Icon:        "sparkles",
	}
	database.DB.Create(&catCleaning)

	// 4. Services
	service1 := models.Service{
		CategoryID:  catPlumbing.ID,
		Name:        "Emergency Pipe Leak Repair",
		Description: "Rapid diagnostic and sealant repair for leaking pipes and joints.",
		BasePrice:   80.00,
		DurationMin: 60,
		IsActive:    true,
	}
	database.DB.Create(&service1)

	service2 := models.Service{
		CategoryID:  catPlumbing.ID,
		Name:        "Drain Unclogging & Cleaning",
		Description: "High-pressure motorized drain cleaning and obstruction clearance.",
		BasePrice:   120.00,
		DurationMin: 90,
		IsActive:    true,
	}
	database.DB.Create(&service2)

	service3 := models.Service{
		CategoryID:  catElectrical.ID,
		Name:        "Ceiling Fan & Light Fixture Installation",
		Description: "Safe mounting and circuit wiring for standard fixtures.",
		BasePrice:   65.00,
		DurationMin: 45,
		IsActive:    true,
	}
	database.DB.Create(&service3)

	service4 := models.Service{
		CategoryID:  catCleaning.ID,
		Name:        "Complete Deep Home Cleaning",
		Description: "3-room intensive dust, vacuum, mopping, and surface disinfecting.",
		BasePrice:   150.00,
		DurationMin: 180,
		IsActive:    true,
	}
	database.DB.Create(&service4)

	// 5. Providers
	p1 := models.Provider{
		UserID:            providerUser1.ID,
		BusinessName:      "Mike's Rapid Plumbing & Heating",
		Bio:               "Licensed master plumber with over 10 years experience solving water leaks and pipe renewals.",
		ServiceCategoryID: catPlumbing.ID,
		HourlyRate:        75.0,
		ExperienceYears:   10,
		Status:            models.ProviderApproved,
		Rating:            4.9,
		TotalReviews:      24,
		IsAvailable:       true,
	}
	database.DB.Create(&p1)

	p2 := models.Provider{
		UserID:            providerUser2.ID,
		BusinessName:      "Sparks Certified Electrical",
		Bio:               "Certified residential electrician for fixtures, rewiring, and safety inspections.",
		ServiceCategoryID: catElectrical.ID,
		HourlyRate:        85.0,
		ExperienceYears:   8,
		Status:            models.ProviderApproved,
		Rating:            4.8,
		TotalReviews:      18,
		IsAvailable:       true,
	}
	database.DB.Create(&p2)

	p3 := models.Provider{
		UserID:            providerUser3.ID,
		BusinessName:      "Bright & Pure Eco Cleaners",
		Bio:               "Professional home and apartment deep cleaning specialist using organic eco-friendly products.",
		ServiceCategoryID: catCleaning.ID,
		HourlyRate:        50.0,
		ExperienceYears:   5,
		Status:            models.ProviderPending, // In pending approval queue for Admin test
		Rating:            5.0,
		TotalReviews:      0,
		IsAvailable:       true,
	}
	database.DB.Create(&p3)

	// 6. Sample Initial Booking + Payment (with 1% fee calculation)
	amount := 80.00
	platformFee := 0.80   // 1% of $80
	providerPayout := 79.20 // 99% of $80
	now := time.Now()

	booking1 := models.Booking{
		BookingNumber:  "BK-20260822-1001",
		CustomerID:     customer.ID,
		ProviderID:     p1.ID,
		ServiceID:      service1.ID,
		ScheduledDate:  "2026-08-25",
		ScheduledTime:  "10:00 AM",
		ServiceAddress: "742 Evergreen Terrace, Springfield",
		Notes:          "Kitchen sink pipe dripping steadily under sink cupboard.",
		Status:         models.BookingAccepted,
		TotalAmount:    amount,
	}
	database.DB.Create(&booking1)

	payment1 := models.Payment{
		BookingID:      booking1.ID,
		TransactionRef: "txn_mock_seed_9021",
		Amount:         amount,
		PlatformFee:    platformFee,
		ProviderPayout: providerPayout,
		PaymentMethod:  "mock_card",
		Status:         models.PaymentSuccess,
		PaidAt:         &now,
		GatewayPayload: `{"status":"success","mock_simulated":true,"platform_commission_percent":1.0}`,
	}
	database.DB.Create(&payment1)

	booking1.PaymentID = &payment1.ID
	database.DB.Save(&booking1)

	log.Println("✅ Seeding completed: 1 Admin, 1 Customer, 3 Providers (2 Approved, 1 Pending), 4 Services, 1 Seed Payment.")
}
