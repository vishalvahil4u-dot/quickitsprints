# User Dashboard (React + Vite)

Customer web application for discovering verified local home service providers, booking appointments, paying through the 1% escrow mock payment gateway, tracking live booking lifecycle progress, and submitting ratings & reviews.

## Setup & Run

```bash
cp .env.example .env
npm install
npm run dev -- --port 5173
```

Access at `http://localhost:5173`.

Demo Customer: `customer@example.com` / `password123`
