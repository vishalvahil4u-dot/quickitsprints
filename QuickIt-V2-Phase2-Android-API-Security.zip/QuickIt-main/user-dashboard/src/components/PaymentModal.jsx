import React, { useState } from 'react';
import { api } from '../services/api';
import { CreditCard, CheckCircle2, AlertCircle, ShieldCheck, Lock, Sparkles, Loader2, X } from 'lucide-react';

export default function PaymentModal({ booking, onClose, onPaymentComplete }) {
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [expiry, setExpiry] = useState('12/28');
  const [cvc, setCvc] = useState('999');
  const [forceStatus, setForceStatus] = useState('success');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [paymentResult, setPaymentResult] = useState(null);

  const amount = booking?.total_amount || 0;
  const platformFee = Math.round(amount * 0.01 * 100) / 100;
  const providerPayout = Math.round((amount - platformFee) * 100) / 100;

  const handlePay = async (e) => {
    e.preventDefault();
    setProcessing(true);
    setError('');

    try {
      // 1. Initiate payment session
      const initRes = await api.post('/payments/initiate', { booking_id: booking.id });
      const { transaction_ref } = initRes.data.data;

      // 2. Simulate 1.5s gateway latency
      await new Promise((r) => setTimeout(r, 1500));

      // 3. Confirm with mock payment gateway
      const confirmRes = await api.post('/payments/confirm', {
        transaction_ref,
        force_status: forceStatus,
      });

      const { payment } = confirmRes.data.data;
      if (payment.status === 'success') {
        setPaymentResult(confirmRes.data.data);
        if (onPaymentComplete) onPaymentComplete(confirmRes.data.data);
      } else {
        setError('Payment was declined by the card issuer simulator.');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Payment gateway connection error');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Secure Mock Checkout</h3>
              <p className="text-[11px] text-slate-400">1% Marketplace Escrow</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {paymentResult ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <div>
              <h4 className="text-xl font-bold text-white">Payment Confirmed!</h4>
              <p className="text-xs text-slate-400 mt-1">
                Ref: <span className="font-mono text-slate-300">{paymentResult.payment.transaction_ref}</span>
              </p>
            </div>

            {/* Split summary */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Total Paid:</span>
                <span className="font-bold text-white font-mono">${amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-blue-400">
                <span>1% Platform Commission:</span>
                <span className="font-mono font-semibold">${platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-emerald-400 border-t border-slate-800 pt-2">
                <span>Provider Net Escrow (99%):</span>
                <span className="font-mono font-bold">${providerPayout.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-sm transition"
            >
              Back to My Bookings
            </button>
          </div>
        ) : (
          <form onSubmit={handlePay} className="mt-5 space-y-4">
            {error && (
              <div className="p-3 bg-red-950/60 border border-red-800 rounded-xl text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Price & 1% Fee Transparency Card */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400">Service Charge</span>
                <span className="font-bold text-white font-mono">${amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-xs text-blue-400">
                <span>Includes 1.00% Platform Fee</span>
                <span className="font-mono">${platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-emerald-400/90 pt-1 border-t border-slate-800/80">
                <span>Direct Provider Payout (99%)</span>
                <span className="font-mono">${providerPayout.toFixed(2)}</span>
              </div>
            </div>

            {/* Mock Card Input Form */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Card Number
              </label>
              <div className="relative">
                <CreditCard className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-sm text-slate-200 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Expires
                </label>
                <input
                  type="text"
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-sm text-slate-200 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  CVC / CVV
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 absolute right-3 top-3 text-slate-500" />
                  <input
                    type="password"
                    value={cvc}
                    onChange={(e) => setCvc(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-sm text-slate-200 font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* Gateway Simulation Mode Toggle */}
            <div className="pt-2">
              <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                Mock Gateway Mode (Test simulation)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setForceStatus('success')}
                  className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition border ${
                    forceStatus === 'success'
                      ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Simulate Success
                </button>
                <button
                  type="button"
                  onClick={() => setForceStatus('failed')}
                  className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition border ${
                    forceStatus === 'failed'
                      ? 'bg-red-600/20 border-red-500 text-red-400'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Simulate Decline
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={processing}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 disabled:opacity-50 mt-2"
            >
              {processing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Mock Escrow...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Pay ${amount.toFixed(2)} Securely</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
