import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api';
import { Wrench, Zap, Sparkles, Star, ShieldCheck, ArrowRight, Clock, MapPin, Search } from 'lucide-react';

export default function Home() {
  const [categories, setCategories] = useState([]);
  const [providers, setProviders] = useState([]);
  const [selectedCat, setSelectedCat] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [catRes, provRes] = await Promise.all([
          api.get('/services/categories'),
          api.get('/providers'),
        ]);
        setCategories(catRes.data.data || []);
        setProviders(provRes.data.data || []);
      } catch (err) {
        console.error('Failed to load marketplace catalog:', err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const getCatIcon = (slug) => {
    switch (slug) {
      case 'plumbing': return <Wrench className="w-5 h-5" />;
      case 'electrical': return <Zap className="w-5 h-5" />;
      case 'cleaning': return <Sparkles className="w-5 h-5" />;
      default: return <Wrench className="w-5 h-5" />;
    }
  };

  const filteredProviders = providers.filter((p) => {
    if (selectedCat !== 'all' && p.category?.slug !== selectedCat) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        p.business_name?.toLowerCase().includes(q) ||
        p.bio?.toLowerCase().includes(q) ||
        p.category?.name?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-10">
      {/* Hero Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-blue-900/60 via-slate-900 to-indigo-950/60 border border-slate-800 p-8 sm:p-12 overflow-hidden shadow-2xl">
        <div className="max-w-2xl relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-full text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            Fair 1% Platform Commission Model
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Book Verified Local Home Service Experts
          </h1>
          <p className="text-sm sm:text-base text-slate-300">
            Transparent pricing, licensed professionals for plumbing, electrical, and deep home cleaning with guaranteed satisfaction.
          </p>

          {/* Search bar */}
          <div className="pt-2 flex items-center gap-2 max-w-lg">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search plumbing, wiring, cleaning..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-3 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Service Categories Bar */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white tracking-tight">Browse by Category</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <button
            onClick={() => setSelectedCat('all')}
            className={`p-4 rounded-2xl border text-left transition flex items-center gap-3 ${
              selectedCat === 'all'
                ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/30'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-slate-950/50 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm">All Services</div>
              <div className="text-xs opacity-75">All Categories</div>
            </div>
          </button>

          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCat(c.slug)}
              className={`p-4 rounded-2xl border text-left transition flex items-center gap-3 ${
                selectedCat === c.slug
                  ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/30'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-slate-950/50 flex items-center justify-center text-blue-400">
                {getCatIcon(c.slug)}
              </div>
              <div>
                <div className="font-bold text-sm">{c.name}</div>
                <div className="text-xs opacity-75">{c.services?.length || 0} services</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Featured Services & Providers */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Available Verified Providers</h2>
            <p className="text-xs text-slate-400">Vetted local professionals ready for on-demand booking</p>
          </div>
          <span className="text-xs font-semibold text-slate-400">{filteredProviders.length} active pros</span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-slate-400">Loading verified providers...</div>
        ) : filteredProviders.length === 0 ? (
          <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-3xl text-slate-400">
            No verified providers found in this category.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProviders.map((p) => (
              <div
                key={p.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 transition flex flex-col justify-between group shadow-xl"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="inline-block px-2.5 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[11px] font-semibold mb-1">
                        {p.category?.name || 'Home Services'}
                      </div>
                      <h3 className="font-bold text-lg text-white group-hover:text-blue-400 transition">
                        {p.business_name}
                      </h3>
                      <p className="text-xs text-slate-400">{p.user?.full_name}</p>
                    </div>

                    <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2.5 py-1 rounded-xl text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{p.rating?.toFixed(1) || '5.0'}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                    {p.bio || 'Licensed and insured local service expert with prompt arrival and guaranteed workmanship.'}
                  </p>

                  <div className="flex items-center gap-4 text-xs text-slate-400 pt-3 border-t border-slate-800/80 mb-4">
                    <div className="flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      <span>{p.experience_years}+ yrs experience</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Verified Pro</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <span className="text-[11px] text-slate-500 uppercase font-semibold block">Base Rate</span>
                    <span className="text-lg font-extrabold text-white font-mono">${p.hourly_rate?.toFixed(2)}/hr</span>
                  </div>

                  <Link
                    to={`/provider/${p.id}`}
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition shadow-md shadow-blue-600/20"
                  >
                    <span>Book Pro</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
