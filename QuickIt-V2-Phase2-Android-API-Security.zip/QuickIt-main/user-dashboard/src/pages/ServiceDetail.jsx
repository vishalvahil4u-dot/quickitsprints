import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';
import { Wrench, Star, ShieldCheck, Clock, MapPin, Calendar, ArrowRight, User, CheckCircle2 } from 'lucide-react';

export default function ServiceDetail() {
  const { id } = useParams();
  const [providerData, setProviderData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProvider = async () => {
      setLoading(true);
      try {
        const res = await api.get(`/providers/${id}`);
        setProviderData(res.data.data);
      } catch (err) {
        console.error('Failed to load provider details:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProvider();
  }, [id]);

  if (loading) {
    return <div className="p-12 text-center text-slate-400">Loading service professional profile...</div>;
  }

  if (!providerData || !providerData.provider) {
    return <div className="p-12 text-center text-slate-400">Service provider not found.</div>;
  }

  const { provider, reviews = [] } = providerData;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Top Banner Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified {provider.category?.name || 'Home Service'} Specialist
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {provider.business_name}
            </h1>
            <p className="text-sm text-slate-300">Represented by <span className="font-semibold text-white">{provider.user?.full_name}</span></p>

            <div className="flex items-center gap-4 text-xs text-slate-400 pt-2">
              <div className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-4 h-4 fill-amber-400" />
                <span>{provider.rating?.toFixed(1) || '5.0'}</span>
                <span className="text-slate-500 font-normal">({reviews.length} customer reviews)</span>
              </div>
              <span>•</span>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>{provider.experience_years}+ Years Experience</span>
              </div>
            </div>
          </div>

          <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 text-center sm:text-right space-y-3 sm:min-w-[200px]">
            <div>
              <span className="text-xs text-slate-400 block">Starting Service Rate</span>
              <span className="text-2xl font-extrabold text-white font-mono">${provider.hourly_rate?.toFixed(2)}/hr</span>
              <span className="text-[10px] text-blue-400 block mt-0.5">Platform commission only 1%</span>
            </div>

            <Link
              to={`/book/${provider.id}`}
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs transition shadow-lg shadow-blue-600/25"
            >
              <span>Schedule Booking</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Bio */}
        <div className="mt-6 pt-6 border-t border-slate-800">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-2">About the Service Provider</h3>
          <p className="text-sm text-slate-300 leading-relaxed">
            {provider.bio || 'Experienced trade professional with verified credentials, complete insurance, and background checks. Dedicated to clean, punctual, high-quality home service.'}
          </p>
        </div>

        {/* Included Guarantees */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center gap-2.5 text-xs text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>100% Guaranteed Workmanship</span>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center gap-2.5 text-xs text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Escrow 1% Protected Payment</span>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center gap-2.5 text-xs text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Verified Admin Approval</span>
          </div>
        </div>
      </div>

      {/* Customer Reviews */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
        <h2 className="text-xl font-bold text-white mb-6">Customer Ratings & Reviews</h2>

        {reviews.length === 0 ? (
          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 text-center text-slate-400 text-sm">
            No reviews yet for this provider. Be the first to book and share feedback!
          </div>
        ) : (
          <div className="space-y-4">
            {reviews.map((r) => (
              <div key={r.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center text-xs font-bold">
                      <User className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-white">{r.customer?.full_name || 'Customer'}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                    {'★'.repeat(r.rating)}
                    <span className="text-slate-500 text-[10px] ml-1 font-normal">
                      {new Date(r.created_at || Date.now()).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pl-9">
                  {r.comment || 'Great service, prompt and professional!'}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
