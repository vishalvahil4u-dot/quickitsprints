import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { Calendar, Clock, MapPin, Wrench, ShieldCheck, AlertCircle, ArrowRight, DollarSign } from 'lucide-react';
import PaymentModal from '../components/PaymentModal';

export default function BookingFlow() {
  const { providerId } = useParams();
  const navigate = useNavigate();

  const [provider, setProvider] = useState(null);
  const [services, setServices] = useState([]);
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [scheduledDate, setScheduledDate] = useState('2026-08-25');
  const [scheduledTime, setScheduledTime] = useState('10:00 AM');
  const [serviceAddress, setServiceAddress] = useState('742 Evergreen Terrace, Springfield');
  const [notes, setNotes] = useState('Please bring tools for sink pipe replacement.');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  // Payment checkout modal state
  const [createdBooking, setCreatedBooking] = useState(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [pRes, sRes] = await Promise.all([
          api.get(`/providers/${providerId}`),
          api.get('/services'),
        ]);
        const prov = pRes.data.data.provider;
        setProvider(prov);
        const allServices = sRes.data.data || [];
        setServices(allServices);
        if (allServices.length > 0) {
          // Default to service belonging to same category or first service
          const match = allServices.find((s) => s.category_id === prov.service_category_id);
          setSelectedServiceId(match ? match.id : allServices[0].id);
        }
      } catch (err) {
        console.error('Failed to load booking details:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [providerId]);

  const selectedService = services.find((s) => s.id === Number(selectedServiceId));
  const totalAmount = selectedService ? selectedService.basePrice || selectedService.base_price || 75.0 : 75.0;
  const platformFee = Math.round(totalAmount * 0.01 * 100) / 100;
  const providerNet = Math.round((totalAmount - platformFee) * 100) / 100;

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('user_token');
    if (!token) {
      navigate('/login');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const res = await api.post('/bookings', {
        provider_id: Number(providerId),
        service_id: Number(selectedServiceId),
        scheduled_date: scheduledDate,
        scheduled_time: scheduledTime,
        service_address: serviceAddress,
        notes: notes,
        total_amount: totalAmount,
      });

      const booking = res.data.data;
      setCreatedBooking(booking);
      setShowPaymentModal(true);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit booking');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePaymentFinished = (result) => {
    setShowPaymentModal(false);
    navigate('/bookings');
  };

  if (loading) {
    return <div className="p-12 text-center text-slate-400">Loading booking configuration...</div>;
  }

  if (!provider) {
    return <div className="p-12 text-center text-slate-400">Provider not found</div>;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Schedule Your Service</h1>
        <p className="text-xs text-slate-400">Select preferred appointment slot, address, and review 1% fee breakdown</p>
      </div>

      {error && (
        <div className="p-3 bg-red-950/60 border border-red-800 rounded-xl text-red-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Provider Summary Badge */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-white text-sm">{provider.business_name}</div>
            <div className="text-xs text-slate-400">{provider.category?.name || 'Home Services'}</div>
          </div>
        </div>
        <div className="text-right font-mono">
          <div className="text-xs text-slate-400">Hourly Base</div>
          <div className="font-bold text-emerald-400 text-sm">${provider.hourly_rate?.toFixed(2)}/hr</div>
        </div>
      </div>

      <form onSubmit={handleBookingSubmit} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-5">
        {/* Service Type Selection */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
            Select Specific Service
          </label>
          <select
            value={selectedServiceId}
            onChange={(e) => setSelectedServiceId(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-white focus:outline-none focus:border-blue-500"
          >
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} — ${(s.basePrice || s.base_price)?.toFixed(2)} ({s.durationMin || s.duration_min || 60} mins)
              </option>
            ))}
          </select>
        </div>

        {/* Date & Time Slot */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Preferred Date
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
              <input
                type="date"
                required
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-3 text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Time Slot
            </label>
            <div className="relative">
              <Clock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
              <select
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-3 text-sm text-white focus:outline-none focus:border-blue-500"
              >
                <option value="09:00 AM">09:00 AM - 11:00 AM</option>
                <option value="11:30 AM">11:30 AM - 01:30 PM</option>
                <option value="02:00 PM">02:00 PM - 04:00 PM</option>
                <option value="04:30 PM">04:30 PM - 06:30 PM</option>
              </select>
            </div>
          </div>
        </div>

        {/* Service Address */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
            Service Location Address
          </label>
          <div className="relative">
            <MapPin className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
            <input
              type="text"
              required
              value={serviceAddress}
              onChange={(e) => setServiceAddress(e.target.value)}
              placeholder="Full street address, apartment / suite..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
            Job Notes / Special Instructions
          </label>
          <textarea
            rows="3"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Describe the issue or any gate codes..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-sm text-white focus:outline-none focus:border-blue-500 resize-none"
          ></textarea>
        </div>

        {/* 1% Fee Transparency Card */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex justify-between items-center text-sm">
            <span className="text-slate-400 font-medium">Service Total</span>
            <span className="font-bold text-white font-mono text-base">${totalAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between items-center text-xs text-blue-400">
            <span>Marketplace Commission (1%)</span>
            <span className="font-mono">${platformFee.toFixed(2)}</span>
          </div>
          <div className="flex justify-between items-center text-xs text-emerald-400 pt-1 border-t border-slate-800">
            <span>Provider Net Disbursal (99%)</span>
            <span className="font-mono font-bold">${providerNet.toFixed(2)}</span>
          </div>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl text-sm transition flex items-center justify-center gap-2 shadow-xl shadow-blue-600/25 disabled:opacity-50"
        >
          {submitting ? 'Creating Booking...' : 'Proceed to Mock 1% Payment Escrow'}
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>

      {/* Payment Modal */}
      {showPaymentModal && createdBooking && (
        <PaymentModal
          booking={createdBooking}
          onClose={() => setShowPaymentModal(false)}
          onPaymentComplete={handlePaymentFinished}
        />
      )}
    </div>
  );
}
