import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { Calendar, Clock, MapPin, CheckCircle2, Star, CreditCard, ShieldCheck, AlertCircle, Sparkles } from 'lucide-react';
import PaymentModal from '../components/PaymentModal';

export default function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedForPayment, setSelectedForPayment] = useState(null);

  // Review modal state
  const [reviewBooking, setReviewBooking] = useState(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('Excellent work, resolved quickly and very neat!');
  const [submittingReview, setSubmittingReview] = useState(false);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await api.get('/bookings/mine');
      setBookings(res.data.data || []);
    } catch (err) {
      console.error('Failed to load user bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleUpdateStatus = async (id, status) => {
    try {
      await api.patch(`/bookings/${id}/status`, { status });
      fetchBookings();
    } catch (err) {
      alert('Failed: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    setSubmittingReview(true);
    try {
      await api.post('/reviews', {
        booking_id: reviewBooking.id,
        rating: Number(rating),
        comment,
      });
      setReviewBooking(null);
      fetchBookings();
    } catch (err) {
      alert('Review error: ' + (err.response?.data?.error || err.message));
    } finally {
      setSubmittingReview(false);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Completed</span>;
      case 'in_progress':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">In Progress</span>;
      case 'accepted':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">Accepted</span>;
      case 'requested':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">Awaiting Payment / Accept</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400">{status}</span>;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Service Bookings Tracker</h1>
        <p className="text-xs text-slate-400">Real-time status lifecycle, 1% fee escrow, and completion reviews</p>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-400">Loading your bookings...</div>
      ) : bookings.length === 0 ? (
        <div className="p-12 bg-slate-900 border border-slate-800 rounded-3xl text-center space-y-3">
          <Calendar className="w-10 h-10 mx-auto text-slate-600" />
          <h3 className="text-lg font-bold text-white">No active service bookings found</h3>
          <p className="text-xs text-slate-400">Browse home service pros and schedule your first job in under a minute.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((b) => {
            const fee = Math.round(b.total_amount * 0.01 * 100) / 100;
            const net = Math.round((b.total_amount - fee) * 100) / 100;
            const isPaid = b.payment && b.payment.status === 'success';

            return (
              <div key={b.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-blue-400">{b.booking_number}</span>
                      {getStatusBadge(b.status)}
                      {isPaid ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-800">
                          PAID (1% ESCROW)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 text-[10px] font-bold border border-amber-800">
                          PAYMENT PENDING
                        </span>
                      )}
                    </div>
                    <h3 className="text-base font-bold text-white mt-1">
                      {b.service?.name || 'Home Repair Service'}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-400 block">Total Booking Value</span>
                    <span className="text-xl font-extrabold text-white font-mono">${b.total_amount?.toFixed(2)}</span>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-300">
                  <div>
                    <span className="text-slate-500 block uppercase text-[10px] font-semibold">Service Provider</span>
                    <span className="font-medium text-white">{b.provider?.business_name}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block uppercase text-[10px] font-semibold">Scheduled Time</span>
                    <span>{b.scheduled_date} at {b.scheduled_time}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block uppercase text-[10px] font-semibold">Service Location</span>
                    <span className="truncate block">{b.service_address}</span>
                  </div>
                </div>

                {/* Status Progress Bar */}
                <div className="pt-2">
                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 mb-2">
                    <span className={b.status === 'requested' ? 'text-amber-400 font-bold' : 'text-slate-300'}>1. Requested</span>
                    <span className={b.status === 'accepted' ? 'text-purple-400 font-bold' : 'text-slate-300'}>2. Accepted & Paid</span>
                    <span className={b.status === 'in_progress' ? 'text-blue-400 font-bold' : 'text-slate-300'}>3. In Progress</span>
                    <span className={b.status === 'completed' ? 'text-emerald-400 font-bold' : 'text-slate-300'}>4. Completed</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div
                      className={`h-full transition-all duration-300 ${
                        b.status === 'completed'
                          ? 'w-full bg-emerald-500'
                          : b.status === 'in_progress'
                          ? 'w-3/4 bg-blue-500'
                          : b.status === 'accepted'
                          ? 'w-1/2 bg-purple-500'
                          : 'w-1/4 bg-amber-500'
                      }`}
                    ></div>
                  </div>
                </div>

                {/* 1% Fee Transparency Breakdown */}
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-400" />
                    <span className="text-slate-300">1% Platform Fee: <span className="font-mono text-blue-400 font-semibold">${fee.toFixed(2)}</span></span>
                  </div>
                  <span className="text-slate-400">Provider Net (99%): <span className="font-mono text-emerald-400 font-semibold">${net.toFixed(2)}</span></span>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-2">
                  <div>
                    {b.review ? (
                      <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold">
                        <Star className="w-4 h-4 fill-amber-400" />
                        <span>Reviewed: {b.review.rating}/5 stars ("{b.review.comment}")</span>
                      </div>
                    ) : b.status === 'completed' ? (
                      <button
                        onClick={() => setReviewBooking(b)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition"
                      >
                        <Star className="w-3.5 h-3.5" />
                        <span>Leave Review</span>
                      </button>
                    ) : null}
                  </div>

                  <div className="flex items-center gap-2">
                    {!isPaid && (
                      <button
                        onClick={() => setSelectedForPayment(b)}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-blue-600/20"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Pay ${b.total_amount?.toFixed(2)}</span>
                      </button>
                    )}

                    {b.status === 'accepted' && (
                      <button
                        onClick={() => handleUpdateStatus(b.id, 'in_progress')}
                        className="px-3 py-2 bg-blue-700 hover:bg-blue-600 text-white rounded-xl text-xs font-semibold"
                      >
                        Mark In Progress
                      </button>
                    )}

                    {b.status === 'in_progress' && (
                      <button
                        onClick={() => handleUpdateStatus(b.id, 'completed')}
                        className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
                      >
                        Mark Completed
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Payment Modal */}
      {selectedForPayment && (
        <PaymentModal
          booking={selectedForPayment}
          onClose={() => setSelectedForPayment(null)}
          onPaymentComplete={() => {
            setSelectedForPayment(null);
            fetchBookings();
          }}
        />
      )}

      {/* Review Modal */}
      {reviewBooking && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-white text-base">Rate Service Provider</h3>
            <p className="text-xs text-slate-400">Share your feedback for {reviewBooking.provider?.business_name}</p>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-2">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setRating(num)}
                      className={`w-10 h-10 rounded-xl font-bold flex items-center justify-center border transition ${
                        rating >= num
                          ? 'bg-amber-500 border-amber-400 text-slate-950'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      ★ {num}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase mb-2">Comment</label>
                <textarea
                  rows="3"
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReviewBooking(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold"
                >
                  {submittingReview ? 'Submitting...' : 'Post Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
