# QuickIt Phase 2 — Android API + Security Refactor

## Implemented
- Retrofit API contract for authentication, bookings and payments.
- Centralized OkHttp authorization/request-ID interceptor.
- DataStore-backed auth session storage; passwords and payment secrets are never stored.
- Build-time API base URL and Google server client ID configuration.
- HTTPS-only API client guard.
- Real-auth-only behavior: removed guest/mock login fallbacks and hardcoded admin password acceptance.
- Enabled Navigation Compose, DataStore, Coil and Play Services Location dependencies for upcoming phases.

## API source of truth
The Android client treats the Go backend as authoritative for price, booking state, payment state, authorization and provider assignment.

## Production configuration
Set these environment variables when building:

- `API_BASE_URL=https://your-api.example.com/`
- `GOOGLE_SERVER_CLIENT_ID=<OAuth web/server client ID>`

Do not place backend secrets, JWT secrets or Razorpay secret keys in the Android project.
